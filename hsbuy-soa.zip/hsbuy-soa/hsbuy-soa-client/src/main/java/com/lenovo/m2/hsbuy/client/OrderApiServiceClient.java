package com.lenovo.m2.hsbuy.client;


import com.lenovo.m2.hsbuy.ordercenter.OpenOrderService;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.support.PropertiesLoaderUtils;

import java.util.Properties;


public class OrderApiServiceClient {

    private static final OrderApiServiceClient INSTANCE = new OrderApiServiceClient();
    private final ClassPathXmlApplicationContext ctx;

    private OrderApiServiceClient() {
        String filename = "spring-config-dubbo-consumer-domain.xml";
        try{
            Properties props = PropertiesLoaderUtils.loadAllProperties("env.properties");
            String env = props.getProperty("env");
            if (env!=null && "product".equals(env)){
                filename = "spring-config-dubbo-consumer-domain.xml";
            }else if (env!=null && "dev".equals(env)){
                filename = "spring-config-dubbo-consumer-dev.xml";
            }else if (env!=null && "uat".equals(env)){
                filename = "spring-config-dubbo-consumer-uat.xml";
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
        this.ctx = new ClassPathXmlApplicationContext(filename);
    }

    public OpenOrderService getOrderApiService() {
        return (OpenOrderService) this.ctx.getBean("openOrderService");
    }

    public static OrderApiServiceClient getINSTANCE() {
        return INSTANCE;
    }

}
