package com.lenovo.m2.hsbuy.inventory;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.inventory.GetStockInfoParam;
import com.lenovo.m2.hsbuy.domain.inventory.OrderAndStock;
import com.lenovo.m2.hsbuy.domain.inventory.StockInfo;


import java.util.List;
import java.util.Map;

public interface StockPortApiService {


    //查询库存信息---(搜索使用)
    public RemoteResult getStockInfo(List<GetStockInfoParam> params);
    //查询库存信息---(global使用)
    RemoteResult getGlobalStockInfo(List<GetStockInfoParam> params, Tenant tenant);


    /**
     * 当活动结束时，将活动库存释放
     * @param list 批量释放
     * @return
     */
    RemoteResult releaseActivity(List<GetStockInfoParam> list);

    /**
     * 根据订单号查询库存扣减记录
     * @param orderCode
     * @return
     */
    RemoteResult<List<OrderAndStock>> getStockInfoByOrderCode(String orderCode);


    /**
     * 根据库存主键id查询库存信息
     * @param stockInfoId
     * @return
     */
    StockInfo getStockInfoById(Long stockInfoId);

}