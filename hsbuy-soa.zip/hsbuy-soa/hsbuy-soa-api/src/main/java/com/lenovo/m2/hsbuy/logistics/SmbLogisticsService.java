package com.lenovo.m2.hsbuy.logistics;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.order.logistics.OpenPlatRequestForMsg;
import com.lenovo.m2.hsbuy.domain.order.logistics.SmbRequest;

/**
 * @author : 朝阳
 * @version : v1.0
 * @email : licy13@lenovo.com
 * @time : 2017/11/28 17:42
 */
public interface SmbLogisticsService {
    /**
     * 订单物流号推送
     *
     * @param smbRequest
     * @return
     */
    RemoteResult updateLogisticsCode(SmbRequest smbRequest);

    /**
     * 订单物流轨迹推送
     *
     * @param openPlatRequestForMsg
     * @return
     */
    RemoteResult updateLogisticsMessage(OpenPlatRequestForMsg openPlatRequestForMsg);
}
