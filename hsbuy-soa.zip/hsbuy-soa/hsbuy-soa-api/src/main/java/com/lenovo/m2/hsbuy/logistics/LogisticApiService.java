package com.lenovo.m2.hsbuy.logistics;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.order.logistics.RemoteLogistic;
import com.lenovo.m2.hsbuy.domain.order.logistics.TaskRequest;
import com.lenovo.m2.hsbuy.domain.ordercenter.LogisticsPlatform;
import com.lenovo.m2.hsbuy.domain.ordercenter.OrderLogistics;

import java.util.List;
import java.util.Map;

public interface LogisticApiService {


    /**
     * 直营、非直营发货接口
     *
     * @param remoteLogistic
     * @param oper           indirect、direct
     * @return
     */
    RemoteResult logisticsDelivery(RemoteLogistic remoteLogistic, String oper);

    /**
     * 获取物流公司
     *
     * @return
     */
    RemoteResult<List<LogisticsPlatform>> getLogiInfo();


    /**
     * 获取物流与订单的关系
     *
     * @param orderCode
     * @return
     */
    RemoteResult<List<OrderLogistics>> getOrderLogisticsByOrderCenter(String orderCode);

    /**
     * 根据订单号和物流单号获取物流轨迹
     *
     * @param orderCode
     * @param logisticsNo
     * @return
     */
    RemoteResult<List<OrderLogistics>> getLogisticTrack(String orderCode, String logisticsNo);

    /**
     * 查询物流轨迹(我的订单调用)
     *
     * @param orderId
     * @return
     */
    RemoteResult<Map<String, Object>> getLogisticsTrack(String orderId, Tenant tenant);

    /**
     * 订阅kuaidi100
     * @param taskRequest
     * @return
     */
    public RemoteResult poll(TaskRequest taskRequest);

    /**
     * kuaidi100回调
     * @param param
     * @return
     */
    public RemoteResult callback(String param);
}
