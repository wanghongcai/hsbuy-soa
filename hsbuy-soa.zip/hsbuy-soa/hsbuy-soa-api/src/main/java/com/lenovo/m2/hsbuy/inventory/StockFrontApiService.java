package com.lenovo.m2.hsbuy.inventory;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.inventory.AddOrderParam;
import com.lenovo.m2.hsbuy.domain.inventory.CastOrderParam;
import com.lenovo.m2.hsbuy.domain.inventory.ConfirmOrderParam;
import com.lenovo.m2.hsbuy.domain.inventory.OrderInfo;

import java.util.List;
import java.util.Map;


public interface StockFrontApiService {


    /*----------------------------------global分割线------------------------------*/

    /**
     * 新增订单
     */
    RemoteResult globalAddOrder(AddOrderParam addOrderParam, Tenant tenant);
    /**
     * 确认订单，进入待支付状态,生成订单号调用
     */
    RemoteResult globalConfirmOrder(ConfirmOrderParam confirmOrderParam, Tenant tenant);
    /**
     * 废弃订单，此订单无效（调用addOrder未调用confirmOrder）
     */
    RemoteResult globalDeleteOrder(Long returnId, Tenant tenant);
    /**
     * 取消订单，只有未支付的才可以取消
     */
    RemoteResult globalFreeOrder(String orderCode, Tenant tenant);
    /**
     * 支付订单，只有新建状态addOrder的才可以支付
     */
    RemoteResult globalPayOrder(String orderCode, Tenant tenant);
    /**
     * 撤销订单，只有已抛单的订单才可以撤销  （支付以后发货之前）
     * 增加faid参数用于区分直营和非直营（直营涉及大平台库存，撤单逻辑不同）
     * @return
     */
    RemoteResult globalRevokeOrder(String orderCode, String faid, Tenant tenant);
    /**
     * 抛单，只有已支付状态的才可以抛单  （抛BTCP以后）
     * 增加faid参数用于区分直营和非直营（直营涉及大平台库存，抛单逻辑不同）
     * @return
     */
    RemoteResult globalCastOrder(String orderCode, String faid, Tenant tenant);
    /**
     * 拆单，只有新建状态的才可以拆单，拆单后订单状态不变，但须校验子订单库品及数量是否与主订单一致
     * @param mOrderCode 主订单号
     * @param sOrderPorts 子订单列表，包括子订单号及相关库品及数量
     * @return
     */
    RemoteResult globalSplitOrder(String mOrderCode, List<Map<String, Object>> sOrderPorts, Tenant tenant);
    /**
     * 按库存地抛单
     * @param param 参数对象
     * @param tenant 租户对象
     * @return
     */
    RemoteResult castOrderByWarehouse(CastOrderParam param,Tenant tenant);
    /**
     * 根据订单号和shopid查询库存中保存的订单信息
     * @param orderCode
     * @param shopId
     * @return
     */
    RemoteResult<OrderInfo> getOrderInfoByOrderCode(String orderCode, Integer shopId);

}
