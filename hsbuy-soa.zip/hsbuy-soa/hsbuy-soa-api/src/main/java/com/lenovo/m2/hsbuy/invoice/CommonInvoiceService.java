package com.lenovo.m2.hsbuy.invoice;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.invoice.VatInvoice;

/**
 * Created by admin on 2017/3/16.
 * 普票和电子票服务
 */
public interface CommonInvoiceService {

    //查询单个发票信息，只能查询到有效数据
    public RemoteResult<VatInvoice> getInvoiceById(Long id, Tenant tenant);

    //前台页面，保存发票信息
    public RemoteResult<VatInvoice> saveInvoice(VatInvoice vatInvoice, Tenant tenant);

    //前台页面根据发票抬头带出发票信息，必须是已审核的
    public RemoteResult<VatInvoice> getInvoiceByTitle(VatInvoice vatInvoice, Tenant tenant);

}
