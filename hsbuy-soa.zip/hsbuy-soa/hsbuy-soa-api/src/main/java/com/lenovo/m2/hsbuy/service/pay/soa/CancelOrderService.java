package com.lenovo.m2.hsbuy.service.pay.soa;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;

/**
 * 订单取消逻辑
 * Created by MengQiang on 2016/8/1.
 */
public interface CancelOrderService {

    /**
     * 处理订单取消逻辑
     * @param outTradeNo
     * @param tenant
     * @param lenovoId
     * @return
     */
    public RemoteResult<String> orderCancel(String outTradeNo, Tenant tenant, String lenovoId);
}
