package com.lenovo.m2.hsbuy.service.pay.query;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;

/**
 * 招行退货查询
 * Created by luyang on 2016/3/15.
 */
public interface CMBPayQueryService {
    public RemoteResult<String> cmbPayQuery(String staTime, String endTime, int count, MerchantPayPlatView merchantPayPlatVie);
}
