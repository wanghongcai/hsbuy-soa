package com.lenovo.m2.hsbuy.inventory.constants;

import java.util.Map;

/**
 * Created by Jiazy on 15-6-28.
 */
public class StockConstants {

    private static Map<String, String> platformAndBusinessUnit;

    public static String getBusinessUnitByPlatform(String platform) {
        return platformAndBusinessUnit.get(platform);
    }

    public void setPlatformAndBusinessUnit(Map<String, String> platformAndBusinessUnit) {
        StockConstants.platformAndBusinessUnit = platformAndBusinessUnit;
    }

    /**
     * 失效类型
     */
    public static final int   SOLD_OUT_INVALID = 0; // 下架 失效
    public static final int HAND_INVALID = 1;    //手动 失效



    /**
     * 库存状态
     */
    public static final String STOCK_VALID="0";//有效
    public static final int STOCK_INVALID=1;//无效

    /**
     * 上架状态
     */
    public static final int IS_PUTAWAY = 1;   //已上架
    public static final int NOT_PUTAWAY = 0;   //未上架

    /**
     * 循环次数
     */
    public static final int LOOP_COUNT = 5;

    /**
     * 订单类型 order_status
     */
    public static final int SPLIT = -2;  //拆单
    public static final int DELETED = -1;  //废弃
    public static final int TO_BE_CONFIRMED = 0;  //新增,待确认
    public static final int WAIT_PAY = 1;  //待支付
    public static final int PAID_PAY = 2;  // 已支付
    public static final int FREE_PAY = 3;  //释放
    public static final int REVOCATION_PAY = 4;  //撤销
    public static final int CAST_PAY = 5;  //抛单
    public static final int SOFT_LOCK = 6;  //软占用 懂得通信订单适用
    public static final int REFUND = 7;//退货 懂得通信订单适用



    /**
     * 库存类型
      */
    public static final int STOCK_TYPE_SALES = 1;   //可卖数库存
    public static final int STOCK_TYPE_SALES_T = 11;   //团购活动库存
    public static final int STOCK_TYPE_SALES_S = 12;   //闪购活动库存
    public static final int STOCK_TYPE_SALES_X = 13;   //限时抢购活动库存
    public static final int STOCK_TYPE_WAIT = 2;    //占用 待支付
    public static final int STOCK_TYPE_PAID = 3;    //冻结  已支付
    public static final int STOCK_TYPE_LIMIT = 4;   //库存上限  大平台库存
    public static final int STOCK_TYPE_CAST = 5;    //抛单

    /**
     * 操作类型
      */
    public static final int OPER_CREATION = 0;   //新建库存
    public static final int OPER_ADD = 1;    //后台管理 增加库存
    public static final int OPER_LES = 2;   //后台管理 减少库存
    public static final int OPER_PUTAWAY = 3;  //上架操作
    public static final int OPER_SOLD_OUT = 4; //下架操作
    public static final int OPER_CONFIRM_STOCK = 5;  //待支付  占用
    public static final int OPER_WAIT_PAY = 6;  //待支付  占用
    public static final int OPER_DELETE_ORDER = 7;  //待支付  占用
    public static final int OPER_PAID_PAY = 8;  // 已支付 冻结
    public static final int OPER_FREE_PAY = 9;  //释放  取消订单
    public static final int OPER_REVOKE_PAY = 10;  //撤销 退货
    public static final int OPER_CAST_PAY = 11;  //抛单
    public static final int OPER_INVALID = 12;   //失效操作  只针对与大平台手动失效
    public static final int OPER_SPLIT_MAIN = 13;   //拆单,主订单
    public static final int OPER_SPLIT_SUB = 14;   //拆单,子订单

    /**
     * 变动方向
     */
    public static final String CHANGE_DIRECTION_ADD = "增加";  //增加
    public static final String CHANGE_DIRECTION_LESS = "减少";  //减少
    public static final String CHANGE_DIRECTION_UNCHANGED = "不变";  //不变

    /**
     * 订单来源
     */

    public static final String ORDER_SOURCE_FRONT = "orderSysytem";  //订单系统
    public static final String ORDER_SOURCE_CUSTOMER = "bigCustomer";   //三方订单
    /**
     * activeMQ 队列名称
     */
    public static final String SOFT_LOCK_QUEUE = "softLock.queue";
    public static final String TELE_STOCK_NOTICE_QUEUE = "teleStockNotice.queue";
    public static final String ACTIVITY_STOCK_QUEUE = "activityStock.queue";
    /**
     * 订单流转操作库存方法对应的码表，定时任务、异常处理任务使用
     */
    public static final Integer ADD_ORDER_CODE = 1;//addOrder
    public static final Integer FREE_ORDER_CODE = 5;//freeOrder
    public static final Integer DELETE_ORDER_CODE = 4;//deleteOrder
    public static final Integer REVOKE_ORDER_CODE = 6;//revokeOrder
    public static final Integer WAIT_PAY_CODE = 2;//waitPay
    public static final Integer INSERT_OAS_CODE = 3;//inserOrderAndStock
    public static final Integer PAY_ORDER_CODE = 7;//payOrder
    public static final Integer CAST_ORDER_CODE = 8;//castOrder
    public static final Integer FREETOPAID_ORDER_CODE = 9;//freeToPaid
    public static final Integer FREETOPAID_STOCK_CODE = 10;//freeToPaid
    public static final Integer FREETOWAITPAY_ORDER_CODE = 11;//freeToPaid
    public static final Integer FREETOWAITPAY_STOCK_CODE = 12;//freeToPaid


}
