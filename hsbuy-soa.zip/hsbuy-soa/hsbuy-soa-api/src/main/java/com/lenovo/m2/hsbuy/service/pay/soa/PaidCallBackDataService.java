package com.lenovo.m2.hsbuy.service.pay.soa;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.outpay.PaidCallBackData;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * Created by tianchuyang on 2017/6/5.
 */
public interface PaidCallBackDataService {


    /**
     * 获取数据
     * @param paidCallBackData
     * @return
     */
    RemoteResult<List<PaidCallBackData>> findPaidCallBackDataList(PaidCallBackData paidCallBackData);

    /**
     * 回调失败添加至 paid_call_back_data表
     * @param paidCallBackData
     * @return
     */
    RemoteResult<String> addPaidCallBackData(PaidCallBackData paidCallBackData);

    /**
     * 回调结果更新 paid_call_back_data表
     * @param paidCallBackData
     * @return
     */
    RemoteResult<String> updatePaidCallBackData(PaidCallBackData paidCallBackData);

    /**
     * 数据从 paid_call_back_data表中删除
     * @param paidCallBackData
     * @return
     */
    RemoteResult<String> deletePaidCallBackData(PaidCallBackData paidCallBackData);

    /**
     * @author tiancy4
     *
     * @param remoteResult 通知订单结果
     * @param shopId 租户
     * @param faId 商户标识
     * @param outTradeNo 商户订单号
     * @param tradeNo 支付流水号
     * @param transactionNo 渠道流水号
     * @param payChannelCode 渠道编码
     * @param amount 订单支付金额
     * @param orderStatus 订单状态 1有效 0无效
     * @param tradeStatus 交易状态 1有效 0无效
     * @param notifyStatus 通知状态 1有效 0无效
     * @param notifyCount 通知次数
     * @param remark 备注信息
     * @param orderCreateTime 订单创建时间
     * @param payTime 支付时间
     * @param notifyTime 通知时间
     * @param extendParam 拓展参数
     * @return
     */
    RemoteResult<String> handleCallBackData(RemoteResult<String> remoteResult, String shopId, String faId, String outTradeNo, String tradeNo, String transactionNo, String payChannelCode,
                                            BigDecimal amount, Integer orderStatus, Integer tradeStatus, Integer notifyStatus, Integer notifyCount, String remark, Date orderCreateTime, Date payTime, Date notifyTime, String extendParam);
}
