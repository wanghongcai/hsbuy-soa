package com.lenovo.m2.hsbuy.integral;


import com.lenovo.m2.hsbuy.domain.integral.IntegralReward;

/**
 * Created by admin on 2017/10/31.
 * 惠商积分奖励服务
 */
public interface IntegralRewardService {

    //惠商奖励积分接口
    public void hsIntegralReward(IntegralReward integralReward);

    //根据id删除积分奖励记录
    public int deleteIntegralReward(Long id);

    //根据记录id修改发放状态
    public int updateStatusById(IntegralReward integralReward);

}
