package com.lenovo.m2.hsbuy.service.pay.cancel;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;

/**
 * 支付宝取消接口
 * Created by MengQiang on 2016/8/1.
 */
public interface AliPayCancelService {
    /**
     * 支付宝取消交易
     * @param payOrder payOrder
     * @return RemoteResult
     */
    public RemoteResult<String> aliPayTradeCancel(PayOrder payOrder);
}
