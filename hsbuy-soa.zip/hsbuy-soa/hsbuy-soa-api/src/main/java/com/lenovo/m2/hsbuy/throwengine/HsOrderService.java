package com.lenovo.m2.hsbuy.throwengine;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.order.OrderItem;
import com.lenovo.m2.hsbuy.domain.throwengine.OrderItemHSVo;

import java.util.List;

/**
 * 惠商订单
 *
 * @Author licy13
 * @Date 2017/6/6
 */

public interface HsOrderService {

    /**
     * 根据订单号获取抛单商品信息
     *
     * @param orderId
     * @return
     */
    RemoteResult<List<OrderItem>> getOrderItemsByOrderId(Long orderId);

    /**
     * 保存库存地信息并发货
     *
     * @param orderItemHSVo
     * @return
     */
    RemoteResult saveItemsWareHouseAndOrder(OrderItemHSVo orderItemHSVo);


    /**
     * 保存库存地信息
     *
     * @param orderItemHSVos
     * @return
     */
    RemoteResult saveItemsWareHouse(List<OrderItemHSVo> orderItemHSVos);


}
