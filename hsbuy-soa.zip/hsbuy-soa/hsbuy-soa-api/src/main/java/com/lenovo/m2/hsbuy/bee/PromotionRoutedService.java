package com.lenovo.m2.hsbuy.bee;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.bee.PromotionInfo;
import com.lenovo.m2.hsbuy.domain.ordercenter.BeeOrderApi;

import java.util.List;
import java.util.Map;

/**
 * Created by yezhenyue on 2016/11/14.
 */
public interface PromotionRoutedService {

    /**
     * 提交订单后收银台将推广信息推送给cps中间件系统处理
     * @param promotionInfo
     * @return
     */
    RemoteResult<Boolean> pushPromotionInfo(PromotionInfo promotionInfo, Tenant tenant);


    /**
     * 根据订单时间获取小蜜蜂订单 StartTime<=订单创建时间<EndTime
     * @param pageQuery
     * @param map
     * @return
     */
    RemoteResult<PageModel2<BeeOrderApi>> getBeeOrdersByOrderTime(PageQuery pageQuery, Map map);


}
