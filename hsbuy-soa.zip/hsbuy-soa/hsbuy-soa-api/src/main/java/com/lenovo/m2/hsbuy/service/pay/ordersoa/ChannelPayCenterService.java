package com.lenovo.m2.hsbuy.service.pay.ordersoa;


import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.pay.soa.ChannelOrder;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.baseInfo.OrderTrace;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.baseInfo.OrderVo;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.baseInfo.PayAccountVo;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.wxpay.ChannelOrderInfo;
import com.lenovo.m2.hsbuy.domain.pay.soa.RefundOrder;

import java.util.List;
import java.util.Map;

/**
 * Created by zhangxs
 */
public interface ChannelPayCenterService {
    /**
     * 根据 主单号集合查询 订单支付数据
     * @param orderMainCodeList  主单号集合
     * @param shopId 门店
     * @param terminal 终端
     * @param lenovoId userid
     * pay-order-front 调用
     * @return
     */
     RemoteResult<List<OrderVo>> queryOrderMainDetail(List<String> orderMainCodeList, String shopId, String terminal, String lenovoId);

    /**
     *  支付完成回调接口
     * @param tenant
     * @param outTradeNo 订单号
     * @param lenovoId
     * @param payAccountVo 支付实体
     * pay-soa 调用
     * @return
     */
     RemoteResult<String> updateChannelOrderPayStatus(Tenant tenant, String outTradeNo, String lenovoId, PayAccountVo payAccountVo, String orderType, boolean isOutMerchant);

    /**
     * 退款查询接口
     * @param refundOrder lenovoId refundNo refundMoney  shopId terminal refundTime
     * @param channelOrder orderMainCode isMain orderCode payMoney lenovoId
     * @param more
     * 订单调用
     * @return
     */
    RemoteResult<Boolean> queryRefundOrderDetail(RefundOrder refundOrder, ChannelOrder channelOrder, ChannelOrder more, Tenant tenant);




    /**
     * 更新订单状态  取消订单,国际化
     * pay-order-front 调用
     * @return
     *  正在使用
     */
     RemoteResult<String> updateOrderStatusByOrderCancel(String orderCode, Tenant tenant, String lenovoId);


    /**
     * 订单编辑 服务于扫单取消修改
     * 暂时未开发
     * 待确定是否正常使用？
     * @param param mainFlag 0/1 orderCode 1 payStatus 0/1/null orderStatus 0/1/null transationId
     */
     RemoteResult<PageModel2<ChannelOrderInfo>> queryChannelOrderPage(PageQuery pageQuery, Map param);
    /**
     * 订单编辑 服务于扫单取消修改
     * 暂时未开发
     * 待确定是否正常使用？
     * @param param orderCode  payStatus 0/1/null orderStatus 0/1/null transationId
     */
     RemoteResult<PageModel2<OrderTrace>> queryOrderTracePage(PageQuery pageQuery, Map param);

    RemoteResult<String> callPCSDOrderPaidCallBack(Tenant tenant, String outTradeNo, String lenovoId, PayAccountVo payAccountVo, String orderType);

    /**
     * 回调订单
     */
    RemoteResult<String> callOrderPaidCallBack(Tenant tenant, String outTradeNo, String lenovoId, PayAccountVo payAccountVo);

    /**
     * 手动回调
     */
    RemoteResult<String> callOrderPaidCallBackByManualHandle(Tenant tenant, String outTradeNo, String lenovoId, PayAccountVo payAccountVo);
}
