package com.lenovo.m2.hsbuy.inventory.constants;

/**
 * Created by mayan3 on 2016/4/9.
 */
public class ErrorUtils {
    public static final String ERR_NOT_ALLOWED="2000";
    public static final String SUCCESS="1000";
    public static final String ERR_SYSTEM_EXCEPTION="10000";

    // 系统异常错误
    public static final String SYSTEM_UNKNOWN_EXCEPTION = "10001";
    // 必填的参数错误
    public static final String ERR_CODE_COM_REQURIE = "10002";

    // 无此门店信息
    public static final String ERR_CODE_NOT_EXIST_STORE = "30001";
}
