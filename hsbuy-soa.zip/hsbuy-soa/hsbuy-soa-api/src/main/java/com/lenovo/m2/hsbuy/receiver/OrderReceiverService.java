package com.lenovo.m2.hsbuy.receiver;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.receiver.SaveOrderInfoParam;
import com.lenovo.m2.hsbuy.domain.receiver.GetOrderByOrderNumberResult;
import com.lenovo.m2.hsbuy.domain.receiver.SaveOrderInfoResult;
import com.lenovo.m2.hsbuy.domain.receiver.OrderInfoEntity;
import com.lenovo.m2.hsbuy.domain.receiver.SaveOrderResult;

/**
 * 
* @ClassName: OrderReceiverService 
* @Description: 接单接口，提供dubbo 调用服务
* @author yuzj7@lenovo.com 
* @date 2015年11月12日 下午12:18:44 
*
 */
public interface OrderReceiverService {
	/**
	 * 
	* @Title: saveOrderInfo 
	* @Description: 保存订单信息 
	* @param entity
	* @return    设定文件
	 */
	@Deprecated
	public SaveOrderResult saveOrderInfo(OrderInfoEntity entity);
	/**
	 * 
	* @Title: saveOrderInfo
	* @Description: 重载接口多住户实现
	* @param tenant
	* @param saveOrderInfoVo
	* @return    设定文件
	* @throws
	 */
	public RemoteResult<SaveOrderInfoResult> saveOrderInfo(Tenant tenant, SaveOrderInfoParam saveOrderInfoVo);
	/**
	 * 
	* @Title: getOrderByOrderNumber
	* @Description: 根据订单号获取订单，监控用
	* @param ordernum
	* @return    设定文件
	* @throws
	 */
	public RemoteResult<GetOrderByOrderNumberResult> getOrderByOrderNumber(Long ordernum);
}
