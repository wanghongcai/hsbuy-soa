package com.lenovo.m2.hsbuy.address;

import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.address.AddressLog;
import com.lenovo.m2.hsbuy.domain.address.Memberaddrs;
import com.lenovo.m2.hsbuy.domain.address.param.ConsigneeAddressParam;
import com.lenovo.m2.hsbuy.domain.address.param.ConsigneeParam;

import java.util.List;

/**
 * Created by admin on 2017/7/25.
 * 用户地址服务
 */
public interface AddressService {

    /**
     * 保存收货地址
     * @param tenant
     * @param consigneeAddressParam
     * @return
     */
    public RemoteResult<String> saveAddress(Tenant tenant, ConsigneeAddressParam consigneeAddressParam);

    /**
     * 更新收货人地址
     * @param tenant
     * @param consigneeAddressParam
     * @return
     */
    public RemoteResult<Integer> updateAddress(Tenant tenant, ConsigneeAddressParam consigneeAddressParam);

    /**
     * 通过地址 ID 删除地址
     * @param tenant
     * @param consigneeParam
     * @return
     */
    public RemoteResult<Integer> deleteAddress(Tenant tenant, ConsigneeParam consigneeParam);

    /**
     * 通过用户ID和地址ID，获取收货地址信息
     * @param tenant
     * @param consigneeParam
     * @return
     */
    public RemoteResult<Memberaddrs> getAddressById(Tenant tenant, ConsigneeParam consigneeParam);

    /**
     * 通过用户ID获取首选收货地址信息
     * @param tenant
     * @param consigneeParam(不包含Id)
     * @return
     */
    public RemoteResult<Memberaddrs> getPreferredAddress(Tenant tenant, ConsigneeParam consigneeParam);

    /**
     * 根据用户ID，获取收货人该租户所有收货地址信息
     * @param tenant
     * @param consigneeParam(不包含Id)
     * @return
     */
    public RemoteResult<List<Memberaddrs>> getAddressListByUser(Tenant tenant, ConsigneeParam consigneeParam);

    /**
     * 个人中心获取用户地址总条数
     * @param tenant
     * @param consigneeParam
     * @return
     */
    public RemoteResult<Integer> getAddressCount(Tenant tenant, ConsigneeParam consigneeParam);

    /**
     * 个人中心获取分页数据
     * @param tenant
     * @param consigneeParam(不包含Id)
     * @param pageQuery
     * @return
     */
    public RemoteResult<List<Memberaddrs>> getAddressListByPage(Tenant tenant, ConsigneeParam consigneeParam, PageQuery pageQuery);

    /**
     * 设置默认收货地址
     * @param tenant
     * @param consigneeParam
     * @return
     */
    public RemoteResult<Boolean> setDefaultAddress(Tenant tenant, ConsigneeParam consigneeParam);

    /**
     * 查询smb未同步地址信息
     * @param tenant
     * @param count
     * @return
     */
    public RemoteResult<List<AddressLog>> getNotSyncAddress(Tenant tenant, Integer count);

    /**
     * 根据地址ID获取guid，smb商城使用
     * @param id
     * @return
     */
    public RemoteResult<String> getGuidById(Tenant tenant, String id);

    /**
     * 根据guid获取地址ID，smb商城使用
     * @param guid
     * @return
     */
    public RemoteResult<String> getIdByGuid(Tenant tenant, String guid);

}
