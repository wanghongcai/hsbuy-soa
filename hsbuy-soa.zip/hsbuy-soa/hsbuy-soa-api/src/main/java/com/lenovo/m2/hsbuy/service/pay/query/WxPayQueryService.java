package com.lenovo.m2.hsbuy.service.pay.query;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.RefundOrderInfo;

/**
 * 退款查询接口
 * Created by luyang on 2016/3/14.
 */
public interface WxPayQueryService {
    public RemoteResult<String> WxPayQuery(RefundOrderInfo refundOrderInfo, MerchantPayPlatView merchantPayPlatView);
}
