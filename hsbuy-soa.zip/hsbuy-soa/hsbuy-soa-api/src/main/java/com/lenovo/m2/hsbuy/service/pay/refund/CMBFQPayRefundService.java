package com.lenovo.m2.hsbuy.service.pay.refund;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.RefundOrderInfo;;


/**
 * 招行分期支付退款接口
 * Created by tianchuyang on 2016/12/19.
 */
public interface CMBFQPayRefundService {


    RemoteResult<String> cmbfqRefund(RefundOrderInfo refundOrderInfo, MerchantPayPlatView merchantPayPlatView);


    boolean logout(String connection);
}
