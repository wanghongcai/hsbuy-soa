package com.lenovo.m2.hsbuy.pricelist;


import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.api.param.pricelist.ManualOrderParam;
import com.lenovo.m2.hsbuy.api.param.pricelist.PriceListParam;
import com.lenovo.m2.hsbuy.domain.pricelist.ManualOrderVo;
import com.lenovo.m2.hsbuy.domain.pricelist.PriceList;

import java.util.List;
import java.util.Map;

/**
 * Created by syj on 2016/7/21.
 */
public interface PriceListService {

    /**
     * 获取报价单列表
     * @param pageQuery
     * @param priceList
     * @return
     */
    public RemoteResult<PageModel2<PriceList>> getPriceListPage(PageQuery pageQuery, PriceList priceList);

    /**
     * 获取报价单详情
     * @param priceList
     * @return
     */
    public RemoteResult<PriceList> getPriceListDetail(PriceList priceList);

    /**
     * 新增报价单
     * @param priceList
     * @return
     */
    public RemoteResult<String> insertPriceList(PriceList priceList);

  
    
    
    
    /**
     * 生成手工订单， 返回订单号
     * @param manualOrderVo
     * @return
     */
    public RemoteResult<Map> genManualOrder(ManualOrderVo manualOrderVo);

    /**
     * 报价单提交定单
     * @param pl
     * @return
     */
    public RemoteResult<Boolean> submitPriceList(PriceList pl);

    
    /**
     * 拉取已下单的报价单号
     * @return
     */
    public RemoteResult<String> pullOrderedDealNo();
    
    
    /**
     * 更新为已下单
     * @param itCode
     * @param dealNo
     * @return
     */
	public RemoteResult<Integer> updateToOrdered(String userId, String dealNo);

	/**
	 * 查询报价单PdfUrl
	 * @param itCode
	 * @param userId
	 * @param dealNo
	 * @return
	 */
	public RemoteResult<String> queryPdfUrl(String itCode, String userId, String dealNo, List<String> showParam);

/***********************************国际化********************************************************/
    /**
     * 获取报价单列表
     * @param tenant
     * @param pageQuery
     * @param priceList
     * @return
     */
    public RemoteResult<PageModel2<PriceList>> getPriceListPage(Tenant tenant, PageQuery pageQuery, PriceListParam priceList);
    /**
     * 获取报价单详情
     * @param tenant
     * @param priceListParam
     * @return
     */
    public RemoteResult<PriceList> getPriceListDetail(Tenant tenant, PriceListParam priceListParam);

    /**
     * 新增报价单
     * @param tenant
     * @param priceListParam
     * @return
     */
    public RemoteResult<String> insertPriceList(Tenant tenant, PriceListParam priceListParam);
    /**
     * 生成手工订单， 返回订单号
     * @param tenant
     * @param manualOrderParam
     * @return
     */
    public RemoteResult<Map> genManualOrder(Tenant tenant, ManualOrderParam manualOrderParam);

    /**
     * 报价单提交定单
     * @param tenant
     * @param priceListParam
     * @return
     */
    public RemoteResult<Boolean> submitPriceList(Tenant tenant, PriceListParam priceListParam);
}
