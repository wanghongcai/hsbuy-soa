package com.lenovo.m2.hsbuy.logistics;

/**
 * worker
 *
 * @author : 朝阳
 * @version : v1.0
 * @email : licy13@lenovo.com
 * @time : 2017/11/28 10:49
 */
public interface HsLogisticsSyncTaskService {

    /**
     * 惠商同步sec物流轨迹
     */
    void hsLogisticsSyncTask();
}
