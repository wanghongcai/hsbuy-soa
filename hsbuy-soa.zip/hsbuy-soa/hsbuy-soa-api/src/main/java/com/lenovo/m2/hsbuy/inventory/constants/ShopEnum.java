package com.lenovo.m2.hsbuy.inventory.constants;


import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;

/**
 * Created by mayan3 on 2016/7/18.
 */
public enum ShopEnum {

    GUANWANG(1), //官网
    Think(2), //Think
    EPP(3),//EPP
    Roaming(4),//Roaming
    MOTO(5),//MOTO
    DONGDE(6),//懂得
    THINKCENTER(7),//Think产品中心
    SMB(8),//SMB
    SMBJF(9),//SMB积分商城
    SMBASK(10),//SMB社区
    PCSD(11),//PCSD商城
    HS(14),//惠商商城
    HSJF(15),//惠商积分
    INR_B2R(16),//印度moto b2r
    INR_POS(17);//印度pos

    // 映射字典表
    private static BiMap<String, Integer> MAPPING_DICT = HashBiMap.create();

    static {
        MAPPING_DICT.put("联想官网", GUANWANG.getValue());
        MAPPING_DICT.put("Think官网", Think.getValue());
        MAPPING_DICT.put("EPP", EPP.getValue());
        MAPPING_DICT.put("Roaming", Roaming.getValue());
        MAPPING_DICT.put("MOTO", MOTO.getValue());
        MAPPING_DICT.put("DONGDE", DONGDE.getValue());
        MAPPING_DICT.put("Think产品中心", THINKCENTER.getValue());
        MAPPING_DICT.put("17商城", SMB.getValue());
        MAPPING_DICT.put("17积分商城", SMBJF.getValue());
        MAPPING_DICT.put("17社区", SMBASK.getValue());
        MAPPING_DICT.put("PCSD", PCSD.getValue());
        MAPPING_DICT.put("惠商", HS.getValue());
        MAPPING_DICT.put("惠商积分", HSJF.getValue());
        MAPPING_DICT.put("India b2r", INR_B2R.getValue());
        MAPPING_DICT.put("India pos", INR_POS.getValue());
    }

    public static String getShopStr(int type) {
        return MAPPING_DICT.inverse().get(type);
    }

    private int value;

    ShopEnum(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }


    @Override
    public String toString() {
        return this.name().toLowerCase();
    }
}
