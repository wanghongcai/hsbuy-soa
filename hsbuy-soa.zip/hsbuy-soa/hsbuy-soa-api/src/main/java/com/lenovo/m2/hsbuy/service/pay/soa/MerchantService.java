package com.lenovo.m2.hsbuy.service.pay.soa;

import com.lenovo.m2.arch.framework.domain.PageModel;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.MerchantInfo;

/**
 * Created by zhanglijun on 2015/6/10.
 */
public interface MerchantService {


    //测试方法
    public MerchantInfo getMerchantInfo(Long id);


    public PageModel<MerchantInfo> getAllMerchantInfo(PageQuery pageQuery);


    public Long insertMerchantInfo(MerchantInfo merchantInfo);


    public int updateMerchantInfo(MerchantInfo merchantInfo);


    public int removeMerchantInfo(Long userId);


}
