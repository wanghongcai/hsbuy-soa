package com.lenovo.m2.hsbuy.middleware;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.middleware.AuditStatusContractParam;
import com.lenovo.m2.hsbuy.domain.middleware.PayAccount;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderItem;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderMain;
import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrderDetail;

import java.util.List;
import java.util.Map;

/**
 * @author : 朝阳
 * @version : v1.0
 * @email : licy13@lenovo.com
 * @time : 2017/11/22 15:55
 */
public interface OrderMiddlewareService {
    /**
     * 计算订单总价和应付金额等
     *
     * @param mOrderItemList
     * @return
     */
    RemoteResult<Map<String, Money>> calculateOrderPrices(MOrderMain mOrderMai, List<MOrderItem> mOrderItemList, Tenant tenant);

    /**
     * 审批惠商订单
     *
     * @param mongoOrder
     * @param pass
     * @param tenant
     * @return
     */
    RemoteResult auditHsOrder(MongoOrderDetail mongoOrder, boolean pass, Tenant tenant);

    /**
     * 合同更新审核状态（签署状态）和合同地址
     * <p>
     * ---如果是全额信用支付，调用支付回调
     *
     * @param auditStatusContractParam
     * @return
     */
    RemoteResult updateAuditStatusByContract(Tenant tenant, AuditStatusContractParam auditStatusContractParam);


    /**
     * 取消订单，供用户主动取消、扫单取消、订单后台管理业务人员取消使用
     *
     * @param shopId
     * @param orderCode
     * @param type      取消类型
     * @return
     */
    RemoteResult cancelOrder(long orderCode, int type, int shopId);

    /**
     * 支付回调
     *
     * @param tenant
     * @param orderCode
     * @param lenovoId
     * @param payAccount
     * @param orderAddType
     * @return
     */
    RemoteResult paidCallback(Tenant tenant, String orderCode, String lenovoId, PayAccount payAccount, int orderAddType) throws Exception;

    /**
     * 支付获取smb地址
     *
     * @param lenovoId
     * @param orderCode
     * @param tenant
     * @return
     */
    RemoteResult<Map<String, Object>> receiveAddress(String lenovoId, List<String> orderCode, Tenant tenant);

    /**
     * 支付获取smb地址
     *
     * @param lenovoId
     * @param orderCodeList
     * @param shopId
     * @param signature
     * @return
     */
    RemoteResult<Map<String, Object>> receiveAddress(String lenovoId, List<String> orderCodeList, String shopId, String signature);


    RemoteResult bogusPay(String orderCode);

    /**
     * 手动弥补积分奖励
     * @param orderId
     * @return
     */
    Boolean rewardScoreSMBTest(String orderId);
}
