package com.lenovo.m2.hsbuy.smb17;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.smb17.InvoiceIdAndUuid;
import com.lenovo.m2.hsbuy.domain.smb17.InvoiceShop;
import com.lenovo.m2.hsbuy.domain.smb17.InvoiceShopModifyLog;

import java.util.List;

/**
 * 17增票
 * Created by xuweihua on 2016/7/27.
 */
public interface InvoiceShopApiService {
    RemoteResult<InvoiceIdAndUuid> synInvoice(InvoiceShop invoiceShop)  throws Exception ;

    RemoteResult<List<InvoiceShop>> queryInvoice(String lenovoid);

    RemoteResult<InvoiceShop> queryInvoiceForId(String id, String lenovoid);

    RemoteResult modifyePersonalCenter(InvoiceShop invoiceShop) throws Exception;

    RemoteResult<InvoiceShop> queryInvoiceAuditForId(String id);

}
