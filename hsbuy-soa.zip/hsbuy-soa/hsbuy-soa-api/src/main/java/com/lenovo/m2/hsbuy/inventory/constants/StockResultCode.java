package com.lenovo.m2.hsbuy.inventory.constants;

/**
 * Created by Jiazy on 15-6-28.
 */
public class StockResultCode {

    /**
     * 操作成功
     */
    public final static String STOCK_SUCCESS = "1000";

    /**
     * /库存不存在
     */
    public final static String STOCK_NOTHINH = "1001";

    /**
     * 存在多条库存
     */
    public final static String STOCK_MORE = "1002";

    //参数有误
    public final static String STOCK_EMPTY = "1003";

    //库存数量不满足
    public final static String STOCK_SHORT = "1004";

    /**
     * 操作条件不满足
     */
    public final static String STOCK_NOT_MEET = "1005";

    //库存操作超时
    public final static String STOCK_OUT_TIME = "1006";
    /**
     * 库存操作失败
     */
    public final static String STOCK_FAIL = "1007";
    /**
     * 重复操作
     */
    public final static String STOCK_REPEAT = "1008";
    /**
     * 超出库存上限
     */
    public final static String STOCK_EXCEED = "1009";

    /**
     * 订单状态无效
     */
    public final static String ORDER_STATE_INVALID = "1009";
    /**
     * 订单重复提交
     */
    public final static String ORDER_SUBMIT_REPEAT = "1010";

    /**
     * 地址查询为空
     */
    public final static String FIND_ADDRESS_NULL = "1011";

    /**
     * 地址查询异常
     */
    public final static String ADDRESS_ERROR = "1012";
    /**
     * 无此库存地信息
     */
    public final static String FIND_WAREHOUSE_NULL = "1013";
    /**
     * 库存地信息已经存在
     */
    public final static String FIND_WAREHOUSE_EXIST = "1014";


    //库存发生异常
    public final static String STOCK_ERROR = "9999";

    /**
     * 大平台库存已经存在
     */
    public final static String FIND_STOCK_EXIST = "1015";
    /**
     * redis key 不存在
     */
    public final static String REDIS_KEY_NOT_EXIST = "1016";
    /**
     * redis 操作发生异常
     */
    public final static String REDIS_ERROR = "1017";
    /**
     * 获取FA信息失败
     */
    public final static String FA_INFO_ERROR = "1018";
    /**
     * 库存处于上架状态
     */
    public final static String STOCK_ON_SALE = "1019";
    /**
     * 库存存在占用订单
     */
    public final static String STOCK_EXIST_UNPAID_ORDER = "1020";
    /**
     * 库存存在冻结订单
     */
    public final static String STOCK_EXIST_PAID_ORDER = "1021";
    /**
     * 库存可售数不为零
     */
    public final static String STOCK_SALES_NUMBER_NOT_ZERO = "1022";
}
