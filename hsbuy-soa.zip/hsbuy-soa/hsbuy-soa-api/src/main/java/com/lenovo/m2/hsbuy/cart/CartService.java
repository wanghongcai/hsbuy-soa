package com.lenovo.m2.hsbuy.cart;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.cart.*;

import java.util.List;

/**
 * @author wangrq1
 * @create 2017-07-17 下午7:47
 **/
public interface CartService {

	/**
	 * 添加
	 * @param tenant 租户
	 * @param entity
	 * @return
	 */
    RemoteResult<CartNG> addItemToCart(Tenant tenant, AddToCartEntity entity);

    /**
     * 删除
     * @param tenant 租户
     * @param entity
     * @return
     */
    RemoteResult<CartNG> delItemByIds(Tenant tenant, DelItemEntity entity);

    /**
     * 清空用户购物车
     * @param tenant
     * @param entity
     * @return
     */
    RemoteResult emptyCart(Tenant tenant,EmptyCartEntity entity);

    /**
     * 得到购物车数量
     * @param tenant 租户
     * @param entity
     * @return
     */
    RemoteResult<Integer> getCartCount(Tenant tenant,GetCartCountEntity entity);

    /**
     * 修改购物车行数量
     * @param tenant
     * @param entity
     * @return
     */
    RemoteResult<CartNG> modifyCarItemNum(Tenant tenant,ModifyItemNumEntity entity) throws Exception;

    /**
     * 更新购物车行服务
     * @param tenant 租户
     * @param entity
     * @return
     */
    RemoteResult<CartNG> updateItemService(Tenant tenant,UpdateItemServiceEntity entity);

    /**
     * 删除服务
     * @param tenant 租户
     * @param entity
     * @return
     */
    RemoteResult<CartNG> deleteItemService(Tenant tenant,DelItemServiceEntity entity);

    /**
     * 勾选/勾掉 购物行
     * @param tenant
     * @param entity
     * @return
     */
    RemoteResult<CartNG> activeItem(Tenant tenant,ActiveItemEntity entity);

    /**
     * 查询主品关联的服务列表
     * @param tenant
     * @param entity
     * @return
     */
    RemoteResult<List<ServiceProductView>> getServiceListByGcode(Tenant tenant, GetGoodServiceEntity entity);

    /**
     * 获取购物车
     * @param tenant
     * @param entity
     * @return
     */
    RemoteResult<CartNG> getCart(Tenant tenant,GetCartNGEntity entity);

    /**
     * 立即购买
     * @param tenant
     * @param entity
     * @return
     */
    RemoteResult<String> directBuy(Tenant tenant, AddToCartEntity entity);

    /**
     * 全选或者全不选
     * @param tenant
     * @param entity
     * @return
     */
    RemoteResult<CartNG> checkedAllOnOff(Tenant tenant,ActiveItemEntity entity);

}
