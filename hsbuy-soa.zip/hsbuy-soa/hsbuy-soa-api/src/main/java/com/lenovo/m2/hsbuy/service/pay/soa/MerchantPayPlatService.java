package com.lenovo.m2.hsbuy.service.pay.soa;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.FakeRule;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.MerchantPayPlat;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.OrderSupportPayType;

import java.util.List;
import java.util.Map;

/**
 * Created by yangjj7 on 2015/5/1.
 */
public interface MerchantPayPlatService {

    /**
     * 查询商户与三方支付平台
     * @param merchantId
     * @param payType
     * @return
     */
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatByMerchantId(String merchantId, int payType);

    RemoteResult<MerchantPayPlatView> getMerchantPayPlatByAccountType(String faid, int payType, Integer accountType);

    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatForWeChat(String merchantId, int payType, String shopId);

    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatById(long merchantId);


    //测试方法


    public RemoteResult getMerchantPayPlatAll(PageQuery pageQuery);

    public RemoteResult insertMerchantPayPlat(MerchantPayPlat merchantPayPlat);


    /**
     *
     * @param merchId
     * @return
     */
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatByMerchId(String merchId);
    public RemoteResult<List<MerchantPayPlatView>> getMerchantPayPlatsByMerchantId(String merchId);
//获取所有MerchantPayPlat
    public RemoteResult<List<MerchantPayPlatView>> getMerchantPayPlatAll();

    /**
     * Create For Cashier
     * 根据FAID获取支持支付类型
     * @param FAID
     * @return
     */
    public RemoteResult<List<OrderSupportPayType>> getOrderSupportPayTypeList(String FAID);

    /**
     * 获取订单支持支付方式
     * @param faId
     * @param payTypeList
     * @return
     */
    public RemoteResult<List<OrderSupportPayType>> getOrderSupportPayTypeListByFaIDPayment(String faId, List<Integer> payTypeList);

    /**
     * 条件查询分页
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<MerchantPayPlat>> getPayPlatPage(PageQuery pageQuery, Map map);

    /**
     * 选择性插入
     * @param mpp
     * @return
     */
    public RemoteResult<Integer> insertSelective(MerchantPayPlat mpp);

    /**
     * 选择性修改
     * @param map
     * @return
     */
    public RemoteResult<Integer> updateSelective(Map map);

    /**
     * 批量删除
     * @param map
     * @return
     */
    public RemoteResult<Integer> delsome(Map map);

    /**
     * 查询所有FA支持的支付方式
     * @return
     */
    public RemoteResult<List<FakeRule>> getMerchantPayPlatByGroupBy();


    RemoteResult<Integer> updateMerchantPayPlatById(MerchantPayPlat merchantPayPlat);


}