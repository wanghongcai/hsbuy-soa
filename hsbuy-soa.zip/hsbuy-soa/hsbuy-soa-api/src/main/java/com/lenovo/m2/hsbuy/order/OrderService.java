package com.lenovo.m2.hsbuy.order;

import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrder;
import com.lenovo.m2.hsbuy.domain.order.orderInfo.OrderInfo;

import java.util.List;
import java.util.Map;

/**
 * Created by zhaocl1 on 2017/11/21.
 */
public interface OrderService {

    /**
     * 一拆
     * @param orderId
     */
    void syncFirstOrder(Long orderId,OrderInfo orderInfo);

    /**
     * 二拆
     * @param orderId
     */
    void processSecondOrder(Long orderId);

    /**
     * 二拆（修改17无法发货bug刷单专用，业务逻辑不要使用）
     * @param orderId
     */
    void processSecondOrderByTest(Long orderId);

    /**
     * 二拆（修改小蜜蜂未匹配bug刷单专用，业务逻辑不要使用）
     * @param orderId
     */
    void processSecondOrderByTest2(Long orderId);

    /**
     * 发送订单信息给CPS
     * @param tenant
     * @param orderNum
     * @return
     */
    RemoteResult<String> sendOrderInfoToCPS(Tenant tenant, Long orderNum);

    /**
     * 根据查询条件提供给CPS订单信息
     * @param cid
     * @param orderStartTime
     * @param orderEndTime
     * @return
     */
    String getOrderByOrderParams(String cid, String orderStartTime, String orderEndTime);

    /**
     * 根据查询条件导出CPS订单信息
     * @param cid
     * @param orderStartTime
     * @param orderEndTime
     * @return
     */
    String getImportOrderByOrderParams(String cid, String orderNo, String orderStartTime, String orderEndTime);

    /**
     * 分页查询订单信息（含子类信息）
     * @param cid
     * @param orderStartTime
     * @param orderEndTime
     * @param pageQuery
     * @return
     */
    RemoteResult<Map<String,Object>> getCpsOrderByOrderParams(String cid, String orderNo, String orderStartTime, String orderEndTime, PageQuery pageQuery);
}
