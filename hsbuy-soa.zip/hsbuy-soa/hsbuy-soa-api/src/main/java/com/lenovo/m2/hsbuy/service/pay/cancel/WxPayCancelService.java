package com.lenovo.m2.hsbuy.service.pay.cancel;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;

/**
 * 微信关闭订单
 * Created by qixin7 on 2017/6/21.
 */
public interface WxPayCancelService {
    /**
     * 微信取消交易
     * @param payOrder
     * @return
     */
    public RemoteResult<String> wxPayTradeCancel(PayOrder payOrder);
}
