package com.lenovo.m2.hsbuy.bee;

import com.alibaba.fastjson.JSONArray;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.bee.PromotionOrder;

/**
 * Created by yezhenyue on 2016/11/7.
 */
public interface CpsOrderService {


    /**
     * 订单有二拆，本地更新同时推送第三方和c2c
     * @param order
     * @param subOrderCodes
     */
    RemoteResult splitPromotionOrder(PromotionOrder order, JSONArray subOrderCodes);

    /**
     * 订单没拆，本地更新，同时推送第三方和c2c
     * @param order
     */
    RemoteResult payPromotionOrder(PromotionOrder order);

    /**
     * 订单退款
     * @param order
     * @return
     */
    RemoteResult refundPromotionOrder(PromotionOrder order);

    /**
     * 订单签收
     * @param order
     * @return
     */
    RemoteResult signPromotionOrder(PromotionOrder order);
    /**
     * 根据订单号查询推广订单
     * @param orderCode
     * @return
     */
    PromotionOrder getPromotionOrderByOrderCode(String orderCode);

}
