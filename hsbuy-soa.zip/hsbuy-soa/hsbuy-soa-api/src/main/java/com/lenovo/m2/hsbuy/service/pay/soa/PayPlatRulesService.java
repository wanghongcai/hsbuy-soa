package com.lenovo.m2.hsbuy.service.pay.soa;


import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.*;

import java.util.List;
import java.util.Map;

/**
 * Created by yinxu on 2015/10/29
 */
public interface PayPlatRulesService {


    /**
     * 更新支付规则主表接口
     * @param map
     * @return
     */
    public RemoteResult<Boolean> updatePayPlatRules(Map map);

    /**
     * 删除支付规则主表接口
     * @param map
     * @return
     */
    public RemoteResult<Boolean> deletePayPlatRules(Map map);

    /**
     * 删除排除商品表接口
     * @param map
     * @return
     */
    public RemoteResult<Boolean> deletePlatRulesExclude(Map map);

    /**
     * 更新支付规则副表接口
     * @param map
     * @return
     */
    public RemoteResult<Boolean> updatePayPlatRuleItem(Map map);

    /**
     * 删除支付规则副表接口
     * @param map
     * @return
     */
    public RemoteResult<Boolean> deletePayPlatRuleItem(Map map);


    /**
     * 假删除规则
     * @param ruleItemMap
     * @param payRuleMap
     * @return
     */
    public RemoteResult<Boolean> deletePayPlatRuleItemAndRules(Map ruleItemMap, Map payRuleMap);


    /**
     * 更新排除商品表接口
     * @param map
     * @return
     */
    public RemoteResult<Boolean> updatePayPlatRuleItemEx(Map map);

}
