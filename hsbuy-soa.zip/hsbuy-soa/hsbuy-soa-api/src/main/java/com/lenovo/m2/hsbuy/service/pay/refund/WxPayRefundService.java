package com.lenovo.m2.hsbuy.service.pay.refund;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.RefundOrderInfo;

/**
 * 微信退货接口
 * Created by luyang on 2016/3/9.
 */
public interface WxPayRefundService {

    public RemoteResult<String> WxPayRefund(RefundOrderInfo payOrderInfo, MerchantPayPlatView merchantPayPlatView);
}
