package com.lenovo.m2.hsbuy.address;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.address.PartAddress;
import com.lenovo.m2.hsbuy.domain.address.param.ProvinceParam;
import java.util.List;

/**
 * Created by admin on 2017/7/31.
 * 区域地址服务
 */
public interface AreaAddressService {

    /**
     * 获取省份列表
     * @param tenant
     * @return
     */
    public RemoteResult<List<PartAddress>> getProvinceList(Tenant tenant);

    /**
     * 根据省获取城市列表
     * @param tenant
     * @param provinceParam
     * @return
     */
    public RemoteResult<List<PartAddress>> getCityList(Tenant tenant, ProvinceParam provinceParam);

    /**
     * 根据省跟市获取区县列表
     * @param tenant
     * @param provinceParam
     * @return
     */
    public RemoteResult<List<PartAddress>> getCountyList(Tenant tenant, ProvinceParam provinceParam);

    /**
     * 根据省市区县获取乡镇列表，只有smb收货地址需要
     * @param tenant
     * @param provinceParam
     * @return
     */
    public RemoteResult<List<PartAddress>> getTownshipList(Tenant tenant, ProvinceParam provinceParam);

    /**
     * 根据省名称获取省编码，目前只有smb需要
     * @param tenant
     * @param provinceParam
     * @return
     */
    public RemoteResult<String> getProvinceNo(Tenant tenant, ProvinceParam provinceParam);

    /**
     * 获取市邮编，目前只有smb需要
     * @param tenant
     * @param provinceParam
     * @return
     */
    public RemoteResult<String> getZip(Tenant tenant, ProvinceParam provinceParam);

    /**
     * 根据省，市，区县，乡镇获取addressId，目前只有smb需要
     * @param tenant
     * @param provinceParam
     * @return
     */
    public RemoteResult<String> getAddressId(Tenant tenant, ProvinceParam provinceParam);

    /**
     * 惠商抛单前，创建sec地址，获取sec地址ID
     * @param tenant
     * @param faCode
     * @param lenovoId
     * @param addressId
     * @return
     */
    public RemoteResult<String> getSecAddressId(Tenant tenant, String faCode, String lenovoId, String addressId);

}
