package com.lenovo.m2.hsbuy.service.pay.soa;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.outpay.PayChannelBank;

import java.util.List;

/**
 * Created by tianchuyang on 2017/1/13.
 */
public interface PayChannelBankService {

    RemoteResult<PayChannelBank> queryPayChannelBanksByParams(Integer payplatId, Integer bankCode, Integer bankType, Integer cardType);

    RemoteResult<List<PayChannelBank>> queryPayChannelBanksByParams(PayChannelBank payChannelBank);

    RemoteResult<List<PayChannelBank>> queryAllPayChannelBanks();
}
