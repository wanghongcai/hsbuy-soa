package com.lenovo.m2.hsbuy.ordercenter;

import com.lenovo.m2.arch.framework.domain.*;
import com.lenovo.m2.hsbuy.domain.order.OrderMain;
import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrderDetail;
import com.lenovo.m2.hsbuy.domain.order.mongo.PayRecords;
import com.lenovo.m2.hsbuy.domain.ordercenter.*;
import org.springframework.data.mongodb.core.query.Query;

import java.util.Map;

/**
 * Created by lzg on 2017/10/12.
 */
public interface OpenOrderService {

    /**
     * 获取订单列表
     *
     * @param plat
     * @param query
     * @param pageQuery
     * @return
     */
    public RemoteResult getAllMongoOrderList(int plat, Map map, PageQuery pageQuery);

    /**
     * 根据订单号查询订单详情
     *
     * @param tenant
     * @param orderCode
     * @return
     */
    public RemoteResult<MongoOrderDetail> getMongoOrderDetail(Tenant tenant, String orderCode);


    /**
     * 订单统计
     */
    public RemoteResult<OrderCount> getOrderCont(int shopId, String lenovoId);

    /**
     * 根据条件查询订单列表
     */
    public RemoteResult<PageModel2<MongoOrderDetail>> getMongoOrderListByStatus(int shopId, String lenovoId, String orderStatus, PageQuery pageQuery);


    /**
     * 根据条件查询订单列表
     */
    public RemoteResult<PageModel2<MongoOrderDetail>> getMongoOrderListByTime(int shopId, String lenovoId, String startTime, String endTime, PageQuery pageQuery);

    /**
     * 获取惠商待审核订单（分页）
     *
     * @param pageQuery
     * @param filterMap
     * @param tenant
     * @return
     */
    RemoteResult getMongoOrderList(PageQuery pageQuery, Map<String, Object> filterMap, Tenant tenant);

    /**
     * 组装惠商审单详情页数据
     *
     * @param map    key：orderId
     * @param tenant
     * @return
     */
    RemoteResult<AuditOrderDetailResult> getMongoOrderDetail(Map<String, Object> map, Tenant tenant);

    /**
     * 线下银行转账记录详情
     *
     * @param payId
     * @param tenant
     * @return
     */
    RemoteResult<PayRecordsDetailResult> payRecordsDetail(String payId, Tenant tenant);


    /**
     * 审核付款支付记录
     *
     * @param payRecords
     * @param tenant
     * @return
     */
    RemoteResult auditPaymentPayRecords(PayRecords payRecords, Tenant tenant);


    /**
     * 获取惠商下线支付列表（分页）
     *
     * @param downlinePayParam
     * @return
     */
    RemoteResult<PageModel2<PayRecords>> queryDownlinePayList(DownlinePayListParam downlinePayParam);


    /**
     * @param payRecords
     * @return
     */
    RemoteResult saveMongoPayRecord(PayRecords payRecords);


    /**
     * 确认签收
     *
     * @param orderId
     * @param lenovoId
     * @param tenant
     * @return
     */
    RemoteResult updateOrderConfirm(String orderId, String lenovoId, Tenant tenant);


    /**
     * 更新订单状态
     *
     * @param request
     * @param from
     * @return
     */
    ApiBaseResponse syncOrderStatus(OrderStatusRequest request, int from);


    RemoteResult<OrderMain> getOrderByOrderCode(String orderCode);


    /**
     * 更新uploadStatus
     *
     * @param orderCode
     * @param uploadStatus
     * @return
     */
    RemoteResult updatePayRecordsUploadStatus(String orderCode, String uploadStatus);


//    RemoteResult migrationStatus(int shopId);

    /**
     * 惠商订单报表 查询分页
     * @param pageQuery
     * @param map
     * @param tenant
     * @return
     */
    RemoteResult<PageModel2<HSReportVo>> getOpenHSOrderReportList(PageQuery pageQuery,Map<String,Object> map,Tenant tenant);

    /**
     * 获取惠商订单对账列表（分页）
     * @param pageQuery
     * @param map
     * @param tenant
     * @return
     */
    RemoteResult<PageModel2<OpenHSOrderReconciliationInfo>> getOpenHSOrderReconciliationPage(PageQuery pageQuery, Map<String, Object> map, Tenant tenant);


    /**
     * 分页查询用户订单，供会员中心首页调用
     * @param lenovoId
     * @param shopId
     * @param pageSize
     * @param pageNum
     * @return
     */
    String queryUserOrderPage(String lenovoId,String shopId,int pageSize,int pageNum);


    RemoteResult<HSOrderVo> getHsOrderInfoByOrderCode(long orderCode);


    /**
     * 订单评论完成后，修改订单的评论状态 hasComment 0代表仍有未评价的商品 1代表所有商品已评价
     * @param orderCode
     * @return
     */
    RemoteResult<Boolean> updateOrderComment(String orderCode);



    /**
     * 转移 一拆 支付数据
     *
     * @param mainOrderId
     * @return
     */
    RemoteResult smbPayTransfer(Long mainOrderId);
}
