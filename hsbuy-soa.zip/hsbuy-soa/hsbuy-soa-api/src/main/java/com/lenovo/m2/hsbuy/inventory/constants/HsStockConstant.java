package com.lenovo.m2.hsbuy.inventory.constants;

/**
 * Created by yezhenyue on 2017/2/16.
 */
public class HsStockConstant {
    /*水位库存相应描述*/
    public static final String HS_WATER_LEVEL_ZERO_DESC = "断货";//库存数=0
    public static final String HS_LESS_WATER_LEVEL_DESC = "货源紧张";//库存数0~水位之间
    public static final String HS_GREATER_WATER_LEVEL_DESC = "货源充足";//库存数>水位库存
    /*默认水位库存*/
    public static final int HS_WATER_LEVEL_DEFAULT = 50;

}
