package com.lenovo.m2.hsbuy.service.pay.soa;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.pay.soa.ChannelOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.RefundOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.RefundOrderInfo;

import java.util.Date;
import java.util.List;
import java.util.Map;


/**
 * 退货记录处理
 * Created by MengQiang on 2015/12/24.
 */
public interface RefundOrderService {

    /**
     * 退货处理接口
     * @param refundOrder
     * @param refundChannelOrder
     * @param newChannelOrder
     * @return
     */
    public RemoteResult<String> orderRefund(RefundOrder refundOrder, ChannelOrder refundChannelOrder, ChannelOrder newChannelOrder, Tenant tenant);
    /**
     * 退货处理接口
     * @param refundOrder
     * @param refundOrder
     * @param payPortalOrder
     * @return
     */
    public RemoteResult<String> orderRefund(RefundOrder refundOrder, PayPortalOrder payPortalOrder, Tenant tenant);

    /**
     * 保存退货信息
     * @param refundOrder
     * @return
     */
    public RemoteResult<Long> saveRefundOrder(RefundOrderInfo refundOrder);

    /**
     * 根据退货批次号更新退货记录
     * @param batchNo
     * @param refundState
     * @param refundErrorMsg
     * @param notifyFlag
     * @param updateTime
     * @return
     */
    public RemoteResult<Boolean> updateRefundOrderByBatchNo(String batchNo, int refundState, String refundErrorMsg, int notifyFlag, Date updateTime, Tenant tenant);

    /**
     * 根据退货单号更新退货记录
     * @param refundNo
     * @param refundState
     * @param refundErrorMsg
     * @param notifyFlag
     * @param updateTime
     * @return
     */
    public RemoteResult<Boolean> updateRefundOrderByRefundNo(String refundNo, int refundState, String refundErrorMsg, int notifyFlag, Date updateTime, Tenant tenant);

    /**
     * 根据退货单号查询退货记录
     * @param refundNo
     * @return
     */
    public RemoteResult<RefundOrder> getRefundOrderByeRefundNo(String refundNo);
    /**
     * 根据退货单号查询退货记录
     * @param refundNo
     * @return
     */
    public RemoteResult<List<RefundOrder>> getRefundOrderByRefundNoShopId(String refundNo, Tenant tenant);

    /**
     * 查询所有订单：逆向订单对账用
     *
     * @param param
     * @return
     */
    public RemoteResult<List<RefundOrderInfo>> getRefundOrderByConf(Map param);
}
