package com.lenovo.m2.hsbuy.invoice;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.invoice.VatInvoice;
import com.lenovo.m2.hsbuy.domain.invoice.param.AddVatInvoiceInfoParam;
import com.lenovo.m2.hsbuy.domain.invoice.param.GetCiParam;
import com.lenovo.m2.hsbuy.domain.invoice.param.GetVatInvoiceInfoListParam;
import com.lenovo.m2.hsbuy.domain.invoice.param.GetVatInvoiceInfoParam;
import com.lenovo.m2.hsbuy.domain.invoice.result.ConfigurationInformation;
import com.lenovo.m2.hsbuy.domain.invoice.result.GetVatInvoiceInfoResult;

import java.util.List;

/**
 * 增票管理
 * Created by mayan3 on 2016/6/20.
 */
public interface InvoiceApiService {
    //获取增票信息
    RemoteResult<GetVatInvoiceInfoResult> getVatInvoiceInfo(GetVatInvoiceInfoParam param, Tenant tenant);

    //获取增票信息
    RemoteResult<List<GetVatInvoiceInfoResult>> getVatInvoiceInfo(GetVatInvoiceInfoListParam param, Tenant tenant);

    //添加或修改增票信息
    RemoteResult addVatInvoiceInfo(AddVatInvoiceInfoParam param, Tenant tenant);

    //订单提交校验接口
    RemoteResult checkVatInvoiceInfo(String id, String lenovoId, String region, Tenant tenant);

    RemoteResult queryVatInvoiceInfo(String id);

    RemoteResult<List<VatInvoice>> queryVatInvoiceInfo(List<String> listZid);

    RemoteResult<ConfigurationInformation> getConfigurationInformation(GetCiParam getCiParam, Tenant tenant);

}
