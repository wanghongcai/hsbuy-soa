package com.lenovo.m2.hsbuy.throwengine;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.order.OrderPay;
import com.lenovo.m2.hsbuy.domain.throwengine.OrderMainSmbThrow;

import java.util.List;

/**
 * @Author licy13
 * @Date 2017/7/4
 */

public interface SmbOrderService {

    /**
     * 获取smb待抛单 smb单号
     *
     * @return smb主单号
     */
    RemoteResult<List<String>> getSmbThrowCustomerOrderCodes(String env);


    /**
     * 获取smb支付信息，主单号
     *
     * @return 主单号
     */
    RemoteResult<List<Long>> getSmbPayInfoOrderIds(String env);


    /**
     * 根据smb订单号 抛送订单
     *
     * @param customerOrderCodes
     */
    void throwSmbOrderByCustomerOrderCodeList(List<String> customerOrderCodes);

    /**
     * 根据smb订单号 抛送订单
     *
     * @param customerOrderCode
     * @return
     */
    RemoteResult throwSmbOrderByCustomerOrderCode(String customerOrderCode);

    /**
     * 抛送smb订单
     *
     * @param smbOrderMain
     * @return
     */
    RemoteResult smbThrowOrder(OrderMainSmbThrow smbOrderMain);


    /**
     * 根据订单号抛smb支付信息
     *
     * @param orderIds
     * @return
     */
    void throwSmbPayInfoByOrderIdList(List<Long> orderIds);

    /**
     * 根据订单号抛smb支付信息
     *
     * @param orderId
     * @return
     */
    RemoteResult throwSmbPayInfoByOrderId(Long orderId);

    /**
     * 抛送smb支付信息
     *
     * @param orderPayThrow
     * @return
     */
    RemoteResult smbThrowPayInfo(OrderPay orderPayThrow);
}
