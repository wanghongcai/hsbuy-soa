package com.lenovo.m2.hsbuy.service.pay.soa;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.outpay.OrderDetail;

/**
 * 支付订单数据查询服务
 * Created by tianchuyang on 2017/5/9.
 */
public interface OrderQueryService {

    RemoteResult<OrderDetail> queryOrderDetailHandle(String outTradeNo, String shopId);
}
