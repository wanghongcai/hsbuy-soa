package com.lenovo.m2.hsbuy.service.pay.soa;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.PayPointRules;

/**
 * Created by jh on 2017/8/10.
 */
public interface PayPointRulesService {

    /**
     * 获取可用积分 规则
     * @param faId
     * @return
     */
    RemoteResult<PayPointRules> getPayPointRulesByfaId(String faId);
}
