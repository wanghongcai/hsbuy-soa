package com.lenovo.m2.hsbuy.service.pay.soa;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;

import java.util.List;
import java.util.Map;

/**
 * 统一支付服务订单
 * Created by MengQiang on 2016/9/12.
 */
public interface PayPortalOrderService {
    /**
     * delete
     */
    public RemoteResult<Integer> deleteByPrimaryKey(Integer id);

    /**
     * Insert
     */
    public RemoteResult<Integer> insert(PayPortalOrder payPortalOrder);

    /**
     * insert
     */
    public RemoteResult<Integer> insertSelective(PayPortalOrder payPortalOrder);


    /**
     * selectByPrimaryKey
     */
    public RemoteResult<PayPortalOrder> selectByPrimaryKey(Integer id);

    /**
     * update
     */
    public RemoteResult<Integer> updateByPrimaryKeySelective(PayPortalOrder payPortalOrder);

    /**
     * update
     */
    public RemoteResult<Integer> updateByPrimaryKey(PayPortalOrder payPortalOrder);

    /**
     *
     * @param payPortalOrder
     * @return PrimaryId
     */
    public RemoteResult<Long> insertReturnPrimaryId(PayPortalOrder payPortalOrder);

    /**
     * 查询PayPortalOrderList
     * @param outTradeNoList
     * @param lenovoId
     * @param tenant
     * @return
     */
    public RemoteResult<List<PayPortalOrder>> queryPayPortalOrderListByOutTradeNoList(List<String> outTradeNoList, String lenovoId, Tenant tenant);

    /**
     * Save And Update
     * @param savePayPortalOrderList
     * @param updatePayPortalOrderList
     * @return
     */
    public RemoteResult<Boolean> saveOrUpdatePayPortalOrderList(List<PayPortalOrder> savePayPortalOrderList, List<PayPortalOrder> updatePayPortalOrderList);

    /**
     * Update PayStatus
     * updatePayPortalOrder.setTransationId(payTransactionId);
     * updatePayPortalOrder.setPayment(payment);
     * updatePayPortalOrder.setPayStatus(Integer.valueOf(payStatus));
     * updatePayPortalOrder.setPayTime(payTime);
     * where
     * updatePayPortalOrder.setOutTradeNo(outTradeNo);
     * updatePayPortalOrder.setLenovoId(lenovoId);
     * updatePayPortalOrder.setShopId(shopId);
     * @param updatePayPortalOrder
     * @return
     */
    public RemoteResult<Integer> updatePayPortalOrderPayStatus(PayPortalOrder updatePayPortalOrder);

    /**
     * Get Single PayPortalOrder
     * @param outTradeNo
     * @param lenovoId
     * @param tenant
     * @return
     */
    public RemoteResult<PayPortalOrder> queryPayPortalOrderByOutTradeNo(String outTradeNo, String lenovoId, Tenant tenant);



    /**
     * Update OrderStatus
     * @param outTradeNo
     * @param tenant
     * @param orderStatus
     * @return
     */
    public RemoteResult<Integer> updatePayPortalOrderOrderStatus(String outTradeNo, Tenant tenant, String orderStatus);

    /**
     * Get Single PayPortalOrder
     * @param showTradeNo
     * @param lenovoId
     * @param tenant
     * @return
     */
    public RemoteResult<PayPortalOrder> queryPayPortalOrderByShowTradeNo(String showTradeNo, String lenovoId, Tenant tenant);

    /**
     * 查询外部商户待取消订单
     * @return
     */
    public RemoteResult<List<PayPortalOrder>> queryPayPortalOrderList(Map<String, String> params);

    /**
     * Save PayPortalOrder List
     * @param savePayPortalOrderList
     * @return
     */
    public RemoteResult<Integer> savePayPortalOrderList(List<PayPortalOrder> savePayPortalOrderList);

    /**
     * 批量取消 pay_portal_order 订单
     * @param centerOrderList 取消订单
     *
     * @return
     */
    public RemoteResult<Integer> cancelPayProtalOrderList(List centerOrderList);

    public void testPath(String path);
}
