package com.lenovo.m2.hsbuy.inventory;

import com.lenovo.fis.model.GoodsMaterials;
import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.inventory.CastOrderParam;
import com.lenovo.m2.hsbuy.domain.inventory.HsStock;
import com.lenovo.m2.hsbuy.domain.inventory.HsWaterLevelStock;

import java.util.List;
import java.util.Map;

/**
 * Created by yezhenyue on 2017/2/10.
 */
public interface HsStockApiService {
    /**
     * 根据faid和物料编号查询 分销商库存列表
     * @param productNo 物料编号
     * @param faid
     * @param productGroupNo
     * @return
     */
    RemoteResult<List<HsStock>> getHsStocksByPcode(String productNo, String faid, String productGroupNo);

    /**
     * 根据faid和物料编号查询库存水位描述
     * @param productNo
     * @param faid
     * @param productGroup
     * @return
     */
    RemoteResult getHsStockLevelDesc(String productNo, String faid, String productGroup);

    /**
     * 新增惠商库存水位
     * @param hsWaterLevelStock
     * @return
     */
    RemoteResult addHsWaterLevelStock(HsWaterLevelStock hsWaterLevelStock);

    /**
     * 修改惠商库存水位
     * @param hsWaterLevelStock
     * @return
     */
    RemoteResult updateHsWaterLevelStock(HsWaterLevelStock hsWaterLevelStock);

    /**
     * 分页查询水位库存
     * @param pageQuery
     * @param map
     * @return
     */
    RemoteResult<PageModel2<HsWaterLevelStock>> getHsWaterLevelStockPage(PageQuery pageQuery, Map map);

    /**
     * 根据faid查询水位库存
     * @param faid
     * @return
     */
    RemoteResult<HsWaterLevelStock> getHsWaterLevelStockByFaid(String faid);
    /**
     * 根据id查询水位库存
     * @param id
     * @return
     */
    RemoteResult<HsWaterLevelStock> getHsWaterLevelStockById(long id);

    /**
     * 根据物料号、faid、库存地编号查询惠商库存
     * @param productNo 物料编号
     * @param faid faid
     * @param rdcCode 库存地编号
     * @param productGroupNo 产品组编号
     * @param tmsordno tms单号
     * @return
     */
    RemoteResult<HsStock> getHsStock(String productNo, String faid, String rdcCode, String productGroupNo, String tmsordno);
    /**
     * 根据分销商编号和物料编号同步分销商库存
     *
     * @param fxsNo     分销商编号
     * @param goodsCode 物料编号
     * @param secCTOGoodsCode 惠商CTO真实物料编号
     */
    void syncHsPlatformStock(String faid, String fxsNo, String goodsCode, String secCTOGoodsCode);

    /**
     * 惠商按库存地抛单成功后，扣减惠商的自有库存
     * @param param
     * @param shopid
     * @return
     */
    RemoteResult handleHsOwnStock(CastOrderParam param, Integer shopid);

    /**
     * 新建自有库存
     * @param hsStock
     * @return
     */
    RemoteResult addHsOwnStock(HsStock hsStock);

    /**
     * 修改自有库存
     * @param hsStock
     * @return
     */
    RemoteResult updateHsOwnStock(HsStock hsStock);

    /**
     * 查询自有库存
     * @param faid
     * @param goodsCode
     * @param productGroupNo
     * @return
     */
    RemoteResult<HsStock> getHsOwnStock(String faid, String goodsCode, String productGroupNo);

    /**
     * 根据主键查询自有库存
     * @param stockId
     * @return
     */
    RemoteResult<HsStock> getHsOwnStockById(long stockId);

    /**
     * 分页查询自有库存
     * @param pageQuery
     * @param map
     * @return
     */
    RemoteResult<PageModel2<HsStock>> getHsOwnStockPage(PageQuery pageQuery, Map map);

    /**
     * 同步惠商库存接口
     * @param faid
     * @param fxsNo 分销商编号
     * @param goodsMaterialses 物料对象列表
     * @return
     */
    void syncHsStock(String faid, String fxsNo, List<GoodsMaterials> goodsMaterialses);
}
