package com.lenovo.m2.hsbuy.api.param.pricelist;


import com.lenovo.m2.hsbuy.domain.purchase.param.BaseParam;

import java.io.Serializable;

/**
 * 接口对象
 * 
 * @author wangrq1
 *
 */
public class ManualOrderParam extends BaseParam implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String dealNo;

	private String payMan;

	private Byte payManType;

	private String payType;

	private String invoiceId;
		
	private String deliverAddress;
	
	private String invoiceAddress;
	
	private String itCode;

	private String deliverAddressId;
	
	private String invoiceAddressId;
	
	private String userName;

	private Integer invoiceType;

	
	public String getDealNo() {
		return dealNo;
	}

	public void setDealNo(String dealNo) {
		this.dealNo = dealNo;
	}

	public String getPayMan() {
		return payMan;
	}

	public void setPayMan(String payMan) {
		this.payMan = payMan;
	}

	public Byte getPayManType() {
		return payManType;
	}

	public void setPayManType(Byte payManType) {
		this.payManType = payManType;
	}

	public String getPayType() {
		return payType;
	}

	public void setPayType(String payType) {
		this.payType = payType;
	}

	public String getInvoiceId() {
		return invoiceId;
	}

	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}

	public String getDeliverAddress() {
		return deliverAddress;
	}

	public void setDeliverAddress(String deliverAddress) {
		this.deliverAddress = deliverAddress;
	}

	public String getInvoiceAddress() {
		return invoiceAddress;
	}

	public void setInvoiceAddress(String invoiceAddress) {
		this.invoiceAddress = invoiceAddress;
	}

	public String getItCode() {
		return itCode;
	}

	public void setItCode(String itCode) {
		this.itCode = itCode;
	}

	public String getDeliverAddressId() {
		return deliverAddressId;
	}

	public void setDeliverAddressId(String deliverAddressId) {
		this.deliverAddressId = deliverAddressId;
	}

	public String getInvoiceAddressId() {
		return invoiceAddressId;
	}

	public void setInvoiceAddressId(String invoiceAddressId) {
		this.invoiceAddressId = invoiceAddressId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Integer getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(Integer invoiceType) {
		this.invoiceType = invoiceType;
	}
}
