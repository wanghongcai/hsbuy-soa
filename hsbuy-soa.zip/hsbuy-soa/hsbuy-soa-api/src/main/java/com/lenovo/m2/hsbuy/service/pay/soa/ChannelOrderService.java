package com.lenovo.m2.hsbuy.service.pay.soa;


import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.ChannelOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.ChannelOrderInfo;

import java.util.List;
import java.util.Map;

/**
 * Created by lijie
 */
public interface ChannelOrderService {

    /**
     * 保存支付订单接口
     * @param orders
     * @param pushTime
     * @return
     */
    public RemoteResult<Map<String,Integer>> pushChannelOrder(List<ChannelOrder> orders, String pushTime) throws Exception;

    /**
     * 查询订单详情
     * @param param
     * @return
     */
    public RemoteResult<List<ChannelOrderInfo>> queryChannelOrderDetail(Map param);

    /**
     * 查询主单
     * @param order_main_code
     * @param lenovo_id
     * @returen list
     */
    public RemoteResult<List<ChannelOrder>> queryChannelOrderMainCodeList(List<String> order_main_code, String lenovo_id, String shopId);

    /**
     * 根据主单号查询对应的主单信息
     * @param order_main_code
     * @param lenovo_id
     * @return map
     */
    public RemoteResult<ChannelOrder> queryChannelOrderMainCodeDetail(String order_main_code, String lenovo_id, String shopId);

    /**
     * 根据主单号修改订单信息
     * @param channelOrder
     * @return
     */
    public RemoteResult<Integer> updateChannelOrderMainCodeDetail(ChannelOrder channelOrder);

    /**
     * 更新ChannelOrder订单状态
     * @param orderStatus
     * @param orderCode
     * @param mainFlag
     * @return
     */
    public RemoteResult<Integer> updateChannelOrderOrderStatus(int orderStatus, String orderCode, int mainFlag, String shopId);

    /**
     * 查询orderMainCode下所有子单
     * @param orderMainCode
     * @param lenovoId
     * @return
     */
    public RemoteResult<List<ChannelOrder>> queryChannelOrderCodeList(String orderMainCode, String lenovoId, int mainFlag, String shopId);

    /**
     * 查询子单信息
     * @param orderCode
     * @param lenovoId
     * @return
     */
    public RemoteResult<ChannelOrder> queryChannelOrderCodeDetail(String orderCode, String lenovoId, int mainFlag, String shopId);

    /**
     * 查询子单List
     * @param orderCodeList
     * @param lenovo_id
     * @returen list
     */
    public RemoteResult<List<ChannelOrder>> queryOrderCodeList(List<String> orderCodeList, String lenovo_id, int mainFlag, String shopId);

    /**
     * 查询子单信息
     * @param smbOrderCode
     * @param mainFlag
     * @return
     */
    public RemoteResult<ChannelOrder> querySmbChannelOrderDetail(String smbOrderCode, int mainFlag, String shopId);


    /**
     * 查询主单列表
     * shopId 商城id
     * minuteDiff 有效期，单位分钟
     * orderType 订单类型
     * exclusionOrderType 排除订单类型
     *
     * @return
     */
    public RemoteResult<List<ChannelOrder>> queryOrderList(Map parMap, PageQuery pageQuery);

    /**
     * 批量取消订单
     * @param orderCodes 取消订单
     *
     * @return
     */
    public RemoteResult<Integer> cancelOrderList(List orderCodes);

    /**
     * 查询超时
     * shopId 商城id
     * timeoutHours 超时小时数
     *
     * @return
     */
    public RemoteResult<List<ChannelOrder>> queryTimeoutOrderList(Map parMap, PageQuery pagChannelOrdereQuery);
}
