package com.lenovo.m2.hsbuy.service.pay.refund;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.RefundOrderInfo;


/**
 * 退款公共接口
 * Created by tianchuyang on 2017/2/14.
 */
public interface RefundService {

    /**
     * lePay退款接口
     * @param refundOrderInfo
     * @param merchantPayPlatView
     * @return
     */
    public RemoteResult lePayRefund(RefundOrderInfo refundOrderInfo, MerchantPayPlatView merchantPayPlatView);
}
