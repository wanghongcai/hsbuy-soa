package com.lenovo.m2.hsbuy.message;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.message.Message;

/**
 * Created by admin on 2017/3/14.
 */
public interface MessageService {

    public RemoteResult addMessageTemplate(Message message);

    public RemoteResult<Message> getMessageTemplate(Message message);

}
