package com.lenovo.m2.hsbuy.api.param.pricelist;

import com.lenovo.m2.hsbuy.domain.pricelist.PriceListDetail;
import com.lenovo.m2.hsbuy.domain.purchase.param.BaseParam;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class PriceListParam extends BaseParam {
    private Long id;

    private String dealNo;

    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date expireDate;

    private String saleOrganization;

    private String itcode;

    private String memberNo;

    private BigDecimal totalPrice;

    private String payee;

    private String openingBank;

    private String accountNumber;

    private Integer isCreatedOrder;

    private String auditFile;

    private String buyerName;

    private String buyerAddress;

    private String buyerZip;

    private String buyerPhone;

    private String buyerContacts;

    private String buyerTele;

    private String customManager;

    private String cmPhone;

    private String cmFax;

    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date createTime;

    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date updateTime;

    private String detail;

    private List<PriceListDetail> detailList;

    private String userId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public List<PriceListDetail> getDetailList() {
        return detailList;
    }

    public void setDetailList(List<PriceListDetail> detailList) {
        this.detailList = detailList;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDealNo() {
        return dealNo;
    }

    public void setDealNo(String dealNo) {
        this.dealNo = dealNo == null ? null : dealNo.trim();
    }

    public Date getExpireDate() {
        return expireDate;
    }

    public void setExpireDate(Date expireDate) {
        this.expireDate = expireDate;
    }

    public String getSaleOrganization() {
        return saleOrganization;
    }

    public void setSaleOrganization(String saleOrganization) {
        this.saleOrganization = saleOrganization == null ? null : saleOrganization.trim();
    }

    public String getItcode() {
        return itcode;
    }

    public void setItcode(String itcode) {
        this.itcode = itcode == null ? null : itcode.trim();
    }

    public String getMemberNo() {
        return memberNo;
    }

    public void setMemberNo(String memberNo) {
        this.memberNo = memberNo == null ? null : memberNo.trim();
    }

    public BigDecimal getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(BigDecimal totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getPayee() {
        return payee;
    }

    public void setPayee(String payee) {
        this.payee = payee == null ? null : payee.trim();
    }

    public String getOpeningBank() {
        return openingBank;
    }

    public void setOpeningBank(String openingBank) {
        this.openingBank = openingBank == null ? null : openingBank.trim();
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber == null ? null : accountNumber.trim();
    }

    public Integer getIsCreatedOrder() {
        return isCreatedOrder;
    }

    public void setIsCreatedOrder(Integer isCreatedOrder) {
        this.isCreatedOrder = isCreatedOrder;
    }

    public String getAuditFile() {
        return auditFile;
    }

    public void setAuditFile(String auditFile) {
        this.auditFile = auditFile == null ? null : auditFile.trim();
    }

    public String getBuyerName() {
        return buyerName;
    }

    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName == null ? null : buyerName.trim();
    }

    public String getBuyerAddress() {
        return buyerAddress;
    }

    public void setBuyerAddress(String buyerAddress) {
        this.buyerAddress = buyerAddress == null ? null : buyerAddress.trim();
    }

    public String getBuyerZip() {
        return buyerZip;
    }

    public void setBuyerZip(String buyerZip) {
        this.buyerZip = buyerZip == null ? null : buyerZip.trim();
    }

    public String getBuyerPhone() {
        return buyerPhone;
    }

    public void setBuyerPhone(String buyerPhone) {
        this.buyerPhone = buyerPhone == null ? null : buyerPhone.trim();
    }

    public String getBuyerContacts() {
        return buyerContacts;
    }

    public void setBuyerContacts(String buyerContacts) {
        this.buyerContacts = buyerContacts;
    }

    public String getBuyerTele() {
        return buyerTele;
    }

    public void setBuyerTele(String buyerTele) {
        this.buyerTele = buyerTele;
    }

    public String getCustomManager() {
        return customManager;
    }

    public void setCustomManager(String customManager) {
        this.customManager = customManager == null ? null : customManager.trim();
    }

    public String getCmPhone() {
        return cmPhone;
    }

    public void setCmPhone(String cmPhone) {
        this.cmPhone = cmPhone == null ? null : cmPhone.trim();
    }

    public String getCmFax() {
        return cmFax;
    }

    public void setCmFax(String cmFax) {
        this.cmFax = cmFax == null ? null : cmFax.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

}