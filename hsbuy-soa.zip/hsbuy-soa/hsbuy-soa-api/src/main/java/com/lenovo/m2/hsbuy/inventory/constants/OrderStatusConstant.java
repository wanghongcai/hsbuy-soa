package com.lenovo.m2.hsbuy.inventory.constants;

/**
 * Created by yezhenyue on 2016/11/17.
 */
public class OrderStatusConstant {
    //订单状态 1新建 2支付 3签收 -1退款 -2拆单
    public static final int ORDER_ADD = 1;
    public static final int ORDER_PAY = 2;
    public static final int ORDER_SIGN = 3;
    public static final int ORDER_RE = -1;
    public static final int ORDER_SPLIT = -2;
}
