package com.lenovo.m2.hsbuy.service.pay.soa;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.PayMailAddress;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.PayMailInfo;

import java.util.List;
import java.util.Map;

/**
 * SOA邮件服务
 * Created by mengqiang1 on 2016/3/24.
 */
public interface PayMailService {

    public boolean sendMail(PayMailInfo payMailInfo);

    public RemoteResult<String> reSendFailedMail(Map<String, Object> paraMap);

    /**
     * 获取收件人信息
     * @param mailType
     * @return
     */
    public RemoteResult<List<PayMailAddress>> queryPayMailAddressList(String mailType);
}
