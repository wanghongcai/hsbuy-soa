package com.lenovo.m2.hsbuy.service.pay.ordersoa;


import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.ChannelOrder;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.baseInfo.OrderTrace;

import java.util.List;
import java.util.Map;

/**
 * Created by lijie
 */
public interface ChannelOrderService {

    /**
     * 推单接口，国际化改造
     *
     * @param orders
     * @param pushTime
     * @return
     */
     RemoteResult<Map<String, String>> pushChannelOrder(List<ChannelOrder> orders, String pushTime, Tenant tenant) throws Exception;



    /**
     * 查询子单List
     * 不确定
     *
     * @param orderCodeList
     * @param lenovo_id
     * @returen list
     */
     RemoteResult<List<ChannelOrder>> queryOrderCodeList(List<String> orderCodeList, String lenovo_id, int mainFlag, String shopId);

    /**
     * 查询主单列表
     * shopId 商城id
     * minuteDiff 有效期，单位分钟
     * orderType 订单类型
     * exclusionOrderType 排除订单类型
     * pay-worker 扫单调用
     *
     * @return
     */
     RemoteResult<List<ChannelOrder>> queryOrderList(Map parMap, PageQuery pageQuery);

    /**
     * 批量取消订单
     *
     * @param orderCodes 取消订单
     *                   pay-worker 扫单调用
     * @return
     * @deprecated 抽取出来，到扫单
     */
     RemoteResult<Integer> cancelOrderList(List orderCodes);

    /**
     * 批量取消 OrderTrace 订单附表
     *
     * @param orderCodes 取消订单
     *                   pay-worker 扫单调用
     * @return
     * @deprecated 抽取出来，到扫单
     */
     RemoteResult<Integer> cancelOrderTraceList(List orderCodes);

    /**
     * 查询OrderTrace表订单
     *
     * @param orderCodes orderList
     *                   pay-worker 扫单调用
     * @return
     * @deprecated 抽取出来，到扫单
     */
     RemoteResult<List<OrderTrace>> queryOrderTraceList(List orderCodes);

    /**
     * 查询超时，供email，短信等提醒用户功能使用
     * shopId 商城id
     * timeoutHours 超时小时数
     * pay-worker 扫单调用
     *
     * @return
     * @deprecated 抽取出来，到扫单
     */
     RemoteResult<List<ChannelOrder>> queryTimeoutOrderList(Map parMap, PageQuery pagChannelOrdereQuery);

    /**
     * 查询预售尾款未支付即将到期 订单
     * pay-worker 扫单调用
     *
     * @return
     * @deprecated 抽取出来，到扫单
     */
     RemoteResult<List<ChannelOrder>> queryPresellNotLastPayList(Map parMap);
}
