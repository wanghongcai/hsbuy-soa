package com.lenovo.m2.hsbuy.service.pay.worker;

import com.lenovo.m2.arch.framework.domain.RemoteResult;

/**
 * Created with IntelliJ IDEA.
 * User: zhangqy10
 * Date: 16-9-21
 * Time: 上午10:09
 * To change this template use File | Settings | File Templates.
 */
public interface ScanOrder {

    public RemoteResult scanOrder(String shopId, String order, String smbOrder);

}
