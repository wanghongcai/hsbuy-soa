package com.lenovo.m2.hsbuy.service.pay.ordersoa;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.MerchantVO;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.SimpleUseInfoVO;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.StoreVO;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.UserInfo;

import java.util.List;
import java.util.Map;

/**
 * @author zhangyg7
 */
public interface UserInfoService {

    /**
     * 添加收银台商户
     * ledger-admin 使用
     *
     * @param merchantVO 商户信息
     * @return RemoteResult<Integer>
     */
    RemoteResult<Integer> saveMerchantToUserInfo(MerchantVO merchantVO);

    /**
     * 添加门店信息
     * ledger-admin 使用
     *
     * @param storeVO 门店信息
     * @return RemoteResult<Integer>
     */
    RemoteResult<Integer> saveStoreToUserInfo(StoreVO storeVO);

    /**
     * 支付用户信息修改
     * ledger-admin 使用
     *
     * @param userInfo 用户信息
     * @return RemoteResult<Integer>
     */
    RemoteResult<Integer> updateUserInfo(UserInfo userInfo);

    /**
     * 删除
     * ledger-admin 使用
     *
     * @param userNo 商户编码
     * @return RemoteResult<Integer>
     */
    RemoteResult<Integer> deleteUserInfoByUserNo(String userNo);

    /**
     * 分页查询
     * ledger-admin 使用
     *
     * @param pageNum  默认 1
     * @param pageSize 默认 20
     * @param map      入参
     * @return RemoteResult<PageModel2<UserInfo>>
     */
    RemoteResult<PageModel2<UserInfo>> getUserInfoPage(Integer pageNum, Integer pageSize, Map map);

    /**
     * 不包含权限参数
     * ledger-admin 使用
     *
     * @param pageNum
     * @param pageSize
     * @param map
     * @return
     */
    RemoteResult<PageModel2<UserInfo>> getUserInfoOfMerchantPage(Integer pageNum, Integer pageSize, Map map);

    /**
     * 查询用户详情
     * ledger-admin 使用
     *
     * @param userNo 商户编码
     * @return RemoteResult<UserInfo>
     */
    RemoteResult<UserInfo> getUserInfoByUserNo(String userNo);

    /**
     * 查询商户信息列表  启用状态 userType !=1
     * ledger-admin 使用
     *
     * @return
     */
    RemoteResult<List<SimpleUseInfoVO>> querySimpleUserInfoList(Map map);

    /**
     * pay-front使用
     * 根据fa查询是否支持网银付款
     * 支持返回true 否则false
     *
     * @param faId
     * @return
     */
    RemoteResult getEnablePersonalBankByFaId(String faId, Integer payTypeCode);

    /**
     * 查询用户商户号列表
     * ledger-admin 使用
     * 用于权限的分配
     *
     * @return
     */
    RemoteResult<List<SimpleUseInfoVO>> queryPermissionsList();

}
