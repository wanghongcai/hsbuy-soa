package com.lenovo.m2.hsbuy.service.pay.soa;

import com.lenovo.m2.arch.framework.domain.RemoteResult;

/**
 * Created by Administrator on 2016/3/14.
 */
public interface RefundQueryService {
    /**
     * 退货查询接口
     * @param payType  0：招行  9：微信
     * @return
     */
    public RemoteResult<String> orderRefundQuery(String payType);
}
