package com.lenovo.m2.hsbuy.service.pay.ordersoa;


import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.wxpay.RefundOrder;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.wxpay.WxPayOrder;

import java.util.List;
import java.util.Map;

/**
 * 对账 支付服务接口
 * Created by zhangxs
 *
 *  此接口所有方法都需确定一遍，基本都应该是对账抽取数据相关接口，需根据ledger-soa和ledger-worker确定
 */
public interface ChannelPayCheckService {

    /**
     * 订单编辑 服务于扫单取消修改
     * 暂时未开发
     *
     * @param param orderCode  transationId
     */
    RemoteResult<List<WxPayOrder>> queryPayDataInfo(Map param);

    /**
     * 订单编辑 服务于扫单取消修改
     * 暂时未开发
     *
     * @param param orderCode
     */
    RemoteResult<List<RefundOrder>> queryPayRefundDataInfo(Map param);

    /**
     * 手工回调
     *
     * @param param orderCode mainFlag transactionId payTime payType
     */
    RemoteResult<Integer> updateChannelOrder(Map<String, String> param) throws Exception;
}
