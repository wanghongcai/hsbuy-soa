package com.lenovo.m2.hsbuy.service.pay.soa;


import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.PayOrderView;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by caoxd2
 */
public interface PayOrderService {

    /**
     * 保存支付订单接口
     * @param payOrder
     * @return
     */
    public RemoteResult<String> savePayOrder(PayOrderView payOrder);

    /**
     * 更新支付订单状态接口
     * @param orderCode
     * @param userId
     * @param merchantFlag
     * @param tradeState
     * @return
     */
    public RemoteResult<Boolean> updateOrderPayState(String orderCode, String wxPayCode, String userId, int merchantFlag, int tradeState, int payType);

    /**
     * 更新商家状态接口
     * @param orderCode
     * @param userId
     * @param transactionId
     * @param merchantFlag
     * @return
     */
    public RemoteResult<Boolean> updateMerchantNotifyState(String orderCode, String userId, String transactionId, int merchantFlag);

    /**
     * 更新商家状态接口
     * @param orderCode
     * @param userId
     * @param transactionId
     * @param merchantFlag
     * @param notifyId
     * @param tradeState
     * @param bankSeqNo
     * @param payType
     * @return
     */
    public RemoteResult<Boolean> updateAliPayNotifyState(String orderCode, String userId, String transactionId, int merchantFlag, String notifyId, int tradeState, String bankSeqNo, int payType);


    /**
     * 更新商家状态接口
     * @param orderCode
     * @param transactionId
     * @param merchantFlag
     * @param tradeState
     * @param bankSeqNo
     * @return
     */
    public RemoteResult<Boolean> updateAliIphonePayNotifyState(String orderCode, String transactionId, int merchantFlag, String notifyId, int tradeState, String bankSeqNo, int payType);





    /**
     * 查询支付订单详情接口
     * @param orderCode
     * @param userId
     * @param payCode
     * @return
     */
    public RemoteResult<PayOrderView> queryPayOrderDetail(String orderCode, String userId, String payCode);


    /**
     * 查询支付订单号
     * @param orderCode
     * @return
     */

     public int  getPayOrderByOutTradeNo(String orderCode);

    /**
     * 查询订单的状态
     * @param orderCode
     * @param userId
     * @return
     */
    public Integer getOrderStatus(String orderCode, String userId);

    /**
     * 获取trade_state,merchant_flag
     * @param orderCode
     * @return
     */
    public PayOrder getTwoStatus(String orderCode);

    /**
     * 根据TransactionId查询支付记录
     * @param transactionId
     * @return
     */
    public PayOrder getPayOrderByTransactionId(String transactionId);

    /**
     * 通过订单号获取支付订单详情
     * @param orderCode
     * @return
     */
    public PayOrder getPayOrderById(String orderCode);

    /**
     * 通过支付单号获取支付订单详情
     * @param payOrderId
     * @return
     */
    public PayOrder getPayOrderByPrimaryId(long payOrderId);

    /**
     *
     * @param orders
     * @return
     */
    public Map<String,Map<String,Object>> getRefundInfo(List<String> orders);

    public int getStatusByOrderCode(String orderCode);

    /**
     * 查询所有订单：参数orderCode订单号
     * @param orderCode
     * @return
     */
    public RemoteResult<List<PayOrder>> getOrderListByOrderCode(String orderCode);

    /**
     * 查询所有订单：对账用
     * @param param
     * @return
     */
    public RemoteResult<List<PayOrder>> getPayOrderByConf(Map param);

    public RemoteResult<List<PayOrder>> getOrderListByPayType(String ordercode, Integer payType);

    public int updatePayBankByID(String keyId, String defaultbank, Integer feeType);

    /**
     * 更新分期信息
     * @param id
     * @param hbfqNum
     * @param fqRate
     * @param fqRatePro
     * @param plat
     * @param shopId
     * @param terminal
     */
    public void updateFqInfo(String id, String hbfqNum, String fqRate, String fqRatePro, String plat, String shopId, String terminal);

    /**
     * 更新支付流水多租户信息
     * @param id
     * @param plat
     * @param shopId
     * @param terminal
     */
    public void updatePayOrderShopIdTerminal(String id, String plat, String shopId, String terminal);

    /**
     * 条件查询分页
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<PayOrder>> getPayOrderPage(PageQuery pageQuery, Map map);


    /**
     * 招商银行更新商家状态接口
     * @param orderCode
     * @param userId
     * @param transactionId
     * @param merchantFlag
     * @param notifyId
     * @param tradeState
     * @param bankSeqNo
     * @param payType
     * @param trade_state
     * @return
     */
    public RemoteResult<Integer> updateCmbPayNotifyState(String orderCode, String userId, String transactionId, int merchantFlag, String notifyId, int tradeState, String bankSeqNo, int payType, int trade_state);

    /**
     * 平安银行更新商家状态接口
     * @param orderPrimaryId
     * @param lenovoId
     * @param trade_no
     * @param merchantFlag
     * @param tradeState
     * @param payType
     * @return
     */
    public RemoteResult<Integer> updatePingAnPayNotifyState(String orderPrimaryId, String lenovoId, String trade_no, int merchantFlag, int tradeState, int payType);

    public RemoteResult<Integer> updatePayOrderCreateTime(String orderPrimaryId, String lenovoId, Date createTime);
}
