package com.lenovo.m2.hsbuy.order;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.order.OrderPay;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MDeliveryAddress;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderItem;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderMain;

import java.util.List;
import java.util.Map;

/**
 * Created by zhaocl1 on 2017/11/28.
 */
public interface DispatcherService {

    /**
     * 取消订单
     * @param orderId
     * @param orderCode
     * @param notes
     * @param tenant
     * @return
     */
    RemoteResult orderCancel(long orderId, long orderCode, String notes,Tenant tenant);


    /**
     * 支付回调
     * @param orderPay
     * @param payOrderNo
     * @param tenant
     * @param orderType
     * @return
     */
    RemoteResult saveAfterPayment(OrderPay orderPay, String payOrderNo,Tenant tenant,int orderType);

    /**
     * 只更改价格
     * @param mOrderMain
     * @param mOrderItemList
     * @param mDeliveryAddress
     * @param tenant
     * @return
     */
    RemoteResult updateMOrder4HS(MOrderMain mOrderMain, List<MOrderItem> mOrderItemList,MDeliveryAddress mDeliveryAddress,Tenant tenant);

    /**
     * 计算订单总价和应付金额等
     * @param mOrderItemList
     * @return
     */
    RemoteResult<Map<String,Money>> calculateOrderPrices(MOrderMain mOrderMai ,List<MOrderItem> mOrderItemList,Tenant tenant);
}
