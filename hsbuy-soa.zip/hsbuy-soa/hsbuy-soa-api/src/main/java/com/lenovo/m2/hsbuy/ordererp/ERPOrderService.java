package com.lenovo.m2.hsbuy.ordererp;

import com.lenovo.m2.arch.framework.domain.RemoteResult;

/**
 * 惠商ERP对接-致益联
 */
public interface ERPOrderService {

    /**
     * 查询惠商订单信息
     * @param faCode 分销商
     * @param paidTimeStart 支付时间(开始)
     * @param paidTimeEnd 支付时间(结束)
     * @return 惠商订单信息
     */
    RemoteResult getMongoOrderList4ERP(String faCode, String paidTimeStart, String paidTimeEnd);
}
