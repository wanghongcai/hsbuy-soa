package com.lenovo.m2.hsbuy.service.pay.soa;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.outpay.BankCardLimit;

import java.util.List;

/**
 * Created by tianchuyang on 2017/1/10.
 */
public interface BankCardLimitService {

    RemoteResult<List<BankCardLimit>> queryBankCardLimitsByParams(BankCardLimit bankCardLimit);

    RemoteResult<List<BankCardLimit>> queryAllBankCardLimits();
}
