package com.lenovo.m2.hsbuy.inventory;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.inventory.*;

import java.util.List;
import java.util.Map;


public interface StockAdminApiService {


    /**
     * 分页查询库存信息
     *
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<StockInfo>> getStockInfoPage(PageQuery pageQuery, Map map);

    /**
     * 分页查询库存信息
     *
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<StockInfo>> getActiveStockInfoPage(PageQuery pageQuery, Map map);

    /**
     * 通过 id 查找库存信息
     *
     * @param stockInfo
     * @return
     */
    public RemoteResult<StockInfo> getStockInfoById(long stockInfo);

    /**
     * @param pageQuery
     * @param map       stock_info_id 库存id，必输
     *                  order_state 订单状态，非必输.1--待支付;2--已支付
     * @return
     */
    public RemoteResult<PageModel2<OrderAndStock>> getOrderInfoPage(PageQuery pageQuery, Map map);

    public RemoteResult<List<StockInfo>> getStockInfoList(Map map);

    public int deleteByBatch(List<StockInfo> list);

    public List<StockInfo> checkStockExist(StockInfo stockInfo);

    //------------------------------------------------分割线-------------------------------
    /**
     * 修改活动库存
     * @param param
     * @param operator
     * @return
     */
    RemoteResult<Boolean> operateActivityStock(StockInfoParam param, String operator);
    /**
     * 新建活动库存
     * @param param
     * @return
     */
    RemoteResult<Boolean> addActivityStock(StockInfoParam param, String operator);

    /**
     * 创建库存信息
     *
     * @param stockInfo
     * @param type 1直营 0非直营
     * @return
     */
    public RemoteResult addStockInfo(StockInfo stockInfo, int type);
    /**
     * 修改库存信息
     * @return
     */
    public RemoteResult updateStockInfo(StockInfoParam parm, String operator);



    public RemoteResult<FaBaseInfo> getFaBaseInfoById(String faid);
    /**
     * 分页查询库存日志信息
     *
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<StockInfoLog>> getStockInfoLogPage(PageQuery pageQuery, Map map);
}
