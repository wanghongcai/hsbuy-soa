/**
 * Project Name:purchase-soa-api
 * File Name:NorderService.java
 * Package Name:com.lenovo.m2.buy.purchase.api.service
 * Date:2016年12月21日下午4:24:58
 * Copyright (c) 2016, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.hsbuy.purchase;

import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.purchase.param.ConverAskPrice2OrderParam;
import com.lenovo.m2.hsbuy.domain.purchase.result.CheckOutResult;
import com.lenovo.m2.hsbuy.domain.purchase.result.GetCartNGResult;
import com.lenovo.m2.hsbuy.domain.purchase.result.SubmitOrderResult;
import com.lenovo.m2.hsbuy.domain.purchase.param.CheckOutParam;
import com.lenovo.m2.hsbuy.domain.purchase.param.GetCartNGParam;
import com.lenovo.m2.hsbuy.domain.purchase.param.SubmitOrderParam;

import java.util.Map;

/**
 * ClassName:NorderService <br/>
 * Function: 新订单接口. 所有接口都带有参数 tenant （租户信息）<br/>
 * Date:     2016年12月21日 下午4:24:58 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */
public interface NorderService {

	/**
	 * 1
	* @Title: checkout 
	* @Description: 去结算api
	* @return    设定文件
	 */
	public RemoteResult<CheckOutResult> checkout(Tenant tenant, CheckOutParam checkOutParam);

	/**
	 * 1
	* @Title: submitOrder
	* @Description: 提交订单api
	* @return    设定文件
	 */
	public RemoteResult<SubmitOrderResult> submitOrder(Tenant tenant, SubmitOrderParam submitOrderParam);
	/**
	 * 1
	 * @Title: getCartNG
	 * @Description: 得到用户结算的购物车
	 * @return    设定文件
	 */
	public RemoteResult<GetCartNGResult> getCartNG(Tenant tenant, GetCartNGParam cartNGParam);

	/**
	 *
	 * @Title: convertAskPriceOrder2Order
	 * @Description: 询价单转订单
	 * @param tenant
	 * @param askPrice2OrderParam
	 * @return    设定文件
	 * @throws
	 */
	public RemoteResult<SubmitOrderResult> convertAskPriceOrder2Order(Tenant tenant,ConverAskPrice2OrderParam askPrice2OrderParam);

	/**
	 * 发送订单信息给CPS
	 * @param tenant
	 * @param orderNum
	 * @return
	 */
	RemoteResult<String> sendOrderInfoToCPS(Tenant tenant,Long orderNum);

	/**
	 * 根据查询条件提供给CPS订单信息
	 * @param cid
	 * @param orderStartTime
	 * @param orderEndTime
	 * @return
	 */
	String getOrderByOrderParams(String cid, String orderStartTime, String orderEndTime);

	/**
	 * 根据查询条件导出CPS订单信息
	 * @param cid
	 * @param orderStartTime
	 * @param orderEndTime
	 * @return
	 */
	String getImportOrderByOrderParams(String cid, String orderNo, String orderStartTime, String orderEndTime);

	/**
	 * 分页查询CPS订单信息
	 * @param cid
	 * @param orderStartTime
	 * @param orderEndTime
	 * @param pageQuery
	 * @return
	 */
	RemoteResult<Map<String,Object>> getCpsOrderByOrderParams(String cid, String orderNo, String orderStartTime, String orderEndTime, PageQuery pageQuery);

}

