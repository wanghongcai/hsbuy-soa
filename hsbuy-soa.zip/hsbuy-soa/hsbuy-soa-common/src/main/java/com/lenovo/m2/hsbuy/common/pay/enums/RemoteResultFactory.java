package com.lenovo.m2.hsbuy.common.pay.enums;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import org.apache.commons.lang.StringUtils;

/**
 * 统一返回 RemoteResult
 *
 * @Author licy13
 * @Date 2017/6/2
 */

public class RemoteResultFactory {

    private RemoteResultFactory() {
    }

    /**
     * ResultMessageEnum
     *
     * @param messageEnum
     * @param reason      异常原因
     * @return
     */
    public static RemoteResult getErrorResult(ResultMessageEnum messageEnum, String reason) {
        RemoteResult ret = new RemoteResult(false);
        ret.setResultCode(messageEnum.getCode());
        if (StringUtils.isEmpty(reason)) {
            ret.setResultMsg(messageEnum.getDesc());
        } else {
            ret.setResultMsg(reason);
        }
        return ret;
    }

    /**
     * ResultMessageEnum
     *
     * @param messageEnum
     * @return
     */
    public static RemoteResult getErrorResult(ResultMessageEnum messageEnum) {
        return getErrorResult(messageEnum, null);
    }

    /**
     * BusinessException
     *
     * @param exception
     * @param reason    异常原因
     * @return
     */
    public static RemoteResult getErrorResult(BusinessException exception, String reason) {
        RemoteResult ret = new RemoteResult(false);
        ret.setResultCode(exception.getErrno());
        if (StringUtils.isEmpty(reason)) {
            ret.setResultMsg(exception.getMessage());
        } else {
            ret.setResultMsg(reason);
        }
        return ret;
    }

    /**
     * BusinessException
     *
     * @param exception
     * @return
     */
    public static RemoteResult getErrorResult(BusinessException exception) {
        return getErrorResult(exception, null);
    }


    /**
     * 成功
     *
     * @param t   返回值
     * @param <T>
     * @return
     */
    public static <T> RemoteResult getSuccessResult(T t) {
        RemoteResult ret = new RemoteResult(true);
        ret.setResultCode(ResultMessageEnum.SUCCESS.getCode());
        if (t instanceof ResultMessageEnum) {
            ret.setResultMsg(((ResultMessageEnum) t).getDesc());
            ret.setResultCode(((ResultMessageEnum) t).getCode());
        }
        ret.setT(t);
        return ret;
    }

    /**
     * 成功
     *
     * @return
     */
    public static RemoteResult getSuccessResult() {
        RemoteResult ret = new RemoteResult(true);
        ret.setResultCode(ResultMessageEnum.SUCCESS.getCode());
        return ret;
    }
}
