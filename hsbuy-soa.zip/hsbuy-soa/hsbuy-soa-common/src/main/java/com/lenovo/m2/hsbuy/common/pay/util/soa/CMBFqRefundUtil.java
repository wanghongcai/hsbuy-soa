package com.lenovo.m2.hsbuy.common.pay.util.soa;

import net.sf.json.xml.XMLSerializer;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 招行分期支付退款工具类
 * Created by tianchuyang on 2016/12/19.
 */
public class CMBFqRefundUtil {

    private static RequestConfig requestConfig = RequestConfig.custom()
            .setSocketTimeout(15000)
            .setConnectTimeout(15000)
            .setConnectionRequestTimeout(15000)
            .build();

    private static Logger logger = Logger.getLogger(CMBFqRefundUtil.class);

    public static final String COMMON_URL = "https://payment.ebank.cmbchina.com/cdpay/cdpay.dll?DirectRequest?Request=";

    // 招行分期支付
    public static final String CMBFQ_MERID = "025015"; // 商户号
    public static final Integer QUERY_PAGE_SIZE = 18;  // 单页支持条数
    // 接口指令类型
    public static final String CMD_LOGIN = "Login"; // 登录
    public static final String CMD_LOGOUT = "Logout"; // 退出
    public static final String CMD_REFUND = "Refund"; // 退款
    public static final String CMD_QUERYREFUND = "QueryRefund"; // 查询退款
    public static final String CMD_SINGLEQRY = "QuerySingleOrder"; // 单笔订单查询


    // 招行掌上生活扫码支付商户密钥
    public static final String CMBLIFE_MER_PRI_KEY = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCcfAstxxYNBRqmUp52R5qWObX1qVx9kjQrQUj246aPSFLdAjj5YdtkTg/oCXGvHAEa0umR2nY/BB0t5DQ1KT9ZTcY5Ka4ilmbIdYx4CrPcjQ7OhZDnRS7ot0TgEg09iUHVbFNidQRiYxn4e/2or7mU4vIQvcXGwd9lRPG11iEZknKpRsXn2AZoga13SUcAG0H3YNGot0FFwTH902euG3AUrEngax2Vn3bBnnfP0GSjAQTS7qaP7HUKiQI6xQMcXBhQd4Gw4SJshKumXIvK0xkpf6fHOkS0OSxKRrNXcdmrj9Xt0FV2mC6EtfoTa9MaWpKjpThHH/0kAZshjnVfksO7AgMBAAECggEBAJX03PWSahQyBvbKB6aLOZ2qUi/Hi6Wd/LZSyqwlPhDimt3F6nk5CHgXwnB21GWdLYXaBhBKTLRYqem3XTxweY+H02QmCASHIpoI44KJpxC8cCsCnfiyOKC0N6GOSvfkV51BQKsCPiBWnaWclFkZhHsj/BqE8UllskGmjwbU20VXrTlkO3WqoPCFQ6KmH1bsn+WblswtI8dQY7bWpiUUv9TSEqSdImyHBFh+5FQisscgSyA0L5ZfD8oZ6oXiA0NdySdrK1KTiW2tkrek4C/a/zj3XDkTOOstTG9keTncu7Rlap1YZt2uT7y6CkaIEYg9jq008cPANp1oEipfRh+qX4ECgYEAyyPy+d0PPd4wHhugBDFo2JX3f/yEKQZPDmGA/5HFAsu3x3GBfhkFsXdyuXotowSVqFNC+V93v7HOC1r7e8i9sXYPKxudGAQ8EgPyKdpLAjiJhj9mwaMe7gUaDy6483ss9pk7+xqNpQrLL1jaNBm6rZwVEnVrSl/pqYJYw0hjAkECgYEAxTQlrdiECglk/aQa5fy4zMIdNb5EBxCMTN+bXP7yx48hzHeYi+TEY2SH65GD/klEN1d+corLf75Pt0osw5iqfFaSkrurKUvU2YMk8c2onAnq+kVCagqI6R5tEEzg8BCxZqy5WRmCESIfwSSp7GJt8ublzDqQJ0ETjB0WFiRgDvsCgYBwq+nSyNfxWtGZgX0JllYu+08hv++VyZgDw/UGy9VYLaIrjzths4NC4ZvSYH/7kUlo6XWWV2tV+crs5XPjPn5odbEIGfLSJVckLugcaqV7/9vXiEb4U/+NyWqgzStscP+Jb4ijSCEUT55PDptIlpTCQnY1nMb7o6M4j8Gn3vh7gQKBgALPeXH+0fLqq1vKCPAaJ/ATHCN18LZBEB7QWQB8Sa16ZrrpQW1M91eLSTycOEtZc/Vt88liHQBXD//GuNiYxmU7Pp+EuS2/fOsUqWQg0DRZF9Y1QnsMZ2MbIebHkbUaJ80UzRdt+6KO3/D6usk5peN+UuwUMZW9oa+vgm8SWaQdAoGBAI57ypdh7XmyRdpVxkrVfmCl2xEVB+qfZz0sc+sfU8UsOGJ3FZ78kAUZsJh7tAjIqQwV9RtoN7jUWbnYpTkQg6KkZMe5ClA7IUCAQWFyisfVd8gYS/ZHiFnXLH8nmPZYCMlIno8BVHcI/EJPeZUYQPsPIHrnB5hdMuN5D7BFZa04";

    public static final String CMBLIFE_PUB_KEY_UAT = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqoUJLtUCJSNe/XjBWci5JD9muP1e8Jbwe5c6H6oRcsD8CvY7EqZVD2GLW/UWumgtM652LQF2U3DX5Zi57XPFEjvOdRpVROaurvYVyvpudMBF3Yu33PV7k7OB+bR5cGfuUu0QOFUSJSLVTA7SPAGVP1XoIPZ48utX1jBcW9y7atVba7Mwmjhn+chDplJXQhbA3htpfRRL6ZyGQltyym6UN3dIddYxXfaL05zwbEOVwDU1H5u0QOO2chaFFyoUFEkMSRWcVUz20pbEQ0HEYUy4bPvxuLWTGauuMRAF4Ltta2uELveWHZL7USfwqFZ2Lo61x78BheicZT/fC6oZTxpfhQIDAQAB";

    public static final String CMBLIFE_PUB_KEY_PRO = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA1z9Z6Y4Ecv27AIJd0LY8YsJQg+cuyHQm2oBOWBm/xE1T+4iGyV+YFm//bbFtqGGIjbnTSD8RSHyYFcAW9bQ8g6nvGfCDIsdtv62JUKQkQRRw/TNZ0CrVO0rZvboF5GDgKyxLaZkAqOLWdbblyduKBVkvjmsf0F7ViegAx5tEOP0rE2OaryLIOlTu0qmoT6fG71dwoUFcJJWidxFyD5gjEexIgTKOSJ0k0SNixxuT34Czd7mzArp8oE1jdWiTDKKE4VSpxTu0+gZwcfEPByOf5t+rysrQB1tcpCrv+AxIT1c7J3WVhYNx7CT9brsEGZ452btSMeoSvpvWfdsladMB3wIDAQAB";

    // 招行掌上生活退款URL
    public static  final String CMBLIFE_REFUND_URL_UAT = "https://sandbox.ccc.cmbchina.com/AccessGateway/transIn/refund.json";
    public static  final String CMBLIFE_REFUND_URL_PRO = "https://open.cmbchina.com/AccessGateway/transIn/refund.json";

    // 招行掌上生活退款订单查询URL
    public static  final String CMBLIFE_REFUND_QUERY_URL_UAT = "https://sandbox.ccc.cmbchina.com/AccessGateway/transIn/getRefundOrder";
    public static  final String CMBLIFE_REFUND_QUERY_URL_PRO = "https://open.cmbchina.com/AccessGateway/transIn/getRefundOrder";
    /**
     * xml解析成Map
     * @param retXml
     * @return
     * @throws Exception
     */
    public static Map<String, String> parseXml(String retXml) throws Exception {
        // 替换掉$符
        String s = retXml.replaceAll("\\u0024", "");
        Map<String, String> map = new HashMap<String, String>();
        getElementList(getRootElement(s), map);
        return map;
    }

    /**
     * 获取根元素
     *
     * @return
     * @throws DocumentException
     */
    public static Element getRootElement(String xml) throws DocumentException {
        Document srcdoc = DocumentHelper.parseText(xml);
        Element elem = srcdoc.getRootElement();
        return elem;
    }

    /**
     * 递归遍历方法
     *
     * @param element
     */
    public static void getElementList(Element element, Map<String, String> map) {
        List elements = element.elements();
        if (elements.size() == 0) {
            //没有子元素
            String name = element.getName();
            String value = element.getTextTrim();
            map.put(name, value);
        } else {
            //有子元素
            for (Iterator it = elements.iterator(); it.hasNext(); ) {
                Element elem = (Element) it.next();
                //递归遍历
                getElementList(elem, map);
            }
        }
    }

    /**
     * 单个字符串判非空
     *
     * @param str
     * @return
     */
    public static boolean isNotNull4Str(String str) {
        return null != str && !"".equals(str.trim());
    }

    /**
     * 判字符串是否为空
     * @param str
     * @return
     */
    public static boolean isNull4Str(String str){
        return null == str || "".equals(str.trim());
    }
    /**
     * 签名
     * @param cleartext head+body
     * @param key 商户密钥
     * @return 签名结果
     */
    public static String sign(String cleartext,String key){
        MessageDigest messageDigest = null;
        StringBuffer signature = new StringBuffer();
        try {
            signature.append(key).append(cleartext);
            messageDigest = MessageDigest.getInstance("SHA-1");
            messageDigest.update(signature.toString().getBytes("GB2312"));
        } catch (Exception e) {
            logger.error("招行网关分期退款签名发生错误："+e);
            e.printStackTrace();
        }
        String sign = byte2hex(messageDigest.digest()).toLowerCase();
        return sign;
    }

    public static String byte2hex(byte[] b) {//二行制转字符串
        String hs="";
        String stmp="";
        for (int n=0;n<b.length;n++){
            stmp=(Integer.toHexString(b[n] & 0XFF));
            if (stmp.length()==1)
                hs=hs+"0"+stmp;
            else
                hs=hs+stmp;
        }
        return hs;
    }

    /**
     * 招行分期支付专用https工具
     * @param url
     * @param params
     * @return
     */
    public static String sendHttpsPost(String url,String params){
        String result = null;
        String charset = "GB2312";
        try {
            params = URLEncoder.encode(params,charset);
            byte[] bytes = HttpsUtil.post(url, params, charset);
            result = new String(bytes,charset);
        } catch (Exception e) {
            logger.error("招行网关分期退款向url="+url+"，请求参数:"+params+",发送POST请求错误："+e);
        }
        return result;
    }

    /**
     * 判断招行分期是否是有效订单
     * @param status
     * @return
     */
    public static boolean isValidBill(String status){
        boolean flag = false;
        if ("03".equals(status) || "04".equals(status)|| "05".equals(status)|| "07".equals(status)|| "10".equals
                (status)){
            flag = true;
        }
        return flag;
    }

    public static String xml2JSON(String xml){
        // 替换掉$符
        String newXml = xml.replaceAll("\\u0024","");
        return new XMLSerializer().read(newXml).toString().replaceAll("\\[\\]","\"\"");
    }

    /**
     * 将json转化为实体POJO
     * @param jsonStr
     * @param obj
     * @return
     */
    public static<T> Object jsonToObj(String jsonStr,Class<T> obj) {
        T t = null;
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            t = objectMapper.readValue(jsonStr, obj);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return t;
    }

    /**
     * 产生32位随机数
     * @return
     */
    public static String genRandom() {
        return UUID.randomUUID().toString().replaceAll("-", "");
    }

    /**
     * 生成时间戳
     * @return
     */
    public static String getDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        Date date = new Date();
        return sdf.format(date);
    }

    /**
     * 发送HTTP POST请求,支持带多个String参数
     *
     * @param url 链接
     * @param paramMap 参数
     */
    public static String sendHttpPost(String url, Map<String, String> paramMap) throws Exception {
        CloseableHttpClient httpclient = getHttpClient();
        return sendHttpPost(url, paramMap, httpclient);
    }

    /**
     * 获取HttpClient
     */
    private static CloseableHttpClient getHttpClient() {
        return HttpClients.createDefault();
    }
    /**
     * 发送HTTP POST请求
     */
    private static String sendHttpPost(String url, Map<String, String> paramMap, CloseableHttpClient httpclient) throws Exception {
        try {
            HttpPost httpPost = new HttpPost(url);
            // 处理发送中文问题
            httpPost.getParams().setParameter("http.protocol.content-charset", HTTP.UTF_8);
            httpPost.getParams().setParameter(HTTP.CONTENT_ENCODING, HTTP.UTF_8);
            httpPost.getParams().setParameter(HTTP.CHARSET_PARAM, HTTP.UTF_8);
            httpPost.getParams().setParameter(HTTP.DEFAULT_PROTOCOL_CHARSET, HTTP.UTF_8);

            List<NameValuePair> nvps = new ArrayList<NameValuePair>();

            for (String key : paramMap.keySet()) {
                nvps.add(new BasicNameValuePair(key, paramMap.get(key)));
            }

            httpPost.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
            return sendHttpPost(httpPost, httpclient);
        } finally {
            httpclient.close();
        }
    }

    /**
     * 发送HTTP POST请求
     */
    private static String sendHttpPost(HttpPost httpPost, CloseableHttpClient httpclient) throws Exception {
        httpPost.setConfig(requestConfig);
        CloseableHttpResponse response = httpclient.execute(httpPost);

        try {
            HttpEntity entity = response.getEntity();
            return EntityUtils.toString(entity, Charset.forName("UTF-8"));
        } finally {
            response.close();
        }
    }
}
