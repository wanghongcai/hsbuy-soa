package com.lenovo.m2.hsbuy.common.order;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.DecimalFormat;

public class BigDecimalUtil {

    private static Logger logger = Logger.getLogger(BigDecimalUtil.class);

    public static String add(String augend, String addend) {
        return new BigDecimal(augend != null && !augend.equals("") ? augend : "0")
                .add(new BigDecimal(addend != null && !addend.equals("") ? addend : "0")).toString();
    }

    public static String getBigDecimalValue(BigDecimal bigDecimal) {
        return bigDecimal == null ? "0" : bigDecimal + "";
    }

    public static String add(String... args) {
        BigDecimal result = new BigDecimal(0);
        for (String arg : args) {
            result = result.add(new BigDecimal(arg != null && !"".equals(arg) ? arg : "0"));
        }
        return result.toString();
    }

    public static String substract(String... args) {
        if (args.length <= 1) {
            return "0";
        }
        BigDecimal result = new BigDecimal(args[0]);
        for (int i = 1; args != null && i < args.length; i++) {
            String arg = args[i];
            result = result.subtract(new BigDecimal(arg != null && !"".equals(arg) ? arg : "0"));

        }
        return result.toString();
    }

    public static String subtract(String minuend, String subtrahend) {
        if (StringUtils.isEmpty(minuend)) {
            minuend = "0";
        }
        if (StringUtils.isEmpty(subtrahend)) {
            subtrahend = "0";
        }
        return new BigDecimal(minuend != null && !minuend.equals("") ? minuend : "0")
                .subtract(new BigDecimal(subtrahend != null && !subtrahend.trim().equals("") ? subtrahend.trim() : "0")).toString();
    }

    public static String mul(String multiplicand, String multiplier) {
        return new BigDecimal(multiplicand != null && !multiplicand.equals("") ? multiplicand : "0")
                .multiply(new BigDecimal(multiplier != null && !multiplier.equals("") ? multiplier : "0")).toString();
    }

    public static String multiply(String... multiplier){
        if(multiplier.length<2){
            throw new ArithmeticException("args length must not less than 2");
        }
        BigDecimal result=new BigDecimal(multiplier[0]);
        MathContext mc=new MathContext(3, RoundingMode.HALF_EVEN);
        for(int i=1;i<multiplier.length;i++){
            BigDecimal m=new BigDecimal(multiplier[i]);
            result=result.multiply(m,mc);
        }
        DecimalFormat df=new DecimalFormat("##.##");

        return df.format(result);
    }

    public static int compareToZero(String str) {
        return new BigDecimal(str != null && !str.trim().equals("") ? str.trim() : "0").compareTo((new BigDecimal("0")));
    }

    /**
     * @param number
     * @param format（例如：0.00,0.000）
     * @return
     * @function 将字符串数字转换指定格式
     */
    public static String numberStrformat(String number, String format) {
        try {
            BigDecimal big = new BigDecimal((number != null && !"".equals(number)) ? number : "0");
            DecimalFormat d = new DecimalFormat("0.00");
            return d.format(big);
        } catch (Exception e) {
            logger.error("将字符串数字转换指定格式异常！", e);
            return "0.00";
        }
    }

    public static String div(String dividend,String divisor,int scale){
        if (scale < 0) {
            throw new IllegalArgumentException(
                    "The scale must be a positive integer or zero");
        }
        BigDecimal b1=new BigDecimal(dividend);
        BigDecimal b2=new BigDecimal(divisor);
        return getBigDecimalValue(b1.divide(b2,scale, BigDecimal.ROUND_HALF_EVEN));

    }

    public static BigDecimal div(BigDecimal dividend,BigDecimal divisor,int scale){
        if (scale < 0) {
            throw new IllegalArgumentException(
                    "The scale must be a positive integer or zero");
        }
        return dividend.divide(divisor, scale, BigDecimal.ROUND_HALF_EVEN);

    }

    public static void main(String[] args) {

//        System.out.println(new BigDecimal(2).subtract(new BigDecimal(1)).multiply(new BigDecimal(10)));
//        System.out.println(new BigDecimal(1.9).intValue());
//        System.out.println(BigDecimalUtil.div(new BigDecimal(8),new BigDecimal(3), 0));

    }
}
