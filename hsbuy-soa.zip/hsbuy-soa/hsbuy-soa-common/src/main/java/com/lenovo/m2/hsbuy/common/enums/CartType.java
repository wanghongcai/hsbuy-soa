package com.lenovo.m2.hsbuy.common.enums;


import com.lenovo.m2.hsbuy.common.util.JsonUtil;

/**
 * @author  zhanghs
 * fa类型
 */
public enum CartType {

	NORMAL(0, "普通"),
	EPHEMERAL(1, "立即购买"),
	PRICELIST(3, "报价单");

	private final int type;
	private final String descr;

	public int getType() {
		return type;
	}

	public String getDescr() {
		return descr;
	}

	private CartType(int type, String descr){
		this.type = type;
		this.descr = descr;
	}
	
	
	public static CartType getCartTypeByType(int type){
		switch (type) {
		case 0:
			return NORMAL;
		case 1:
			return EPHEMERAL;
		case 3:
			return PRICELIST;
		default:
			return NORMAL;
		}
	}
	
	public static void main(String[] args) {
		System.out.println(JsonUtil.toJson(CartType.getCartTypeByType(1)));
	}
	

	
}
