/**
<<<<<<< HEAD
 * Project Name:couponV2-soa-common
 * File Name:ArrayUtil.java
 * Package Name:com.lenovo.m2.couponV2.common
 * Date:2017年6月12日下午5:29:16
 * Copyright (c) 2017, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.hsbuy.common.pruchase.util;

/**
 * ClassName:ArrayUtil <br/>
 * Function: 数组工具类. <br/>
 * Date:     2017年6月12日 下午5:29:16 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */
public class ArrayUtil {

	private ArrayUtil(){}
		/**
		 * 
		* @Title: toArrayString
		* @Description: 数组转string
		* @param temp
		* @return    设定文件
		* @throws
		 */
		public static final String toArrayString(String[] temp){
			if(null == temp || temp.length == 0){
				return "";
			}
			StringBuffer buffer = new StringBuffer();
			for(String t : temp){
				buffer.append(t).append("@");
			}
			if(buffer.length() >0){
				return buffer.substring(0, buffer.lastIndexOf("@"));
			}
			return "";
		}
}


