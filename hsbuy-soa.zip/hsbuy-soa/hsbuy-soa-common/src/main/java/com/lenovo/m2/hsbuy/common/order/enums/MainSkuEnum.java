package com.lenovo.m2.hsbuy.common.order.enums;

/**
 * Created by zhaocl1 on 2017/9/21.
 * 主品指的是促销的主品，一个促销中只有一个主品，
 * 搭售的品时主品但是在促销结构上不是主品
 */
public enum  MainSkuEnum {

    MAINSKU("主品",1),
    NOMAINSKU("非主品",2);

    private String name;
    private int value;

    MainSkuEnum(String name, int value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public int getValue() {
        return value;
    }
}
