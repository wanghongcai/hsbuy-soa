/**
 * Project Name:purchase-common
 * File Name:LeBeanTypeEnum.java
 * Package Name:com.lenovo.m2.buy.purchase.common.enums
 * Date:2016年7月12日上午11:41:10
 * Copyright (c) 2016, chenzhou1025@126.com All Rights Reserved.
 *
*/

package com.lenovo.m2.hsbuy.common.pruchase.enums;
/**
 * ClassName:LeBeanTypeEnum <br/>
 * Function: TODO ADD FUNCTION. <br/>
 * Reason:	 TODO ADD REASON. <br/>
 * Date:     2016年7月12日 上午11:41:10 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.6
 * @see 	 
 */
public enum LeBeanTypeEnum {
	LE_BEAN(0,"乐豆"),
	LE_SCORE(1,"积分");
	private int type;
	private String common;
	
	
	public int getType() {
		return type;
	}


	public void setType(int type) {
		this.type = type;
	}


	public String getCommon() {
		return common;
	}


	public void setCommon(String common) {
		this.common = common;
	}


	private LeBeanTypeEnum(int type,String common){
		this.type = type;
		this.common = common;
	}
}

