package com.lenovo.m2.hsbuy.common.pruchase.enums;

/**
 * 商品拥有者(暂时只给是否服务使用)
 *
 */
public enum BuOwnerEnum {

	Lenovo_PC(10,"lenovopc"),
	Lenovo_MBG(20,"lenovombg"),
	Lenovo_Service(30,"lenovoservice"),//30代表服务
	Lenovo_Pad(40,"lenovopad"),
	Lenovo_Think(50,"lenovothink"),
	DONGDE_NONUMBER(140,"dongdenonumber"),
	Lenovo_Other(60,"其他");


	private final int type;
	private final String descr;

	private BuOwnerEnum(int type, String descr) {
		this.type = type;
		this.descr = descr;
	}

	public int getType() {
		return type;
	}

	public String getDescr() {
		return descr;
	}


	public static BuOwnerEnum getItemTypeByType(int type) {
		BuOwnerEnum result = null;
		switch (type) {
			case 10:
				result = Lenovo_PC;
				break;
			case 20:
				result = Lenovo_MBG;
				break;
			case 30:
				result = Lenovo_Service;
				break;
			case 40:
				result = Lenovo_Pad;
				break;
			case 50:
				result = Lenovo_Think;
				break;
			case 60:
				result = Lenovo_Other;
				break;
			default:
				throw new IllegalArgumentException("can't find match enum instance where type=" + type);
		}
		return result;
	}

	/**根据buowner获取是否为服务
	 *
	 * @param type
	 * @return
	 */
	public static int getIsServiceByBuOwner(int type) {
		switch (type) {
			case 30:
			case 100:
				return 1;
			default:
				return 0;
		}
	}

}
