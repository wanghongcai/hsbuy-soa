package com.lenovo.m2.hsbuy.common.pruchase.constants;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author zhanghs 【zhanghs6@lenovo.com】
 * @Description: 订单来源
 *
 * @date 2016/3/15 15:05
 * @return
 */
public class OrderSource {

    private static final Map<String,OrderSourceBean> map = new HashMap<>();

    static{
         List<OrderSourceBean> list = new ArrayList<>();
        for (OrderSourceBean bean:list){
            map.put(bean.getTerminal()+"|"+bean.getShopId()+"|"+bean.getSaleType(),bean);
        }

    }

    /**
     * @Author zhanghs 【zhanghs6@lenovo.com】
     * @Description: 获取订单来源
     * @param ternimal  终端ID
     * @param shopId    商城ID
     * @param saleType  销售类型
     * @date 2016/3/15 17:14
     * @return 若没有找到对应的订单来源则返回null
     */
    public static OrderSourceBean getOrderSource(int ternimal,int shopId,int saleType){
        return new OrderSourceBean();
    }



    public static class OrderSourceBean{
        private int orderSourceCode;//来源编号
        private String orderSourceLetterCode;//来源缩写
        private String orderSourceMeaning;//订单来源名称
        private int shopId;
        private int terminal;
        private int saleType;
        private String reversLetterCode;//客服编码
        
        

        public OrderSourceBean() {
			super();
		}

		public OrderSourceBean(int orderSourceCode, String orderSourceLetterCode, String orderSourceMeaning, int shopId, int terminal, int saleType, String reversLetterCode) {
            this.orderSourceCode = orderSourceCode;
            this.orderSourceLetterCode = orderSourceLetterCode;
            this.orderSourceMeaning = orderSourceMeaning;
            this.shopId = shopId;
            this.terminal = terminal;
            this.saleType = saleType;
            this.reversLetterCode = reversLetterCode;
        }

        public int getOrderSourceCode() {
            return orderSourceCode;
        }

        public void setOrderSourceCode(int orderSourceCode) {
            this.orderSourceCode = orderSourceCode;
        }

        public String getOrderSourceLetterCode() {
            return orderSourceLetterCode;
        }

        public void setOrderSourceLetterCode(String orderSourceLetterCode) {
            this.orderSourceLetterCode = orderSourceLetterCode;
        }

        public String getOrderSourceMeaning() {
            return orderSourceMeaning;
        }

        public void setOrderSourceMeaning(String orderSourceMeaning) {
            this.orderSourceMeaning = orderSourceMeaning;
        }

        public int getShopId() {
            return shopId;
        }

        public void setShopId(int shopId) {
            this.shopId = shopId;
        }

        public int getTerminal() {
            return terminal;
        }

        public void setTerminal(int terminal) {
            this.terminal = terminal;
        }

        public int getSaleType() {
            return saleType;
        }

        public void setSaleType(int saleType) {
            this.saleType = saleType;
        }

        public String getReversLetterCode() {
            return reversLetterCode;
        }

        public void setReversLetterCode(String reversLetterCode) {
            this.reversLetterCode = reversLetterCode;
        }

        @Override
        public String toString() {
            return "OrderSourceBean{" +
                    "orderSourceCode=" + orderSourceCode +
                    ", orderSourceLetterCode='" + orderSourceLetterCode + '\'' +
                    ", orderSourceMeaning='" + orderSourceMeaning + '\'' +
                    ", shopId=" + shopId +
                    ", terminal=" + terminal +
                    ", saleType=" + saleType +
                    ", reversLetterCode='" + reversLetterCode + '\'' +
                    '}';
        }
    }
}



