package com.lenovo.m2.hsbuy.common.pay.common.soa;

import java.util.ArrayList;
import java.util.HashMap;

public class Constant {
    //是否加密
    public static String ENCRYPT = "encrypt";

    public static String SYS_ERROR = "系统错误！请重试！";

    public static String INPUT_CHARSET = "UTF-8";
    public static String WX_MD5_CHARSET = "GBK";

    public static int TOKEN_EXPIRES = 7000;
    public static String MPAPPID = "wx7b37229179b64bf3";

    public static final int HTTP_TYPE_GET   = 1;

    public static final int HTTP_TYPE_POST  = 2;

    public static final String GET_PAY_PACKAGE_ERROR  = "获取订单支付信息失败";
    public static final String PARMS_ERROR  = "参数错误";
    public static final String SIGN_ERROR  = "签名失败";
    public static final String FEE_ERROR  = "金额费用有误";
    public static final String WX_SERVER_ERROR = "微信服务器异常";
    public static final String WOMAI_SERVER_ERROR = "服务器异常";
    public static final String ORDER_PAYED_ERROR = "该订单已经发起支付";
    public static final String ORDER_NOPAYED_ERROR = "该订单未发起支付无法退款";

    public static final String WX_SERVICE_ERROR_CODE = "-2";
    public static final String WOMAI_SERVICE_ERROR_CODE = "-1";
    public static final String SIGN_ERROR_CODE = "100001";
    public static final String FEE_ERROR_CODE = "100003";
    public static final String PARMS_ERROR_CODE = "100004";
    public static final String GET_PAY_PACKAGE_ERROR_CODE = "100002";
    public static final String ORDER_PAYED_CODE = "100005";
    public static final String ORDER_NOPAYED_CODE = "100006";

    //Plat
    public static final String PLAT_WAP = "1";//WAP
    public static final String PLAT_WX = "2";//微信
    public static final String PLAT_APP = "3";//APP
    public static final String PLAT_PC = "4";//PC
    public static final String PLAT_THINK_WAP = "5";//THINKWAP add by dongcy5 15-7-20
    public static final String PLAT_THINK_WX = "6";//THINK微信 add by dongcy5 15-7-20
    public static final String PLAT_THINK_APP = "7";//THINKAPP add by dongcy5 15-7-20
    public static final String PLAT_THINK_PC = "8";//THINKPC add by dongcy5 15-7-20
    public static final String PLAT_EPP_WAP = "20";//EPP add by lijie 15-9-01
    public static final String PLAT_EPP_PC = "22";
    public static final String PLAT_ROAMING = "0";
    public static final String PLAT_MOTO_WAP = "51";//MOTO WAP
    public static final String PLAT_MOTO_WX = "52";//MOTO 微信
    public static final String PLAT_MOTO_APP = "53";//MOTO APP
    public static final String PLAT_MOTO_PC = "54";//MOTO PC

    //平台信息改造SHOPID
    public static final String SHOPID_LENOVO = "1";
    public static final String SHOPID_THINK = "2";
    public static final String SHOPID_EPP = "3";
    public static final String SHOPID_ROAMING = "4";
    public static final String SHOPID_MOTO = "5";
    public static final String SHOPID_DONGDE = "6";
    public static final String SHOPID_THINKCENTER = "7";
    //平台信息改造TERMINAL
    public static final String TERMINAL_PC = "1";
    public static final String TERMINAL_WAP = "2";
    public static final String TERMINAL_APP = "3";
    public static final String TERMINAL_WECHAT = "4";

    //smb发票返回code
    public static final String SUCCESS = "0";
    public static final String ERROR = "1";
    public static final String IRDNUMBERREPEAT = "INVOICE002012"; //重复抛送数据
    public static final String NOTAUTH = "INVOICE002022"; //公司未认证
    public static final String NOUPLOAD = "INVOICE002016"; //未上传关联证明
    public static final String VATNOTEXISTENT = "INVOICE002017"; //发票信息不存在
    public static final String IRDNUMBEREXISTENT = "INVOICE002011"; //纳税人识别号已经被创建主数据



    public static HashMap<String,String> errMap = new HashMap<String, String>();

    static {
        errMap.put(WX_SERVICE_ERROR_CODE,WX_SERVER_ERROR);
        errMap.put(WOMAI_SERVICE_ERROR_CODE,WOMAI_SERVER_ERROR);
        errMap.put(SIGN_ERROR_CODE,SIGN_ERROR);
        errMap.put(FEE_ERROR_CODE,FEE_ERROR);
        errMap.put(PARMS_ERROR_CODE,PARMS_ERROR);
        errMap.put(GET_PAY_PACKAGE_ERROR_CODE,GET_PAY_PACKAGE_ERROR);
        errMap.put(ORDER_PAYED_CODE,ORDER_PAYED_ERROR);
        errMap.put(ORDER_NOPAYED_CODE,ORDER_NOPAYED_ERROR);
    }


    public static ArrayList<String> ignorePackList = new ArrayList<String>();

    //不需要转换的字段
    static {
        ignorePackList.add("total_fee");
        ignorePackList.add("product_fee");
        ignorePackList.add("transport_fee");
        ignorePackList.add("fee_type");
        ignorePackList.add("time_start");
        ignorePackList.add("time_expire");
        ignorePackList.add("fee_type");
        ignorePackList.add("input_charset");
        ignorePackList.add("bank_type");
        ignorePackList.add("partner");
        ignorePackList.add("notify_url");
        ignorePackList.add("sign");
        ignorePackList.add("errcode");
        ignorePackList.add("errmsg");
    }

}
