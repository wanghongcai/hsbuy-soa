package com.lenovo.m2.hsbuy.common.order.enums;

/**
 * Created by zhaocl1 on 2017/5/23.
 */
public enum PaymentTypeIdEnum {

    ONLINE_PAYMENT("在线支付",0),
    COD("货到付款",1),
    OFFLINE_BANK_TRANSFER("线下银行转账",2);

    private String name;
    private int value;

    PaymentTypeIdEnum(String name, int value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public int getValue() {
        return value;
    }
}
