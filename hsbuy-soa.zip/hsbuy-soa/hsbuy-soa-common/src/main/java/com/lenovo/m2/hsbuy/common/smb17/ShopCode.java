package com.lenovo.m2.hsbuy.common.smb17;

/**
 * Created by xuweihua on 2016/8/5.
 */
public class ShopCode {
    public static final int smpsShop=8;
}
