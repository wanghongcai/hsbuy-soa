package com.lenovo.m2.hsbuy.common.pruchase.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.expression.EvaluationException;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.SpelParserConfiguration;
import org.springframework.expression.spel.standard.SpelExpressionParser;

/**
 * 
* @ClassName: ExpressionUtil 
* @Description: 表达式
* @author yuzj7@lenovo.com 
* @date 2016年3月7日 下午2:58:38 
*
 */
public class ExpressionUtil {
	private static Log log = LogFactory.getLog(ExpressionUtil.class);
	/**
	 * 
	* @Title: executePression 
	* @Description: 执行计算表达式
	* @param pression
	* @return    设定文件
	 */
	public static String executePression(String pression) {
		try {
			ExpressionParser parser = new SpelExpressionParser(new SpelParserConfiguration(true, true));
			Expression e = parser.parseExpression(pression);
			Object result = (Object) e.getValue();
			return result.toString();
		}catch (EvaluationException e) {
			System.out.println("============执行表达式报错:" + pression);
			log.error("executePression error -->", e);
			return "0";
		}
	}
}
