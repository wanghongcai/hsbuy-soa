package com.lenovo.m2.hsbuy.common.pruchase.util;


/**
 * @Description:获取wechat.conf文件中的配置数据
 * @author:
 * @Created:2014-11-12上午
 * @Modified:shenjc 2014-11-13下午
 */
public class B2CMainConfig {

	/*private static Config config = ConfigFactory.load("wechat.conf",
			ConfigParseOptions.defaults().setSyntax(ConfigSyntax.CONF)
					.setAllowMissing(false), ConfigResolveOptions.defaults()
					.setUseSystemEnvironment(false));
*/
	public static void main(String[] args) {
		//System.out.println(B2CMainConfig.getCouponSourcekey(""));
	}

	private static String proxy_ip = null;
	private static int proxy_port = -1;
	private static String web_path_url = null;
	private static String pay_ali_pc_notify_url = null;
	private static String pay_ali_pc_call_back_url = null;
	private static String pay_ali_pc_ALIPAY_GATEWAY_NEW = null;
	private static String pay_ali_phone_notify_url = null;
	private static String pay_ali_phone_call_back_url = null;
	private static String pay_ali_phone_ALIPAY_GATEWAY_NEW = null;
	private static String pay_cmb_key = null;
	private static String pay_cmb_branchid = null;
	private static String pay_cmb_cono = null;
	private static String pay_cmb_user = null;
	private static String pay_cmb_password = null;
	private static String pay_cmb_keyFilePath = null;
	private static String pay_cmb_payeeID = null;
	private static String web_union_ali_pay = null;
	private static String web_union_alipay_it_b_pay = null;
	private static String alipay_direct_call_back_url = null;
	private static String alipay_direct_notify_url = null;
	private static String pay_union_merId = null;
	private static String pay_union_frontUrl = null;
	private static String pay_union_backUrl = null;
	private static String pay_union_frontFailUrl = null;
	private static String pay_union_pc_url = null;
	private static String pay_union_phone_url = null;
	private static String product_pc_url = null;
	private static String product_m_url = null;
	private static String message_url = null;
	private static String message_sysId = null;
	private static String message_key = null;
	private static String message_real=null;
	private static String pay_notice_url_pc=null;
	private static String pay_notice_url_wx=null;
	private static String pay_notice_url_app=null;
	private static String pay_notice_url_wap=null;

	public static String getProperty() {
		return null;/*config.getString("test.url");*/
	}

	public static String getProxyHost() {
		/*if (proxy_ip == null) {
			proxy_ip = config.getString("proxy.ip");
		}*/
		return proxy_ip;
	}

	public static int getProxyPort() {
		/*if (proxy_port == -1) {
			proxy_port = config.getInt("proxy.port");
		}*/
		return proxy_port;
	}

	public static String getWebPathUrl() {
		/*if (web_path_url == null) {
			web_path_url = config.getString("web.path.url");
		}*/
		return web_path_url;
	}

	/**
	 * @description 银联支付配置 商户在银联支付系统中的 商户代码
	 * @author qinhca
	 * @2015年3月6日下午2:03:16
	 * @return
	 */
	public static String getPayUnionMerId() {
		/*if (pay_union_merId == null) {
			pay_union_merId = config.getString("pay.union.merId");
		}*/
		return pay_union_merId;
	}

	public static String getPayUnionFrontUrl() {
		/*if (pay_union_frontUrl == null) {
			pay_union_frontUrl = config.getString("pay.union.frontUrl");
		}*/
		return pay_union_frontUrl;
	}

	public static String getPayUnionBackUrl() {
		/*if (pay_union_backUrl == null) {
			pay_union_backUrl = config.getString("pay.union.backUrl");
		}*/
		return pay_union_backUrl;
	}

	public static String getPayUnionFrontFailUrl() {
		/*if (pay_union_frontFailUrl == null) {
			pay_union_frontFailUrl = config.getString("pay.union.frontFailUrl");
		}*/
		return pay_union_frontFailUrl;
	}

	public static String getPayUnionPcUrl() {
		/*if (pay_union_pc_url == null) {
			pay_union_pc_url = config.getString("pay.union.pcUrl");
		}*/
		return pay_union_pc_url;
	}

	public static String getPayUnionPhoneUrl() {
		/*if (pay_union_phone_url == null) {
			pay_union_phone_url = config.getString("pay.union.phoneUrl");
		}*/
		return pay_union_phone_url;
	}

	public static String getWebUnionAliPay() {
		/*if (web_union_ali_pay == null) {
			web_union_ali_pay = config.getString("web.unionAliPay.url");
		}*/
		return web_union_ali_pay;
	}

	public static String getWebUnionAlipayItbpay() {
		/*if (web_union_alipay_it_b_pay == null) {
			web_union_alipay_it_b_pay = config
					.getString("web.unionAliPay.it_b_pay");
		}*/
		return web_union_alipay_it_b_pay;
	}

	// 商品在pc 端的链接url
	public static String getProductPcurl() {
		/*if (product_pc_url == null) {
			product_pc_url = config.getString("web.unionAliPay.product_pc_url");
		}*/
		return product_pc_url;
	}

	// 商品在移动端 的链接url
	public static String getProductMurl() {
		/*if (product_m_url == null) {
			product_m_url = config.getString("web.unionAliPay.product_m_url");
		}*/
		return product_m_url;
	}

	// 支付宝直连支付同步通知地址
	public static String getAlipay_direct_call_back_url() {
		/*if (alipay_direct_call_back_url == null) {
			alipay_direct_call_back_url = config
					.getString("pay.ali_direct.call_back_url");
		}*/
		return alipay_direct_call_back_url;
	}

	// 支付宝直连支付异步通知地址
	public static String getAlipay_direct_notify_url() {
		/*if (alipay_direct_notify_url == null) {
			alipay_direct_notify_url = config
					.getString("pay.ali_direct.notify_url");
		}*/
		return alipay_direct_notify_url;
	}

	// 支付宝配置(PC端)
	public static String getPayAli_pcNotify_url() {
		/*if (pay_ali_pc_notify_url == null) {
			pay_ali_pc_notify_url = config
					.getString("pay.ali_direct.call_back_url");
		}*/
		return pay_ali_pc_notify_url;
	}

	// 支付宝配置(PC端)
	public static String getPayAli_pcCall_back_url() {
		/*if (pay_ali_pc_call_back_url == null) {
			pay_ali_pc_call_back_url = config
					.getString("pay.ali_pc.call_back_url");
		}*/
		return pay_ali_pc_call_back_url;
	}

	// 支付宝配置(PC端)
	public static String getPayAli_pcALIPAY_GATEWAY_NEW() {
		/*if (pay_ali_pc_ALIPAY_GATEWAY_NEW == null) {
			pay_ali_pc_ALIPAY_GATEWAY_NEW = config
					.getString("pay.ali_pc.ALIPAY_GATEWAY_NEW");
		}*/
		return pay_ali_pc_ALIPAY_GATEWAY_NEW;
	}

	// 支付宝配置(手机端)
	public static String getPayAli_phoneNotify_url() {
		/*if (pay_ali_phone_notify_url == null) {
			pay_ali_phone_notify_url = config
					.getString("pay.ali_phone.notify_url");
		}*/
		return pay_ali_phone_notify_url;
	}

	// 支付宝配置(手机端)
	public static String getPayAli_phoneCall_back_url() {
		/*if (pay_ali_phone_call_back_url == null) {
			pay_ali_phone_call_back_url = config
					.getString("pay.ali_phone.call_back_url");
		}*/
		return pay_ali_phone_call_back_url;
	}

	// 支付宝配置(手机端)
	public static String getPayAli_phoneALIPAY_GATEWAY_NEW() {
		/*if (pay_ali_phone_ALIPAY_GATEWAY_NEW == null) {
			pay_ali_phone_ALIPAY_GATEWAY_NEW = config
					.getString("pay.ali_phone.ALIPAY_GATEWAY_NEW");
		}*/
		return pay_ali_phone_ALIPAY_GATEWAY_NEW;
	}

	// 招商配置
	public static String getPayCmbKey() {
		/*if (pay_cmb_key == null) {
			pay_cmb_key = config.getString("pay.cmb.key");
		}*/
		return pay_cmb_key;
	}

	// 招商配置
	public static String getPayCmbBranchid() {
		/*if (pay_cmb_branchid == null) {
			pay_cmb_branchid = config.getString("pay.cmb.branchid");
		}*/
		return pay_cmb_branchid;
	}

	// 招商配置
	public static String getPayCmbCono() {
		/*if (pay_cmb_cono == null) {
			pay_cmb_cono = config.getString("pay.cmb.cono");
		}*/
		return pay_cmb_cono;
	}

	// 招商配置
	public static String getPayCmbUser() {
		/*if (pay_cmb_user == null) {
			pay_cmb_user = config.getString("pay.cmb.user");
		}*/
		return pay_cmb_user;
	}

	// 招商配置
	public static String getPayCmbPassword() {
		/*if (pay_cmb_password == null) {
			pay_cmb_password = config.getString("pay.cmb.password");
		}*/
		return pay_cmb_password;
	}

	// 招商配置
	public static String getPayCmbKeyFilePath() {
		/*if (pay_cmb_keyFilePath == null) {
			pay_cmb_keyFilePath = config.getString("pay.cmb.keyFilePath");
		}*/
		return pay_cmb_keyFilePath;
	}

	// 招商配置
	public static String getPayCmbPayeeID() {
		/*if (pay_cmb_payeeID == null) {
			pay_cmb_payeeID = config.getString("pay.cmb.keyPayeeID");
		}*/
		return pay_cmb_payeeID;
	}

	/**
	 * <br>
	 * 获取cached session的失效时间
	 * 
	 * @author shenjc
	 * @return
	 */
	public static int getCachedSesionTimeout() {
		//return config.getInt("cached.session.timeout");
		return 0;
	}

	public static int getExpires_in() {
		//return config.getInt("wx.api.token_expires_in");
		return 0;
	}

	public static String getDelivernotify_url() {
		//return config.getString("wx.pay.delivernotify_url");
		return null;
	}

	public static String getWxuatSendInfo_url() {
		//return config.getString("wxuat.sendInfoUrl");
		return null;
	}

	public static String getOrderquery_url() {
		//return config.getString("wx.pay.orderquery_url");
		return null;
	}

	public static int getOrderCannelTime() {
		//return config.getInt("wx.pay.order_cannel_time");
		return 0;
	}

	public static String getTokenUrl() {
		//return config.getString("wx.api.token_url");
		return null;
	}

	public static String getOAuthTokenUrl() {
		//return config.getString("wx.api.OAuth_token_url");
		return null;
	}

	public static String getAesKey() {
		//return config.getString("aes.key");
		return null;
	}

	// 获取将要将要返回的首页
	public static String getWxApiIndex() {
		//return config.getString("wx.api.index");
		return null;
	}

	/*
	 * btcp{ getinvoiceurl = "" cid = "" data_digest = "" }
	 */
	/**
	 * 获去电子发票的btcp URL
	 * 
	 * @return
	 */
	public static String getBtcpGetinvoiceurl() {
		//return config.getString("btcp.getinvoiceurl");
		return null;
	}

	/**
	 * 获取BTCP 的 CID
	 * 
	 * @return
	 */
	public static String getBtcpCid() {
		//return config.getString("btcp.cid");
		return null;
	}

	/**
	 * 获取BTCP 的 data_digest
	 * 
	 * @return
	 */
	public static String getBtcpData_digest() {
		//return config.getString("btcp.data_digest");
		return null;
	}

	/**
	 * <br>
	 * 获取是否获取支付的判断
	 * 
	 * @return
	 */
	public static boolean getPayReal() {
		/*String res = config.getString("pay.real");
		boolean bool = false;
		if (res != null) {
			res = res.toLowerCase();
			if (res.equals("true") || res.equals("false")) {
				bool = Boolean.parseBoolean(res);
			}
		}
		return bool;*/
		return false;
	}

	/**
	 * <br>
	 * 获取是否是lucene的war
	 * 
	 * @return
	 */
	public static boolean getIsLucene() {
		/*String res = config.getString("lucene.real");
		boolean bool = false;
		if (res != null) {
			res = res.toLowerCase();
			if (res.equals("true") || res.equals("false")) {
				bool = Boolean.parseBoolean(res);
			}
		}
		return bool;*/
		return false;
	}

	public static String getPlatWap() {
		// TODO Auto-generated method stub
		return null;
	}

	public static String getPayNoticeUrlPc() {
		// TODO Auto-generated method stub
		return null;
	}

	public static String getPlatPC() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
