package com.lenovo.m2.hsbuy.common.pruchase.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

public class ReceiveSalesCoupons {

	private static Logger logger = LogManager.getLogger(ReceiveSalesCoupons.class.getName());


	public static String  drawCoupon(String plat,String memberid,String lenovoid) throws UnsupportedEncodingException{
		String url ="http://" + CustomizedPropertyConfigurer.getContextProperty("coupon.url");
		String body = url+"?plat="+plat+"&memberId="+memberid+"&lenovoId="+lenovoid;

		logger.info("调用的地址是================================================："+ url);
		String res = HttpUtil.getStr(body);
		logger.info("返回的结果是:"+res);
		return res;
	}
	
	public static void main(String[] args) throws UnsupportedEncodingException {
		
		Map<String, String> map = new HashMap<String , String>();
		map.put("plat" , "1");
		map.put("memberId", "333");
		map.put("lenovoId", "2222");
		String res = HttpUtil.postStr("http://coupont.lenovovip.com.cn/receiveSalesCoupons.jhtm", map);
		System.out.println("======="+res);
	}
	
}
