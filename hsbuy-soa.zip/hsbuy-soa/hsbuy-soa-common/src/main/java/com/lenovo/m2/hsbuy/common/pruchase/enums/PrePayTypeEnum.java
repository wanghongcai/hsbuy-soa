package com.lenovo.m2.hsbuy.common.pruchase.enums;

import java.util.Map;
import java.util.TreeMap;

/**
 * 预售付款方式 枚举
 *
 * @author licy13
 * @description
 * @date 2016 -09-27-11:27
 */
public enum PrePayTypeEnum {
    /**
     * Pay deposit pre pay type enum.
     */
    PAY_DEPOSIT("2", "预付定金"),
    PAY_FULL("1", "全额支付");
    /**
     * The Map.
     */
    static Map<String, String> map = new TreeMap<String, String>();
    private String code;// 代号
    private String common;// 说明


    PrePayTypeEnum(String code, String common) {
        this.code = code;
        this.common = common;
    }

    /**
     * 获取枚举类型的所有<值,名称>对
     *
     * @return map
     */
    public static Map<String, String> toMap() {
        if (map.size() > 0) {
            return map;
        }
        for (int i = 0; i < PrePayTypeEnum.values().length; i++) {
            map.put(PrePayTypeEnum.values()[i].getCode(), PrePayTypeEnum.values()[i].getCommon());
        }
        return map;
    }

    /**
     * Gets code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets code.
     *
     * @param code the code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets common.
     *
     * @return the common
     */
    public String getCommon() {
        return common;
    }

    /**
     * Sets common.
     *
     * @param common the common
     */
    public void setCommon(String common) {
        this.common = common;
    }
}
