package com.lenovo.m2.hsbuy.common.enums;

import java.util.HashMap;
import java.util.Map;

/**
*
* @ClassName: ErrorMessageEnum
* @Description:公共错误信息汇总  成功提示0#401
* @author lihc5@lenovo.com
* @date 2015年11月25日
*
*/
public enum ErrorMessageEnum {

	SUCCESS(0,"success"),
	FAIL(1,"fail"),
	ERROR_NOT_LOGIN(401,"请登陆后操作！"),

	ERROR_PARAM(10000,"参数错误！"),
	ERROR_ILLEGAL(10001,"参数非法！"),
	ERROR_ORDER_FAIL(10002,"订单生成失败！"),
	ERROR_QUERY(10003,"查询失败! "),
	ERROR_STOCK_NOT_ENOUGH(10004,"商品[{0}]库存不足！"),
	ERROR_STOCK_INTERFACE(10005,"调用库存接口失败！"),
	ERROR_ZC_ILLEGAL(10006,"众筹参数错误！"),
	ERROR_MOBILE(10007,"手机号不正确! "),
	ERROR_UPDATE_MOBILE(10008,"更新手机号失败! "),
	ERROR_ORDER_COMMIT(10009,"订单提交失败! "),
	ERROR_GET_CART(10010,"获取购物车失败! "),
	ERROR_BANKCARD_NUMBER(10011,"请输入正确的银行卡号! "),
	ERROR_ZIPCODE(10012,"请输入正确的邮编! "),
	ERROR_TIMEOUT(10013,"网络异常，请稍后再试!"),
	ERROR_ANALYSIS_CART(10014,"解析购物车失败！"),
	ERROR_USER_ILLEGAL(10015,"用户信息错误！"),
	ERROR_USER_EMAIL(10016,"请输入正确的邮箱!"),
	ERROR_USER_NICKNAME(10017,"用户的姓名不能大于30个字符!"),
	ERROR_URSER_LOGINNAME(10018,"登录用户名不能为空!"),
	ERROR_CURRENCY_CODE_IS_NULL(10019,"币种标识不能为空!"),
	ERROR_O2O_STOCK_NOT_ENOUGH(10020,"所选地区暂不支持极速达!"),

	ERROR_CART_UNKNOWN_ITEMTYPE(20000,"添加到购物车，未知的itemtype! "),
	ERROR_SECKILL_CHECK(20001,"闪购资格校验失败! "),
	ERROR_OVER_PURCHASE_NUMBER(20002,"超过购买次数! "),
	ERROR_PURCHASE_UNKNOWN_ITEMTYPE(20003,"立即购买失败，未知的itemtype! "),
	ERROR_PACKAGE_INFO(20004,"套餐信息有误! "),
	ERROR_FIND_NOT_PACKAGE_INFO(20005,"查询不到套餐信息! "),
	ERROR_FIND_NOT_PURCHASE_ROW(20006,"找不到购物行信息! "),
	ERROR_NOT_SELECT_SERVICE_DELETE(20007,"没有选中该服务，不能删除! "),
	ERROR_UNEFFECT_SERVICE_SN(20049,"无效的SN编码，不能购买该服务"),
	ERROR_NOT_APPOINTMENTS_BEGIN_OR_PASS(20008,"预约尚未开始或预约时间已过! "),
	ERROR_NOT_REPRERT_APPOINTMENTS(20009,"您已预约，不能重复预约! "),
	ERROR_GOODS_NOT_FOUND(20010,"查询商品失败!"),
	ERROR_VERIFY_SIGN_FAILD(20012,"验签失败!"),
	ERROR_ACTIVITY_STATUS_ERRPR(20014,"活动状态不对！"),
	ERROR_ACTIVITY_FINISHED(20015,"活动已结束!"),
	ERROR_NO_RESERVATION(20016,"没有预约!"),
	ERROR_EXCEED_CEILING(20017,"超过最大购买数量!"),
	ERROR_PURCHASE_CAN_NOT_BE_ALLOWED(20018,"无权限购买此商品!"),
	ERROR_PACKAGE_NOTFINDMAINGODE(20019,"套餐中沒有找到主品！"),


	ERROR_SELECT_GIFT_NOT_EXIST(20029,"可选赠品不正确!"),
	ERROR_CART_TOTAL_EXCEED_LIMIT(20028,"购物车商品数量超限!"),

	ERROR_QUERY_PRODUCT_UNSALEINDEPENT(20020,"该商品不能单独购买！"),
	ERROR_QUERY_PRODUCT_PRICE_FAILD(20019,"查询商品价格失败!"),
	ERROR_PRODUCT_SHELVE_OFF(20021,"商品已下架!"),
	ERROR_ITEM_DELETE_FAILED(20022,"商品删除失败!"),


	ERROR_COUPONCODE_INVALID(20023, "无效的优惠码或优惠码已失效（次数用尽）！"),

	ERROR_GOODS_SHELF_OFF(20024,"商品已下架!"),

	ERROR_GOODS_DONGDE_PNONENUMBER_FAIL(20025,"懂的通信号码验证失败"),
	ERROR_GOODS_DONGDE_STOCK_FAIL(20026,"懂的通信库存占用失败"),
	CHECK_COUPON_CODE_ERROR(20027,"验证优惠码失败"),
	/**
	 * 内购额度相关错误信息，错误码以20030开始 add by zhanghs 2015-11-30
	 */
	ERROR_INNERLIMIT_NOT_DECIMALS(20030, "内购额度不能为小数！"),
	ERROR_INNERLIMIT_NOT_VALID(20031, "对不起，您的内购额度还没有生效或已过期!"),
	ERROR_INNERLIMIT_MORETHEN_USER_VALID(20032, "使用内购额度大于用户可用内购额度！"),
	ERROR_CREDIT_CANNOT_RIGHT(20033,"输入信用额度大于订单金额!"),
	ERROR_INNERLIMIT_ILLEGITMACY(20034, "使用内购额度非法!"),
	ERROR_INNERLIMIT_MORETHEN_PRODUCT_VALID(20035, "使用的内购额度不能大于商品可用内购额度!"),
	ERROR_INNERLIMIT_CONSUME_FAIL(20036, "消费内购额度失败！"),
	ERROR_INNERLIMIT_RETURN_FALI(20037,"内购额度退回失败!"),
	ERROR_INNERLIMIT_NOTSUPPORT(20038,"优惠券,优惠码和内购额度不能同时使用!"),
	ERROR_CREDIT_BEYOUND_AVAILABLE(20039,"信用额度超过可用额度!"),
	ERROR_CREDIT_NOT_RIGHT(20040,"输入信用额度信息错误!"),
	ERROR_CREDIT_IS_OCCUPY(20041,"您在{0}_下的信用额度被冻结,不能使用!"),
	ERROR_GET_PRICE_GROUP(20050,"查询价格组失败"),


	/**
	 * 地址相关错误信息 add by zhanghs 2016-3-6
	 */
	ERROR_ADDRESS_GET_FILL(20100, "获取用户收货地址失败"),
	ERROR_ADDRESS_GET_INVOICE(20102, "获取用户收票地址失败"),
	ERROR_ADDRESS_GET_CONSTRACT(20102, "获取用户合同地址失败"),
	ERROR_ADDRESS_EMPTY_CONSTRACT(20102, "您勾选了邮寄合同，请填写合同邮寄地址!"),
	ERROR_ADDRESS_EMPTY_BILLING(20103, "请选择账单寄送地址!"),

	/**
	 * 乐豆相关错误信息,错误码以20200开始 add by zhanghs 2016-3-11
	 */
	ERROR_LEBEAN_COUNT_ILLEGAL(20200,"乐豆数量非法！"),
	ERROR_LEBEAN_NOTENOUGHT(20201,"使用乐豆数量大于商品最大支持使用乐豆数量!"),
	ERROR_LEBEAN_GET_FAIL(20202,"获取乐豆失败！"),
	ERROR_LEBEAN_MORETHEN_USABLECOUNT(20203,"使用乐豆大于最大可以使用乐豆数!"),
	ERROR_LEBEAN_CONSUME_FAIL(20204,"消费乐豆失败!"),
	ERROR_LEBEAN_RETURN_FAIL(20205,"退回乐豆失败!"),
	ERROR_LEBEAN_CONFIRM_FAIL(20206,"确认乐豆订单号失败!"),

	//积分错误
	ERROR_SMBSCORE_NOTENOUGHT(20207,"可使用积分不足!"),
	ERROR_SMBSCORE_GET_FAIL(20208,"获取用户积分信息失败!"),
	ERROR_SMBSCORE_CONSUME_FAIL(20204,"消费积分失败!"),
	ERROR_SMBSCORE_RETURN_FAIL(20205,"退回积分失败!"),


	/**
	 * L码相关错误,错误码以20300开始 add by zhanghs 2016-6-17
	 */
//	ERROR_KCODE_SUCCEED(0,"00","成功"),
	ERROR_KCODE_FAIL(20350,"02","L码操作失败"),
	ERROR_KCODE_NOT_START(20300,"0101","L码活动还未开始"),
	ERROR_KCODE_NOT_EXIST(20301,"0102","L码不存在"),
	ERROR_KCODE_EXPIRE(20302,"0103","L码已过期"),
	ERROR_KCODE_ALREADY_USED(20303,"0104","L码已使用"),
	ERROR_KCODE_NOT_SUPPORT_PRODUCT(20304,"0105","非L码商品"),


	/**
	 * 发票错误信息
	 */

	INVOICE_ERROR(30000,"发票信息有误!"),
	ERROR_VAT_NOT_MATCH(20354,"公司名称和税号不匹配，请核实后再提交"),
	/**
	 * 增票错误信息,错误码以20300开始 add by zhanghs 2016-6-27
	 */
	ERROR_VAT_SYSTEM_UNKNOWN_EXCEPTION(20350,"10001","系统异常错误"),
	ERROR_VAT_COM_REQURIE(20351,"10002","必填的参数错误"),
	ERROR_VAT_NOTEXIST(20352,"10003","值税发票信息不存在或未通过审核"),
	ERROR_VAT_NOT_SHARD(20353,"10004","增值税发票未共享"),
	ERROR_VAT_NOT_AUTH(102,"开增值税专用发票，请先进行企业认证。"),
	ERROR_VAT_NOT_UPLOAD(103,"发票抬头与认证公司名称不一致，请上传关联关系证明"),
	ERROR_VAT_NOT_FOUND(104,"未查询到发票信息"),
	ERROR_VAT_THROWREPEAT(101,"发票内容数据已经存在，请确认是否重复"),
	ERROR_VAT_TAXITDEXISTENT(105,"该税号已经创建过发票"),
	//发票完整性校验
	ERROR_VAT_CONTENT_ISNULL(200254,"请填写发票抬头信息!"),
	ERROR_VAT_PROVICE_ISNULL(200255,"请选择发票省份!"),
	ERROR_VAT_CITY_ISNULL(200256,"请选择发票城市!"),
	ERROR_VAT_COUNTRY_ISNULL(200257,"请选择发票区/县!"),
	ERROR_VAT_ZIP_ISNULL(200258,"请填写发票邮政编码!"),
	ERROR_VAT_ADDRESS_ISNULL(200259,"请填写发票注册地址!"),
	ERROR_VAT_PHONE_ISNULL(200260,"请填写发票注册电话!"),
	ERROR_VAT_TYPE_ERROR(200261,"发票类型错误，只能是普票或者是增票!"),
	ERROR_VAT_BANKNAME_ISNULL(200262,"请填写发票银行名称!"),
	ERROR_VAT_TAXNO_ISNULL(200263,"请填写发票税号!"),
	ERROR_VAT_BANKNO_ISNULL(200264,"请填写发票银行账号!"),
	ERROR_VAT_PROVICENO_ISNULL(200265,"请选择正确的发票省份！"),



	ERROR_ORDER_NOT_MONEY(30001,"下单失败，订单金额不能小于或等于0元!"),
	ERROR_GET_SALETYPE(30002,"销售类型获取错误!"),
	ERROR_ORDER_CANCEL(30003,"订单取消失败!"),
	CHOOSE_CONSOLIDATED_INVOICES(30004,"请选择是否合并开票!"),
	ERROR_INVOICE_NOTEMPTY(30005,"发票抬头不能为空!"),
	ERROR_INVOICE_NOT_MORETHAN_100(30006,"发票抬头不能大于100个字符!"),
	ERROR_REGISTERED_ADDRESS_NOT_EMPTY(30007,"注册地址不能为空!"),
	ERROR_REGISTERED_ADDRESS_NOT_MORETHAN_100(30008,"注册地址不能大于100个字符!"),
	ERROR_BANK_ACCOUNT_NOT_EMPTY(30009,"开户银行不能为空!"),
	ERROR_BANK_ACCOUNT_NOT_MORETHAN_100(30010,"开户银行不能大于100个字符!"),
	ERROR_UPLOAD_TWO_PHOTOS(30011,"请上传两张资质图片!"),
	ERROR_INVOICE_ADDRESSEE_NOT_EMPTY(30012,"发票收件人姓名不能为空!"),
	ERROR_INVOICE_ADDRESSEE_NOT_MORETHAN_50(30013,"发票收件人姓名不能大于50个字符!"),
	ERROR_INVOICE_ADDRESSEE_PROVINCE_NOT_EMPTY(30014,"发票收件人所在省份或城市或区县不能为空!"),
	ERROR_INVOICE_ADDRESSEE_INFO_NOT_EMPTY(30015,"发票收件人地址明细不能为空!"),
	ERROR_INVOICE_ADDRESSEE_INFO_NOT_MORETHAN_100(30016,"发票收件人地址明细不能大于100个字符!"),
	ILLEGAL_TAXPAYER_IDENTIFICATION_CODE(30017,"纳税人识别码不合法，不能包含除数字和字母以外的数据!"),
	ERROR_SAME_PHOTOS(30018,"请不要上传两张一模一样的图片资质，否则审核无法通过，无法开具增值税发票! "),


	ERROR_ORDER_NOT_MONEY_2(30019,"下单失败，订单金额不能小于0元!"),
	ERROR_ORDER_NULL_ZPID(30020,"请填写增票信息!"),
	ERROR_ORDER_NULL_SPID(30021,"请填写并选择发票邮寄地址!"),
	ERROR_ORDER_SP_ADDRESS(30022,"收票地址错误!"),
	ERROR_ORDER_SP_PROVICENO(30023,"收票地址省份错误!"),
	ERROR_ORDER_SMB_FPID(30024,"请填写并选择发票信息!"),
	ERROR_ORDER_SMB_NULL_PAYNAME(30025,"付款方名称不能为空!"),
	ERROR_ORDER_SMB_PERSON_VAT_CONFIRM(30026,"开个人发票需要勾选【确认此订单是代公司采购，承诺向联想提供信息及开票请求的真实性，并承担因上述开票请求与实际企业经营活动不符而造成的任何税务和/或法律后果】选项"),
	ERROR_ORDER_SMB_INVOICE(30027,"请填写并选择发票信息!"),
	ERROR_ORDER_SMB_GET_INVOICE_FAIL(30028,"获取发票信息错误!"),
	ERROR_ORDER_SMB_GET_INVOICE_NOTALLOW(30029,"个人不允许开增值税发票!"),
	ERROR_ORDER_NOT_ALLOW_VAT(30030,"该用户不允许开增值税发票!"),

	ERROR_CONSIGNEE_NAME_ISNULL(30031,"xxx收货人不能为空!"),
	ERROR_CONSIGNEE_COMPANY_ISNULL(30032,"xxx收货公司不能为空!"),
	ERROR_CONSIGNEE_PHOME_ISNULL(30033,"xxx手机号不能为空!"),
	ERROR_CONSIGNEE_PROVICE_ISNULL(30034,"xxx省份不能为空!"),
	ERROR_CONSIGNEE_CITY_ISNULL(30035,"xxx城市不能为空!"),
	ERROR_CONSIGNEE_COUNTY_ISNULL(30036,"xxx区/县不能为空!"),
	ERROR_CONSIGNEE_TOWERSHIP_ISNULL(30037,"xxx乡镇不能为空!"),
	ERROR_CONSIGNEE_ZIP_ISNULL(30038,"xxx邮政编码不能为空!"),
	ERROR_CONSIGNEE_ADDRESS_ISNULL(30039,"xxx详细地址不能为空!"),
	ERROR_CONSIGNEE_ROVICE_WRONG(30040,"地址省份信息错误!"),
	ERROR_ORDER_SMB_PAYNAMETYPE(30041,"付款方类型错误!"),
	ERROR_ORDER_SMB_ZP_PAYNAMETYPE_MUST_COMPANY(30042,"开增值税发票，付款方类型必须是公司!"),
	ERROR_ORDER_SMB_GR_PAYNAMETYPE_MUST_COMPANY(30043,"开个人发票，付款方类型必须是个人!"),


	ERROR_ORDER_REMARK(40000,"订单备注不能大于150个字符！"),
	ERROR_ORDER_MANAGERCODE(40001,"客服经理编码不能大于20个字符！"),
	ERROR_ORDER_PAYTYPE(40002,"支付方式错误!"),
	ERROR_ORDER_INVOICE_HEADER_TYPE(40008,"增票属性请选择个人还是公司!"),
	ERROR_ORDER_INVOICE_TYPE(40003,"请选择发票类型!"),
	ERROR_ORDER_INVOICE_CONTENT(40004,"开公司发票必须填写公司抬头!"),

	ERROR_ORDER_CONSIGNEE(40007,"收货地址错误！"),

	ERROR_ORDER_O2O_NOTSUPPORT(40010,"这座城市正在积极备货中……"),
	ERROR_ORDER_KCODE_BLANK(40011,"购买L码商品L码不能为空!"),
	ERROR_ORDER_KCODE_NOTFIX(40012,"L码与商品不匹配!"),
	ERROR_ORDER_KCODE_WRONG(40013,"L码输入错误!"),
	ERROR_ORDER_SNCODE_BLANK(40014,"需要输入正确的机器编号才能购买此服务！"),
	ERROR_ORDER_CUSTOMERTIME_BLANK(40015,"定制商品购买时间不能为空！"),
	ERROR_ORDER_CUSTOMERTIME_WRONG(40016,"定制商品不在预约时间或购买时间段内!"),

	ERROR_ORDER_ISNOT_FIRSTORDER(40019,"该用户不享受首次下单"),
	ERROR_ORDER_RESOURCE(40020,"获取订单来源信息失败！"),
	ERROR_ORDER_SALESTYPE(40021,"不支持同时获取多个销售类型！"),
	ERROR_ORDER_COUPON(40022,"优惠券无效!"),
	ERROR_ORDER_USECOUPON(40023,"使用优惠券失败!"),
	ERROR_ORDER_COUPONCODE(40024,"使用优惠码失败!"),
	ERROR_ORDER_CONFIRM_STOCK(40027,"确认库存失败!"),
	ERROR_ORDER_ROLLBACK_STOCK(40028,"回退库存失败!"),
	ERROR_ORDER_NOT_ALLOW_COUPON(40029,"不允许使用优惠券!"),
	ERROR_ORDER_NOT_ALLOW_COUPONCODE(40030,"不允许使用优惠码!"),
	ERROR_ORDER_NOT_ALLOW_LEBEAN(40031,"不允许使用乐豆!"),

	ERROR_ORDER_COIUPON_NOSUPPORT(40032,"该类型的优惠券不支持叠加使用!"),
	ERROR_ORDER_CONFIRM_COUPON(40033,"确认优惠券订单号失败"),
	ERROR_ORDER_CONFIRM_COUPONCODE(40034,"确认优惠码订单号失败"),
	ERROR_ORDER_CONFIRM_LEBEAN(40035,"确认乐豆订单号失败!"),
	ERROR_ORDER_ZC_INVOICE(40036,"众筹商品不能开增值税发票!"),
	ERROR_ORDER_MBG_COUNT_QUOTA(40037,"同一用户在一财年内购买MBG的商品数量不能超过三个"),

	ERROR_ORDER_EMPTY_PAYTYPE(40038,"请选择支付方式"),
	ERROR_ORDER_EMPTY_CONSIGN(40039,"请选择收货地址"),
	ERROR_ORDER_COUPON_ONLYONE(40040,"同一优惠券只能使用一张!"),
	ERROR_ORDER_VONDER_COUPON(40041,"代金券使用额度不能超过该商品的最大优惠额度{0}元"),
	ERROR_ORDER_IDENTITY(40042,"请先填写身份认证信息!"),
	ERROR_ORDER_GIFT_COUPON(40043,"大礼包券使用额度不能超过该商品的最大优惠额度{0}元"),
	ERROR_ORDER_INVOICE(40044,"请保存增票信息!"),

	ERROR_GET_MAKER_SOFT_RESERVATIONID(50001,"查询moto maker 软锁失败"),
	ERROR_GIFT_COST_PRICE_NULL(50002,"赠品成本价为null"),
	ERROR_GET_MAKER_DETAIL(50003,"查询moto maker定制信息失败"),
	ERROR_USER_LIMEI(50004,"账号异常!"),

	ERROR_GET_PRICE_LIST(60001,"查询报价单信息失败"),
	ERROR_GET_INVOICE(60002,"查询发票信息失败"),
	ERROR_GET_PRICE_LIST_ORDERED(60003,"报价单已生成订单"),
	ERROR_GET_PRICE_LIST_EXPIRED(60004,"报价单已过期"),
	ERROR_GET_PRICE_LIST_EXISTS(60005,"报价单号已存在"),
	ERROR_GET_PRICE_LIST_CREATEPDF(60006,"报价单号生成pdf失败"),
	//
	ERROR_UPLOAD_File(69999,"上传文件错误!"),
	//预售
	ERROR_PRESALEMOBILE_EMPTY(70001,"尾款支付联系方式不能为空！"),
	ERROR_ORDER_PREPAYTYPE(70002,"预售付款方式错误!"),
	ERROR_PRESALE_DEPOSIT_NOT_MONEY(70003,"下单失败，尾款金额不能小于或等于0元!"),
	ERROR_PRESALE_REST_NOT_MONEY(70004,"下单失败，定金金额不能小于或等于0元!"),

	//动态数据
	ERROR_TOTALPAY_USE(80000,"商品{0}的总的优惠额度超过{1}%!"),
	ERROR_COUPON_COUPONCODE_USE(80001,"商品{0}优惠券，优惠码总的优惠额度超过{1}%!"),
	ERROR_WINCONTROL_BLACKLIST(80002,"进入黑名单，不允许下单"),
	ERROR_WINCONTROL_GRATHER_MAXBUY(80003,"购买数量超过购买上限"),
	ERROR_COUPON_USE(80004,"商品{0}优惠券总的优惠额度超过{1}%!"),

	//税收
	ERROR_TAX_INTERFACE(9000,"计算商品收税金额错误!"),
	ERROR_DELIVER_GOODSTYPE(9001,"送货方式是错误!"),
	ERROR_ADDRESS(9002,"收货地址错误!"),
	ERROR_BILDING_ADDRESS(9003,"账单地址错误!"),
	ERROR_ADDRESS_TAXNO(9004,"收货地址税号错误!"),
	ERROR_BILING_ADDRESS_TAXNO(9005,"账单地址税号错误!"),
	ERROR_ADDRESS_NOTFIND_STOCK(9006,"收货地址没有匹配到仓库!"),

	ERROR_SYSTEM_EXCEPTION(99999,"网络异常"),
	;
	private int code;// 代号
	private String remoteCode;//其他系统状态码
	private String common;// 说明

	ErrorMessageEnum(Integer code, String common) {
		this.code = code;
		this.common = common;
	}

	ErrorMessageEnum(Integer code, String remoteCode, String common) {
		this.code = code;
		this.remoteCode = remoteCode;
		this.common = common;
	}


	private final static Map<String,ErrorMessageEnum> kcodeMap = new HashMap();
	private final static Map<String,ErrorMessageEnum> vatMap = new HashMap();
	public final static Map<String,ErrorMessageEnum> WINCONTROL = new HashMap();
	public final static Map<String,ErrorMessageEnum> TAXCALCULATE = new HashMap();
	public final static Map<String,ErrorMessageEnum> CREDIT = new HashMap();
	public final static Map<String,ErrorMessageEnum> STOCK = new HashMap();
	static {
		//设置L码状态码
		kcodeMap.put("00",SUCCESS);
		kcodeMap.put("02",ERROR_KCODE_FAIL);
		kcodeMap.put("0101",ERROR_KCODE_NOT_START);
		kcodeMap.put("0102",ERROR_KCODE_NOT_EXIST);
		kcodeMap.put("0103",ERROR_KCODE_EXPIRE);
		kcodeMap.put("0104",ERROR_KCODE_ALREADY_USED);
		kcodeMap.put("0105",ERROR_KCODE_NOT_SUPPORT_PRODUCT);

		//设置增票状态码
		vatMap.put("1000",SUCCESS);
		vatMap.put("10001",ERROR_VAT_SYSTEM_UNKNOWN_EXCEPTION);
		vatMap.put("10002",ERROR_VAT_COM_REQURIE);
		vatMap.put("10003",ERROR_VAT_NOTEXIST);
		vatMap.put("10004",ERROR_VAT_NOT_SHARD);
		vatMap.put("10007",ERROR_VAT_NOT_MATCH);
		//风控错误提示转换
		WINCONTROL.put("0000", SUCCESS);
		WINCONTROL.put("0001", ERROR_PARAM);
		WINCONTROL.put("0002", ERROR_WINCONTROL_BLACKLIST);
		WINCONTROL.put("0003", ERROR_WINCONTROL_GRATHER_MAXBUY);
		//算税收错误提示转换
		TAXCALCULATE.put("2001",ERROR_ADDRESS);
		TAXCALCULATE.put("2002",ERROR_BILDING_ADDRESS);
		TAXCALCULATE.put("2003",ERROR_ADDRESS_TAXNO);
		TAXCALCULATE.put("2004",ERROR_BILING_ADDRESS_TAXNO);
		TAXCALCULATE.put("2005",ERROR_ADDRESS_NOTFIND_STOCK);
		TAXCALCULATE.put("1000",SUCCESS);
		TAXCALCULATE.put("9999",ERROR_TAX_INTERFACE);

	}

	public interface RemoteCodeConvert{


		//收货地址
		/*public enum AddressCodeEnum {
			private String code;
			private ErrorMessageEnum errmsg;
			public String getCode() {
				return code;
			}
			public void setCode(String code) {
				this.code = code;
			}
			public ErrorMessageEnum getErrmsg() {
				return errmsg;
			}
			public void setErrmsg(ErrorMessageEnum errmsg) {
				this.errmsg = errmsg;
			}
			private AddressCodeEnum(String code, ErrorMessageEnum errmsg) {
				this.code = code;
				this.errmsg = errmsg;
			}


		}*/
		//老发票
		public enum InvoiceCodeEnum{

		}
		//新发票--老马
		public enum VatCodeEnum{

		}
		//优惠券，优惠码
		public enum CouponCodeEnum{

		}
		//K码
		public enum KcodeCodeEnum{

		}
		//乐豆
		public enum LdouCodeEnum{

		}
		//库存
		public enum StockCodeEnum{

		}
		//风控
		public enum WindControlCodeEnum{

		}
		//信用额度
		public enum CrediCodeEnum{

		}
		//促销
		public enum PromotionCodeEnum{

		}
		//接单
		public enum ReceiverCodeEnum{

		}
		//省市县
		public enum ProviceCityCodeEnum{

		}
		//上传服务
		public enum UpdateLoadFileCodeEnum{

		}
	}




	/**
	 * @Author zhanghs 【zhanghs6@lenovo.com】
	 * @Description:  通过L码服务的状态码得到转换后的对于的本地系统的状态码
	 *
	 * @date 2016/6/17 19:59
	 * @return
	 */
	public static ErrorMessageEnum getKcodeByRemoteCode(String code){
		return getValueByCode(kcodeMap,code);
	}

	/**
	 * @Author zhanghs 【zhanghs6@lenovo.com】
	 * @Description: 通过增票服务的状态码得到转换后的对于的本地系统的状态码
	 *
	 * @date 2016/6/27 14:24
	 * @return
	 */
	public static ErrorMessageEnum getVatByRemoteCode(String code){
		if("1000".equals(code)){
			return SUCCESS;
		}else if("10007".equals(code)){
			return ERROR_VAT_NOT_MATCH;
		}
		return FAIL;
		/*return getValueByCode(vatMap,code);*/

	}

	private static ErrorMessageEnum getValueByCode(Map<String,ErrorMessageEnum> map,String code){
		ErrorMessageEnum errorMessageEnum = map.get(code);
		if (errorMessageEnum == null) {
			if(String.valueOf(SUCCESS.getCode()).equals(code)){
				return SUCCESS;
			}else if (String.valueOf(ERROR_SYSTEM_EXCEPTION.getCode()).equals(code)){
				return ERROR_SYSTEM_EXCEPTION;
			}else if (String.valueOf(FAIL.getCode()).equals(code)){
				return FAIL;
			}else{
				return FAIL;
			}
		}

		return errorMessageEnum;
	}

	public int getCode() { return code; }
	public void setCode(int code) { this.code = code; }
	public String getCommon() {
		return common;
	}
	public void setCommon(String common) {
		this.common = common;
	}
//	static  Map<String, String> map = new TreeMap<String, String>();
	/**
	 * 获取枚举类型的所有<值,名称>对
	 *
	 * @return
	 */
//	public static Map<String, String> toMap() {
//		if(map.size() > 0){
//			return map;
//		}
//		for (int i = 0; i < ErrorMessageEnum.values().length; i++) {
//			map.put(ErrorMessageEnum.values()[i].getCode(), ErrorMessageEnum.values()[i].getCommon());
//		}
//		return map;
//	}

	public static void main(String[] args) {
		Map<String,String> map = new HashMap<>();
		String a = null;
		map.get(a);
		System.out.println("=======");
	}

}
