package com.lenovo.m2.hsbuy.common.util;

import com.alibaba.fastjson.JSONObject;
import com.lenovo.open.gateway.java.sdk.JavaSDKClient;
import com.lenovo.open.gateway.java.sdk.util.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.HashMap;

/**
 * @Description: 调用开放平台发送短信工具类
 * @Author: ShaoYuanHu
 * @Date: Created in 2017-12-21
 */
public class SMSUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(SMSUtil.class);

    private String appKey;
    private long appId;
    private long activeId;

    private String openapiUrl;
    private String openapiAppKey;
    private String openapiScrebt;
    private String method;

    public boolean send(String content,String mobile){
        //调用开放平台发送短信
        try {
            long timeStamp = System.currentTimeMillis();
            String md5Key = MessageMD5Utils.md5Digest(appId + appKey + timeStamp);
            HashMap<String, Object> paraMap = new HashMap<>();
            paraMap.put("mobile",mobile);
            paraMap.put("content",content);
            paraMap.put("timeAt",timeStamp);
            paraMap.put("appId",appId);
            paraMap.put("activeId", activeId);
            paraMap.put("key", md5Key);
            paraMap.put("useMarket", true);
            paraMap.put("isInner", true);

            Response response = JavaSDKClient.proxy(openapiUrl, openapiAppKey, openapiScrebt, method, paraMap, null);
            JSONObject jsonObject = JSONObject.parseObject(response.getBody().toString());
            if (jsonObject.getBoolean("success")) {
                JSONObject object = jsonObject.getJSONObject("result").getJSONObject(String.format("%s_response", method.replaceAll("\\.", "_")));
                Integer code = object.getInteger("code");
                if (code==1){
                    //发送成功
                    LOGGER.info("ShortMessageUtil==短信发送成功，方法==" + method);
                    return true;
                }else {
                    String msg = object.getString("msg");
                    LOGGER.info("ShortMessageUtil==短信发送失败，方法==" + method+"==错误信息=="+msg+"==手机号=="+mobile+"==短信内容=="+content);
                    return false;
                }
            } else {
                LOGGER.info("ShortMessageUtil==调用开放平台失败，方法==" + method);
                return false;
            }
        } catch (Exception e) {
            LOGGER.info("ShortMessageUtil==调用开放平台失败，方法=="+method);
            return false;
        }

    }

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public long getAppId() {
        return appId;
    }

    public void setAppId(long appId) {
        this.appId = appId;
    }

    public long getActiveId() {
        return activeId;
    }

    public void setActiveId(long activeId) {
        this.activeId = activeId;
    }

    public String getOpenapiUrl() {
        return openapiUrl;
    }

    public void setOpenapiUrl(String openapiUrl) {
        this.openapiUrl = openapiUrl;
    }

    public String getOpenapiAppKey() {
        return openapiAppKey;
    }

    public void setOpenapiAppKey(String openapiAppKey) {
        this.openapiAppKey = openapiAppKey;
    }

    public String getOpenapiScrebt() {
        return openapiScrebt;
    }

    public void setOpenapiScrebt(String openapiScrebt) {
        this.openapiScrebt = openapiScrebt;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }
}
