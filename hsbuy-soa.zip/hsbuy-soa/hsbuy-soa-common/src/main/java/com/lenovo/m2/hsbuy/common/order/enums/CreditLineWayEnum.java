package com.lenovo.m2.hsbuy.common.order.enums;

/**
 * Created by zhaocl1 on 2017/9/21.
 */
public enum  CreditLineWayEnum {

    NOUSE("不用信用额度",0),
    PARTUSE("部分使用信用额度",1),
    ALLUSE("全部使用信用额度",2);

    private String name;
    private int value;

    CreditLineWayEnum(String name, int value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public int getValue() {
        return value;
    }
}
