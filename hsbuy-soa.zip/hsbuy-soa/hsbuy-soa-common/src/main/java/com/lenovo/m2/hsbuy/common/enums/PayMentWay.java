package com.lenovo.m2.hsbuy.common.enums;

/**
 * Created by pxg01 on 2017/7/24.
 * 付款方式
 */
public enum  PayMentWay {

    ALL_PAY(1,"全款"),
    PART_PAY(0,"部分付款");
    PayMentWay(Integer code,String dec){
        this.code = code;
        this.dec = dec;
    }
    private Integer code;
    private String dec;

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getDec() {
        return dec;
    }

    public void setDec(String dec) {
        this.dec = dec;
    }
}
