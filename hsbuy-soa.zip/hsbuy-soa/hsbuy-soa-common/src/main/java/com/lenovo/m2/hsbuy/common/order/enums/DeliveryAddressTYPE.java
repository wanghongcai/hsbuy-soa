package com.lenovo.m2.hsbuy.common.order.enums;

/**
 * Created by zhaocl1 on 2017/5/23.
 */
public enum DeliveryAddressTYPE {

    TYPE_DELIVERY("送达方地址",0),
    TYPE_VAT("发票寄送地址",1),
    TYPE_CONTRACT("合同寄送地址",2);

    private String name;
    private int value;

    DeliveryAddressTYPE(String name, int value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public int getValue() {
        return value;
    }
}
