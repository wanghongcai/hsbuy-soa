package com.lenovo.m2.hsbuy.common.smb17;

/**
 * Created by xuweihua on 2016/7/26.
 */
public class InvoiceShopCode {
    //参数错误
    public static final String PARAMETER_ERROR_CODE = "10001";
    public static final String SUCCESS = "0000";
    public static final String FAIL = "9999";
    public static final String IRDNUMBERREPEAT = "101"; //发票内容重复
    public static final String NOTAUTH = "102"; //公司未认证
    public static final String NOUPLOAD = "103"; //未上传关联证明
    public static final String VATNOTEXISTENT = "104"; //发票信息不存在
    public static final String IRDNUMBEREXISTENT = "105"; //税号重复使用
}
