package com.lenovo.m2.hsbuy.common.order.enums;

/**
 * Created by zhaocl1 on 2017/5/27.
 */
public enum  CouponTypeEnum {

    COMMON("普通券",1),
    C2C("专属c2c",4),
    OLD2NEW("专属--依旧换新",6),
    OLD2NEW_CASH("专属-依旧换新代金券",7);

    private String name;
    private int value;

    private CouponTypeEnum(String name, int value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public int getValue() {
        return value;
    }
}
