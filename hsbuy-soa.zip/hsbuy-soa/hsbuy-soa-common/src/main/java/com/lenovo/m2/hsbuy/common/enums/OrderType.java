package com.lenovo.m2.hsbuy.common.enums;

/**
 * Created by pxg01 on 2017/7/24.
 */
public enum  OrderType {

    NORMAL_ORDER(0,"正常订单"),
    PRESELL_ORDER(1,"预售订单");
    OrderType(Integer code,String dec){
        this.code = code;
        this.dec = dec;
    }
    private Integer code;
    private String dec;

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getDec() {
        return dec;
    }

    public void setDec(String dec) {
        this.dec = dec;
    }
}
