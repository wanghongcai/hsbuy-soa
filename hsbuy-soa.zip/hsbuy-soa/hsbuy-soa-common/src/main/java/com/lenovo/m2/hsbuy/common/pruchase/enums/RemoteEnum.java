package com.lenovo.m2.hsbuy.common.pruchase.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * @author zhanhgs
 * @version V1.0
 * @Title: ${file_name}
 * @Package ${package_name}
 * @Description: 调用远程资源错误码说明
 * @date 2016/3/12 17:14
 */

public  class RemoteEnum {

    /*==============================================远程调用乐豆服务返回码=======================================*/

    public static enum LeBean{
        SUCCEED("001","成功"),
        CODE_ERROR("002","code的编码不对"),
        USERID_DEFICIENCY("003","userId 缺失"),
        OPERATE_ILLEGAL("004","操作非法"),
        TIMESTAMP_WRONG("005","时间戳不正确"),
        REQUEST_ILLEGAL("006","非法请求"),
        COUNT_NOT_ENOUGH("007","用户乐豆数量不足，无法进行后续操作"),
        CALL_EXCEPTION("008","调用乐豆异常"),
        RETURN_DATA_EXCEPTION("009","返回数据异常"),
        PARAM_DEFICIENCY("010","log参数缺失"),
        BASK_WORK_ORDER_DEFICIENCY("011","bask_work_order缺失");
        private String code;// 代号
        private String common;// 说明
        private static Map<String,LeBean> map = new HashMap<>();
        LeBean(String code, String common) {
            this.code = code;
            this.common = common;
        }

        public String getCode() {
            return code;
        }

        public String getCommon() {
            return common;
        }

        static{
            for(LeBean type: LeBean.values()){
                map.put(type.code, type);
            }
        }

        public static LeBean getLeBean(String code){
            return map.get(code);
        }
    }


      /*==============================================远程调用L码服务返回码=======================================*/

    public static enum Kcode{

        SUCCEED("00","成功"),
        FAIL("02","操作失败"),
        KCODE_NOT_START("0101","L码活动还未开始"),
        KCODE_NOT_EXIST("0102","L码不存在"),
        KCODE_EXPIRE("0103","L码已过期"),
        KCODE_ALREADY_USED("0104","L码已使用"),
        KCODE_NOT_SUPPORT_PRODUCT("0105","非L码商品");

        private String code;// 代号
        private String common;// 说明
        private static Map<String,Kcode> map = new HashMap<>();
        Kcode(String code, String common) {
            this.code = code;
            this.common = common;
        }

        public String getCode() {
            return code;
        }

        public String getCommon() {
            return common;
        }

        static{
            for(Kcode type: Kcode.values()){
                map.put(type.code, type);
            }
        }

        public static Kcode getKcode(String code){
            return map.get(code);
        }
    }

 /*==============================================远程调用库存服务返回码=======================================*/

    public static enum Stock{

        STOCK_SUCCESS("1000", "成功!"),
        STOCK_NOT_EXIST("1001", "库存不存在"),
        STOCK_MORE_THANONE("1002", "找到多条库存!"),
        STOCK_NOT_ENOUGH("1004", "库存不足!"),
        STOCK_CONDITION_NO("1005", "条件不满足！"),
        STOCK_OREERA_FAIL("1007", "操作失败!"),
        STOCK_FAIL("9999","占用库存失败！"),
        ;
        private String code;// 代号
        private String common;// 说明

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public String getCommon() {
            return common;
        }

        public void setCommon(String common) {
            this.common = common;
        }

        Stock(String code, String common) {
            this.code = code;
            this.common = common;
        }

        static  Map<String, String> map = new HashMap<String, String>();
        /**
         * 获取枚举类型的所有<值,名称>对
         *
         * @return
         */
        public static Map<String, String> toMap() {
            if(map.size() > 0){
                return map;
            }
            for (int i = 0; i < Stock.values().length; i++) {
                map.put(Stock.values()[i].getCode(), Stock.values()[i].getCommon());
            }
            return map;
        }
    }
}


