package com.lenovo.m2.hsbuy.common.pruchase.util;///**
// * Project Name:purchase-soa-common
// * File Name:DefaultNamespacePrefixMapper.java
// * Package Name:com.lenovo.m2.buy.purchase.common.util
// * Date:2016年9月20日下午6:26:45
// * Copyright (c) 2016, yuzj7@lenovo.com All Rights Reserved.
// *
//*/
//
//package com.lenovo.m2.buy.purchase.common.util;
//
//import java.util.HashMap;
//import java.util.Map;
//
//import com.sun.xml.bind.marshaller.NamespacePrefixMapper;
//
///**
// * ClassName:DefaultNamespacePrefixMapper <br/>
// * Function: TODO ADD FUNCTION. <br/>
// * Date:     2016年9月20日 下午6:26:45 <br/>
// * @author   yuzj7
// * @version  
// * @since    JDK 1.7
// * @see 	 
// */
//public class DefaultNamespacePrefixMapper extends NamespacePrefixMapper{
//
//	private Map<String, String> namespaceMap = new HashMap<>();
//    
//	/**
//	 * Create mappings.
//	 */
//	public DefaultNamespacePrefixMapper() {
//		namespaceMap.put("http://www.w3.org/2001/XMLSchema-instance", "xsi");
//		namespaceMap.put("http://www.w3.org/2001/XMLSchema", "xsd");
//		namespaceMap.put("http://www.w3.org/2003/05/soap-envelope/", "soap12");
//	}
// 
//	/* (non-Javadoc)
//	 * Returning null when not found based on spec.
//	 * @see com.sun.xml.bind.marshaller.NamespacePrefixMapper#getPreferredPrefix(java.lang.String, java.lang.String, boolean)
//	 */
//	@Override
//	public String getPreferredPrefix(String namespaceUri, String suggestion, boolean requirePrefix) {
//		String prefix = namespaceMap.get(namespaceUri);
//        if (prefix != null) {
//            return prefix;
//        }
//        return suggestion;
//	}
//}
//
