package com.lenovo.m2.hsbuy.common.pruchase.enums;

import com.lenovo.risk.api.ams.model.InvocieType;

import java.util.HashMap;
import java.util.Map;

/**
 * 发票类型
 */
public enum InvoiceType {
	
	E_INVOICE(0, "电子发票"), COMMON_INVOICE(1, "普通发票"), VALUE_ADDED_INVOICE(2, "增值发票"),NULL_(999,"不开发票");

	private final int type;
	private final String descr;

	private InvoiceType(int type, String descr){
		this.type = type;
		this.descr = descr;
	}
	
	private static Map<String,String>lookupmap =new HashMap<>();
	
	static{
		for(InvoiceType type: InvoiceType.values()){
			lookupmap.put(type.type+"", type.descr);
		}
		
	}
	
	public static String getNameByType(String type){
		return lookupmap.get(type);
	}
	public static boolean containsKey(int t){
		InvoiceType temp[] = InvoiceType.values();
		for(InvoiceType tt :temp){
			if(t == tt.getType()){
				return true;
			}
		}
		return false;
	}
	
	public int getType() {
		return type;
	}

	public String getDescr() {
		return descr;
	}

	public static enum TitleType{
		
		INDIVIDUAL(0, "个人"), CORPORATION(1, "公司");
		
		private final int type;
		private final String descr;
		
		private TitleType(int type, String descr){
			this.type = type;
			this.descr = descr;
		}

		public int getType() {
			return type;
		}

		public String getDescr() {
			return descr;
		}
		
		public static boolean containsKey(int t){
			TitleType temp[] = TitleType.values();
			for(TitleType tt :temp){
				if(t == tt.getType()){
					return true;
				}
			}
			return false;
		}
	}

	/**
	 * 订单的发票枚举类型转成风控的枚举类型
	 * @param type 订单发票类型 0 1 2 (-1 返回 null)
	 * @return
	 */
	public static  InvocieType getRiskInvoiceType(int type) {
		if (type == COMMON_INVOICE.getType()) {
			return InvocieType.NORMALINVOICE;//风控--普通发票类型
		} else if (type == VALUE_ADDED_INVOICE.getType()) {
			return InvocieType.INVOICE;//风控--增值税发票类型
		} else if (type == E_INVOICE.getType()) {
			return InvocieType.NORMALINVOICE;//风控--普通发票类型
		} else {
			return null;
		}
	}
}
