package com.lenovo.m2.hsbuy.common.pay.constants.ordersoa;

/**
 * Created by zhangxs7 on 2016/10/10.
 */
public class OrderPayConstance {
    public static Integer ORDER_TRACE_UNPAID=0;//未支付
    public static Integer ORDER_TRACE_PAID=1;//已支付

    public static Integer CHANNEL_ORDER_PAID_STATUS=1;//已支付
    public static Integer CHANNEL_ORDER_UNPAID_STATUS=0;//未支付

    public static String PRE_SELL_ORDER_TYPE="2";//预售的支付方式

    public static String SMB_SHOP_ID="8";//smb订单
    public static String PCSD_SHOP_ID="11";//PCSD

    public static Integer  ORDER_TRACE_ORDER_NOREMAL=0;//订单状态为可用
    public static Integer  ORDER_TRACE_ORDER_ABNOREMAL=1;//订单状态为可用

    public static Integer  CHANNEL_ORDER_NOREMAL=0;//订单状态为可用
    public static Integer  CHANNEL_ORDER_ABNOREMAL=1;//订单状态为可用

    public static Integer MAIN_FLAG_SUB=0;//子单标识

    public static Integer MAIN_FLAG_MAIN=1;//子单标识

    public static final String SHOPID_ROAMING = "4";
    public static final Integer UN_ONLINE_PAY = 2;

    public static String ORDER_PAY_STATUS_PRE="2";//预售 定金支付
    public static String ORDER_PAY_STATUS_ATTACH="1";//预售 尾款支付
    public static String ORDER_PAY_STATUS_ALL="3";//预售 全款支付

    public static Integer ORDER_PAY_STATUS_PRE_NUM=2;//预售 定金支付
    public static Integer ORDER_PAY_STATUS_ATTACH_NUM=1;//预售 尾款支付
    public static Integer ORDER_PAY_STATUS_ALL_NUM=3;//预售 全款支付

    public static final Integer PRESELL_WAY_ALL=1;//预售方式 1:全款  正常订单
    public static final Integer PRESELL_WAY_PRE=2;//预售方式 2:定金


    public static String ERR_NOT_FIND_ORDERMAIN="200";//未找到主单异常

    public static Integer PAYMENT_WAY_TRUE=1;//代收代付标识 1 代收代付
    public static Integer PAYMENT_WAY_FALSE=0;//代收代付标识 0 非代收代付

    public final static String TRAN_ID_LAST_INDEX="0001";

    public static Integer ORDER_STATUS_DISABLE=1;//订单状态 1 不可用
    public static Integer ORDER_STATUS_USABLE=0;//订单状态 0 可用


    public static Integer PAY_WAY_ALL=3;//全款支付
    public static Integer PAY_WAY_PRE=2;//定金支付
    public static Integer PAY_WAY_ATTACH=1;//尾款支付

    public static Integer CMB_FEFNQI=24;
    public static Integer CMB_FEFNQI_PAY=21;

    // 订单类型
    public static String ORDER_TYPE_CREDIT = "15";
    // 支付终端微信小程序
    public static String TERMINAL_WECHAT_APPLET = "5";

}
