package com.lenovo.m2.hsbuy.common.order.enums;

/**
 * Created by zhaocl1 on 2017/6/2.
 */
public enum FaTypeEnum {

    DIRECT("直营",0),
    PROXY("代理",1),
    SMB_TOTAL_PROXY("smb总代",7),
    SMB_DIRECT("smb直营",8);


    private String name;
    private int value;

    FaTypeEnum(String name, int value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public int getValue() {
        return value;
    }
}
