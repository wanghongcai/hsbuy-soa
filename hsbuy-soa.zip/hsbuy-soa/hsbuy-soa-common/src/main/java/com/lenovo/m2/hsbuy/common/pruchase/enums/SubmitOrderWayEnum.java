/**
 * Project Name:purchase-soa-common
 * File Name:SubmitOrderWayEnum.java
 * Package Name:com.lenovo.m2.buy.purchase.common.enums
 * Date:2016年8月2日下午2:59:31
 * Copyright (c) 2016, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.hsbuy.common.pruchase.enums;
/**
 * ClassName:SubmitOrderWayEnum <br/>
 * Function: 提交订单方式枚举. <br/>
 * Date:     2016年8月2日 下午2:59:31 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */
public enum SubmitOrderWayEnum {
	SILIENCE(1,"静默下单"),
	BYHAND(2,"手工下单"),
	ASKORDER(3,"询价单");
	private int way;
	private String common;
	public int getWay() {
		return way;
	}
	public void setWay(int way) {
		this.way = way;
	}
	public String getCommon() {
		return common;
	}
	public void setCommon(String common) {
		this.common = common;
	}
	private SubmitOrderWayEnum(int way, String common) {
		this.way = way;
		this.common = common;
	}
	
	
}

