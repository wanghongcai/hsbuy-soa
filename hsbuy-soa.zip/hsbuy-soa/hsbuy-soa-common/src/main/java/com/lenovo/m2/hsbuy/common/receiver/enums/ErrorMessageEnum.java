/**
 * Project Name:order-receiver-common
 * File Name:ErrorMessageEnum.java
 * Package Name:com.lenovo.m2.buy.order.receiver.common.enums
 * Date:2016年12月21日下午2:12:24
 * Copyright (c) 2016, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.hsbuy.common.receiver.enums;
/**
 * ClassName:ErrorMessageEnum <br/>
 * Function: TODO ADD FUNCTION. <br/>
 * Date:     2016年12月21日 下午2:12:24 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */
public enum ErrorMessageEnum {
	SUCCESS("0","SUCCESS"),
	ORDERFAIL("10000","下单失败"),
	GETORDERFAIL("10001","获取订单失败!");
	private String code;
	private String msg;
	
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}



	public void setMsg(String msg) {
		this.msg = msg;
	}

	private ErrorMessageEnum(String code, String msg) {
		this.code = code;
		this.msg = msg;
	}
	
	
}

