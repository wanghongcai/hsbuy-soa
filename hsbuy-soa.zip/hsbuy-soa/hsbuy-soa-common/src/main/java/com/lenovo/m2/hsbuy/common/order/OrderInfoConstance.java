package com.lenovo.m2.hsbuy.common.order;

/**
 * Created by fenglg1 on 2015/5/19.
 */
public class OrderInfoConstance {

    //订单未读取
    public static final int ORDER_NOT_READ = 0;
    //订单已读取
    public static final int ORDER_READ = 1;
    //支付推送
    public static String ORDER_PAY_PUSH_SUCCESS = "0";
    public static String ORDER_PAY_PUSH_FAILURE = "3";
    //已支付
    public static final int ORDER_PAY_STATUS_PAID = 1;
    public static final int ORDER_PAY_STATUS_UNPAID = 0;

    //订单状态（0：正常订单  1：异常订单  2：已取消  3：已撤销）
    public static final int ORDER_STATUS_NORMAL = 0;
    public static final int ORDER_STATUS_ABNORMAL = 1;
    public static final int ORDER_STATUS_CANCELED = 2;
    public static final int ORDER_STATUS_REVOKED = 3;

    // 0: 正常订单  1： 异常订单
    public static final int ORDER_IS_NORMAL = 0;
    public static final int ORDER_IS_ABNORMAL = 1;

    // 0: 未转移  1：转移成功
    public static final int ORDER_TRANSFER_NO_INVOKE = 0;
    public static final int ORDER_TRANSFER_SUCCESS = 1;


    public static final int AuditStatus_NoNeed = 0;//自动过审 即不需要审核
    public static final int AuditStatus_Passed = 1;//审核通过
    public static final int AuditStatus_Pending = 2;//待审核
    public static final int AuditStatus_NoPass = 3;//拒审
    public static final int AuditStatus_pendingHT = 4;//待生成合同
    public static final int AuditStatus_SignedHT = 5;//已签署合同

}
