package com.lenovo.m2.hsbuy.common.middleware;

import com.lenovo.m2.arch.tool.util.StringUtils;

/**
 * 返回信息
 *
 * @Author licy13
 * @Date 2017/4/11
 */

public enum ResultMessageEnum {


    SUCCESS("1000", "操作成功"),
    ERROR("9999", "异常"),

    /*物流*/

    //对外编码
    EXTERNAL_EMPTY("1", "参数为空"),
    EXTERNAL_SUCCESS("200", "成功"),
    EXTERNAL_XML_EMPTY("405", "xml参数为空"),
    EXTERNAL_ERROR_XML_DATA("406", "xml格式错误"),
    EXTERNAL_ERROR_DATE_DATA("407", "时间解析错误"),
    EXTERNAL_OPERATING_ERROR("500", "操作失败"),
    EXTERNAL_K100_DUPLICATE("501", "快递100重复订阅"),
    EXTERNAL_ERROR("999", "失败"),

    QUERY_ERROR("1010", "查询数据异常"),
    DATA_CONVERSION_ERROR("1011", "数据转换异常"),
    ERROR_XCX_DELIVERY("1202", "通知小程序发货失败"),
    UPDATE_SN_MATERIAL_CODE_NOTHING("1703", "未找到订单号与物料号匹配记录"),
    LOGISTICS_NO_NOTHING("1801", "未找到订单号与物流号匹配记录"),
    UPLOAD_ERROR("2000", "上传文件失败"),


    /*订单*/
    //签收信息
    SIGN_SUCCESS("7000","签收成功"),
    SIGN_REPETITION("7001","重复签收"),
    ERROR_NO_ORDER("1003", "无此订单"),
    ERROR_UPDATE_UPLOAD_STATUS("8880","更新mongoorder上传状态失败"),
    ERROR_NO_ONE_FACODE("9989", "付款记录不是针对同一个分销商"),
    ERROR_AUDIT_NO_PASS_UPDATE_MDB("9990", "付款信息审核拒绝更新MDB失败"),
    ERROR_AUDIT_PASS_UPDATE_MDB("9991", "付款信息审核通过更新MDB失败"),
    ERROR_AUDIT_STATUS("9992", "审核状态有误"),
    ERROR_PARSE_DATE("9993", "格式化付款时间异常"),
    ERROR_PAYMENT_ORDER_TOTALPAY("9994", "经销商录入金额小于订单应付金额"),
    ERROR_PAYMENT_PAYEE_TOTALPAY("9995", "分销商与经销商录入金额不一致"),
    EMPTY_MDB_ORDER("9996", "MDB订单信息为空"),
    EMPTY_PAYRECORDS_ORDERCODE("9997", "线下银行转账记录订单号为空"),
    EMPTY_PAYRECORDS("9998", "线下银行转账记录为空"),

    /*转移*/
    FAIL_CREP_GET_IS_INFO("9946", "调用CREP返回结果失败"),
    FAIL_UPDATE_CREP_IS_INFO("9947", "更新EPP企业信息失败"),
    EMPTY_CREP_GET_IS_INFO("9948", "调用CREP返回结果为空"),

    ERROR_UPDATE_ORDERCENTER_MOTO_ORDER_BILL("9949", "支付返回账单信息，更新全量库异常"),
    ERROR_UPDATE_PIPELINE_MOTO_ORDER_BILL("9950", "支付返回账单信息，更新管道异常"),


    ERROR_UPDATE_EXPECT_DATE("9951", "预期发货时间更新失败"),
    ERROR_NOT_REACH_TRANSFER_THROW_CONDITIONS("9952", "不能转移抛单库,未先转移全量库"),

    ERROR_SYNCHRONOUS_ORDERCENTER_ORDERCOUPONS("9953", "同步全量库插入OrderCoupons失败"),
    ERROR_SYNCHRONOUS_ORDERCENTER_ORDERCOUPONCODE("9954", "同步全量库插入OrderCouponCode失败"),


    ERROR_UPDATE_ORDERCENTER_REWARD_SCORE("9955", "更新全量库奖励积分信息失败"),
    ERROR_REWARD_SCORE("9956", "惠商奖励积分失败"),
    NO_MEET_REQUIREMENTS_GOODS("9957", "没有满足奖励积分需求的商品"),
    ERROR_SAVE_QUARTER_RECORD("9958", "保存惠商积分季度记录失败"),
    ERROR_SAVE_ORDER_SCORE("9959", "保存惠商订单积分信息失败"),

    EMPTY_GET_ITEMS_ORDER("9960", "获取订单信息为空"),
    ERROR_SMB_INVOICE_NOT_PASS("9961", "SMB发票未审核通过"),
    ERROR_GEN_TRANSFER_ORDERCENTER("9962", "转化成全量库对象异常"),
    EMPTY_GET_INVOICE_ID("9963", "发票ID为空"),
    ERROR_SAVE_INVOICE_INFO("9964", "保存发票信息失败"),
    ERROR_UPDATE_ORDERCENTER_PRESELLS_MAINDISCOUNT("9965", "更新全量库预售尾款奖励乐豆信息失败"),
    ERROR_UPDATE_ORDERCENTER_PRESELLS_MAIN("9966", "更新全量库预售尾款信息失败"),
    ERROR_UPDATE_INVOICE_ID("9967", "更新发票ID信息失败"),
    EMPTY_GET_PIPELINE_ORDER("9968", "获取管道订单信息为空"),
    ERROR_NOT_ADVANCE_TRANSFER_ORDERCENTER("9969", "未先转移全量库"),
    ERROR_REPEAT_TRANSFER("9970", "重新转移中..."),
    ERROR_NOT_REACH_TRANSFER_CONDITIONS("9971", "未达到转移条件"),
    ERROR_UPDATE_INVOICE_AUDIT("9972", "更新SMB发票审单信息失败"),
    ERROR_GET_INVOICE_AUDIT("9973", "获取SMB发票审单信息失败"),
    ERROR_SEND_EMAIL("9974", "发送邮件失败"),
    ERROR_SYNCHRONOUS_THROW_ORDERPAY("9975", "同步抛单库插入OrderPay失败"),
    ERROR_SYNCHRONOUS_THROW_DELIVERYADDRESS("9976", "同步抛单库插入DeliveryAddress失败"),
    ERROR_SYNCHRONOUS_THROW_IDENTITY("9977", "同步抛单库插入Identity失败"),
    ERROR_SYNCHRONOUS_THROW_ORDERINVOICE("9978", "同步抛单库插入OrderInvoice失败"),
    ERROR_SYNCHRONOUS_THROW_ORDERCOUPONS("9979", "同步抛单库插入OrderCoupons失败"),
    ERROR_SYNCHRONOUS_THROW_ORDERITEM("9980", "同步抛单库插入OrderItem失败"),
    ERROR_SYNCHRONOUS_THROW_ORDERMAIN("9981", "同步抛单库插入OrderMain失败"),
    ERROR_SMB_TAX_INVOICE_NOT_PASS("9982", "SMB增值税发票未审核通过"),
    ERROR_SYNCHRONOUS_ORDERCENTER_INVOICE("9983", "同步全量库插入invoice失败"),
    ERROR_SYNCHRONOUS_ORDERCENTER_ITEM("9984", "同步全量库插入item失败"),
    ERROR_SYNCHRONOUS_ORDERCENTER_IDENTITY("9985", "同步全量库插入identity失败"),
    ERROR_SYNCHRONOUS_ORDERCENTER_DELIVERYADDRESS("9986", "同步全量库插入deliveryaddress失败"),
    ERROR_SYNCHRONOUS_ORDERCENTER_MAINDISCOUNT("9987", "同步全量库插入mainDiscount失败"),
    ERROR_SYNCHRONOUS_ORDERCENTER_MAINBELONGING("9988", "同步全量库插入mainBelonging失败"),
    ERROR_SYNCHRONOUS_ORDERCENTER_MAIN("9989", "同步全量库插入main失败"),
    ERROR_CREDIT_FREEZE("9990", "冻结信用失败"),
    ERROR_SHOPID_ILLLEGAL("9991", "shopId不合法"),
    ERROR_PAY_ORDER_TELE_STOCK("9992", "懂得通信减占用、加冻结库存失败"),
    ERROR_PAY_ORDER_STOCK("9993", "普通品减占用、加冻结库存失败"),
    ERROR_GET_CTO_DATE("9994", "获取CTO日期失败"),
    ERROR_UPDATE_CTO_DATE("9995", "CTO日期更新失败"),
    ERROR_SEND_SMS("9996", "发送短信失败"),
    ERROR_UPDATE_SERVICE_CODE("9997", "更新服务码失败"),
    ERROR_GET_SERVICE_CODE("9998", "获取服务码失败"),
    /*中间件*/
    ORDER_NOTHING("1201", "没有查找到订单"),
    ORDER_STATUS_ERROR("1203", "订单状态错误"),
    ORDER_PAID("1204", "此订单已支付，不能取消。"),
    ORDER_AUDIT_SIGN_CONTRACT("1206", "订单已签署合同"),
    ORDER_OFFLINE_BANK("1207", "线下银行转账的订单，不能取消"),

    PIPELINE_CANCEL_ORDER_ERROR("1601", "管道取消订单失败"),
    UPDATE_ES_CANCEL_ORDER_ERROR("1602", "更新ES取消订单失败"),


    ERROR_PAID_ORDER_AMOUNT_INCONSISTENT("8000", "支付回调的金额跟订单金额不一致"),
    ERROR_PARAM("9001", "参数有误"),
    ERROR_EMPTY_ORDER("9002", "未查到订单信息"),
    THROW_ORDER_FINISH("9003", "抛单成功或是正在抛单中"),
    ERROR_UPDATE_INVOICE("9004", "更新发票信息失败"),
    ERROR_UPDATE_M_PIPELINE("9995", "更新M-pipeline失败"),
    ERROR_UPDATE_MDB("9996", "更新MDB失败"),
    ERROR_EMPTY_ORDER_ITEMS("9997", "未查到订单商品信息"),
    ERROR_HUISHANG_AUDIT("9998", "惠商审单失败"),


    /*抛单*/

    UPDATE_DB_0_NUMBER("1006", "更新数据库条数为0"),
    FAILURE_HTTP_EPACK("1007","调用smb epack 失败"),
    ORDER_NO_EXIST("1008","订单信息不存在"),

    THROW_ORDER_WAITING("400", "已抛单，等待返回值"),
    THROW_ORDER_SUCCESS("300", "抛单成功"),
    THROW_ORDER_FAILURE("200", "抛单失败"),
    PARAM_EMPTY("1001", "参数为空"),
    ERROR_GET_COMMON_ORDER_LIST("1002", "获取待抛单列表异常（非SMB非惠商非roming订单）"),
    ERROR_GENERATE_THROW_ORDER("1003", "组装抛单数据集合异常"),
    ERROR_THROW_DIRECT_XML("1004", "抛送直营报文为空"),
    ERROR_SIGN_THROW_ORDER("1005", "签名失败导致抛单失败"),
    ERROR_GET_THROW_ORDER("1006", "获取抛单订单异常"),
    EMPTY_GET_THROW_ORDER("1007", "获取抛单订单为空"),
    ERROR_UPDATE_THROW_INFO("1008", "更新抛单返回信息失败"),
    ERROR_UPDATE_FREEZE_STOCK_STATUS("1009", "更新库存减冻结状态失败"),
    ERROR_UPDATE_ORDERCENTER_THROW_INFO("1010", "更新全量库抛单信息失败"),
    ERROR_UPDATE_ORDERCENTER_THROW_STATUS("1011", "更新修改全量库抛单状态结果失败"),
    ERROR_UPDATE_THROW_UPDATETIME("1012", "更新抛单库更新时间失败"),
    EMPTY_GET_THROW_INVOICE("1013", "获取发票信息为空"),
    ERROR_THROW_FA_XML("1014", "抛送非直营FA报文为空"),
    ERROR_THROW_DONGDE_BOSS_JSON("1015", "抛送懂的通信报文为空"),
    ERROR_GET_SMB_ORDER_LIST("1016", "获取SMB待抛单列表异常"),
    ERROR_GET_SMB_ORDER("1017", "获取SMB抛单信息异常"),
    ERROR_GET_SMB_PAY_INFO_LIST("1018", "获取SMB已支付列表异常"),
    ERROR_UPDATE_RULE_RESULT("1019", "更新规则结果失败"),
    ERROR_THROW_XML("1020", "抛送报文为空"),
    ERROR_GET_SMB_PAY_INFO("1021", "获取SMB已支付信息异常"),
    EMPTY_GET_SMB_PAY_INFO("1022", "获取SMB已支付信息为空"),
    ERROR_GEN_THROW("1023", "组装报文异常"),


    ERROR_GET_REMOTE_INVOICE("8000", "获取发票失败"),
    EMPTY_INVOICE_ID("8001", "发票ID为空"),
    INVOICE_NO_AUDIT("8002", "发票未审核"),
    ERROR_UPDATE_INVOICE_AUDIT_INFO("8003", "更新发票审核信息失败"),
    EMPTY_GET_REMOTE_INVOICE("8004", "获取发票信息为空"),
    ERROR_GET_REMOTE_CONTRACT("8005", "获取合同失败"),
    ERROR_GET_REMOTE_INVOICE_NO_INVOICE("8006", "没有这张发票"),

    ERROR_ALLOWED_REPEAT_UPDATE_WAREHOUSE("9970", "抛sec已经成功，不允许再次修改库存地信息"),
    EMPTY_OWN_STOCK_NUM("9971", "自有库存数量不足！"),

    MATCHING_RULES("9958", "匹配规则"),
    NO_MATCHING_RULES("9959", "不匹配规则"),

    ERROR_BUYERNAME_LENGTH_TOO_LONG("9977", "经销商名称长度超长"),
    ERROR_NAME_LENGTH_TOO_LONG("9978", "名称长度超长"),
    ERROR_ADDRESS_LENGTH_TOO_LONG("9979", "地址长度超长"),
    EMPTY_GET_SMB_MEMBER("9980", "获取smb用户信息为空"),
    ERROR_GET_ORDER_ITEM("9981", "获取抛单商品异常"),
    ERROR_ILL_LEGAL_SHOPID("9982", "商户信息有误"),
    EMPTY_OPEN_GET_FA_CODE("9983", "调用公共平台获取分销商编码为空"),
    ERROR_OPEN_GET_FA_CODE("9984", "调用公共平台获取分销商编码失败"),
    ERROR_GET_SEC_ADDRESS_ID("9985", "获取sec地址ID失败"),
    EMPTY_OPEN_GET_BUYER_CODE("9986", "调用公共平台获取经销商编码为空"),
    ERROR_OPEN_GET_BUYER_CODE("9987", "调用公共平台获取经销商编码失败"),
    ERROR_GET_REAL_MATERIAL("9988", "惠商CTO调用真实物料号失败"),
    ERROR_UPDATE_THROW_STATUS("9989", "更新抛单状态失败"),
    ERROR_REDUCE_FREEZE_STOCK("9990", "库存减冻结失败"),
    ERROR_THROW_ORDER_PENDING("9991", "正在抛单中..."),
    ERROR_SAVE_ORDER_ITEMS("9992", "保存抛单商品失败"),
    ERROR_DELETE_ORDER_ITEM("9993", "删除抛单商品失败"),
    ERROR_THROW_STATUS_SUCCESS("9994", "抛单已成功或正在抛单中,不能修改商品库存地信息"),
    ERROR_UPDATE_ORDER_ITEM_NUM("9995", "更新抛单商品库存地信息，商品数量不一致"),
    EMPTY_GET_ORDER_ITEM("9997", "获取抛单商品为空"),
    ERROR_GET_ORDER_ITEMS("9998", "获取抛单商品列表异常"),;


    private String code;
    private String desc;

    ResultMessageEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    /**
     * 判断成功
     *
     * @param code
     * @return
     */
    public static boolean isSuccess(String code) {
        if (StringUtils.isEmpty(code)) {
            return false;
        }
        return SUCCESS.getCode().equals(code);
    }
}
