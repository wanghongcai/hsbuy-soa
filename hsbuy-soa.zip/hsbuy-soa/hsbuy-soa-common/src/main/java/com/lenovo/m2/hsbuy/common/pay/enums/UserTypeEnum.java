package com.lenovo.m2.hsbuy.common.pay.enums;

/**
 * Created by jh on 2017/10/26.
 * user_info   user_type
 */
public enum UserTypeEnum {
    PERSONAL(1, "个人"),
    ENTERPRISE(2, "企业"),
    STORE(3, "门店");


    private final int type;
    private final String desc;

    UserTypeEnum(int type, String desc) {
        this.type = type;
        this.desc = desc;
    }

    public int getType() {
        return type;
    }

    public String getDesc() {
        return desc;
    }


    /**
     * 是否个人用户
     *
     * @param type
     * @return
     */
    public static boolean isPersonal(Integer type) {
        if(null == type){
            return false;
        }
        return PERSONAL.type == type;
    }

    /**
     * 是否企业用户
     *
     * @param type
     * @return
     */
    public static boolean isEnterprise(Integer type) {
        if(null == type){
            return false;
        }
        return ENTERPRISE.type == type;
    }

    public static boolean isStore(Integer type) {
        if(null == type){
            return false;
        }
        return STORE.type == type;
    }


}
