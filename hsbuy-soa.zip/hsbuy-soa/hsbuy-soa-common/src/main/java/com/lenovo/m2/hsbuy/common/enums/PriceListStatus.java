package com.lenovo.m2.hsbuy.common.enums;

/**
 * @author  pxg1
 * 报价单状态
 */
public enum PriceListStatus {

	NOT_ORDER(0, "未下单"),
	ORDERED(1, "已下单"),
	WAIT_TO_CHECK(2, "等待后台确认"),
	EXPIRE_DATE(3,"已过期");


	private final int type;
	private final String descr;

	public int getType() {
		return type;
	}

	public String getDescr() {
		return descr;
	}

	private PriceListStatus(int type, String descr){
		this.type = type;
		this.descr = descr;
	}

	public static PriceListStatus getSaleType(int type){
		PriceListStatus result = null;
		switch(type){
			case 0:
				result = NOT_ORDER;
				break;
			case 1:
				result = ORDERED;
				break;
			case 2:
				result = WAIT_TO_CHECK;
				break;
			default:
				throw new IllegalArgumentException("unkown parameter type=" + type + "");
		}
		return result;
	}






}

