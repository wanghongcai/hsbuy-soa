package com.lenovo.m2.hsbuy.common.enums;

/**
 * Created by pxg01 on 2017/7/24.
 * 支付类型
 */
public enum PayMentType {

    CASH_PAY(0,"Cash"),
    CARD_PAY(1,"Card");
    PayMentType(Integer code, String dec){
        this.code = code;
        this.dec = dec;
    }
    private Integer code;
    private String dec;

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getDec() {
        return dec;
    }

    public void setDec(String dec) {
        this.dec = dec;
    }
}
