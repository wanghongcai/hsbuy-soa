package com.lenovo.m2.hsbuy.common.middleware;

import com.lenovo.m2.arch.framework.domain.RemoteResult;

/**
 * @description 业务异常
 */

public class BusinessException extends RuntimeException {

    private static final long serialVersionUID = 1255854435024536217L;

    private String errno;

    public BusinessException(String errno, String errmsg) {
        super(errmsg);
        this.errno = errno;
    }


    public BusinessException(ResultMessageEnum error) {
        super(error.getDesc());
        this.errno = error.getCode();
    }

    public BusinessException(ResultMessageEnum error, String errmsg) {
        super(errmsg);
        this.errno = error.getCode();
    }

    public BusinessException(RemoteResult result) {
        super(result.getResultMsg());
        this.errno = result.getResultCode();
    }

    public String getErrno() {
        return errno;
    }
}
