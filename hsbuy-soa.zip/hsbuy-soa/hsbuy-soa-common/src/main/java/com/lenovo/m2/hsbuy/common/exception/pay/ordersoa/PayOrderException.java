package com.lenovo.m2.hsbuy.common.exception.pay.ordersoa;

/**
 * Created by kenvin on 2014/10/28.
 */
public class PayOrderException extends Exception{
    private String message;

    public PayOrderException(String message) {

        super(message);    //To change body of overridden methods use File | Settings | File Templates.
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
