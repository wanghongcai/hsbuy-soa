package com.lenovo.m2.hsbuy.common.util;


import com.alibaba.dubbo.rpc.RpcContext;
import com.lenovo.m2.arch.framework.domain.Tenant;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * Created by zhangzhen on 17/3/20.
 */
public class DateJsonSerializer extends JsonSerializer<Date> {

    private static final Logger LOG = LoggerFactory.getLogger(DateJsonSerializer.class);

    @Override
    public void serialize(Date value, JsonGenerator gen, SerializerProvider serializers) throws IOException, JsonProcessingException {


        LOG.info("DateJsonSerializer");

        if(value == null){
            return;
        }

        Object obj = RpcContext.getContext().get("tenant");

        if(obj != null && obj instanceof Tenant){

            Tenant data = (Tenant)obj;

            LOG.info("tenant timezone: {}", data.getTimeZone());

            String tz = data.getTimeZone();

            SimpleDateFormat sdf = new SimpleDateFormat(data.getTimeFormat());

            sdf.setTimeZone(TimeZone.getTimeZone(tz));

            gen.writeString(sdf.format(value));

            return;
        }

        gen.writeString(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(value));

    }

}
