package com.lenovo.m2.hsbuy.common.pruchase.util;//package com.lenovo.m2.buy.purchase.common.util;
//
//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
//
//import javax.servlet.http.HttpServletRequest;
//
///**
// * Created by Administrator on 2015/11/18.
// */
//public class IpUtil {
//    private final static Log LOG = LogFactory.getLog(IpUtil.class);
//
//    /**
//     * 获取用户ip
//     * @param request
//     * @return
//     * @author dulijie
//     */
//    public static String getIp( HttpServletRequest request) {
//        String ip = "";
//        try{
//            ip = request.getHeader("X-Real-IP");
//            LOG.info("商城限购X-Real-IPIP="+request.getHeader("X-Real-IP"));
//            LOG.info("商城限购x-forwarded-forIPIP="+request.getHeader("x-forwarded-for"));
//            LOG.info("商城限购Proxy-Client-IPIPIP="+request.getHeader("Proxy-Client-IP"));
//            LOG.info("商城限购WL-Proxy-Client-IPIPIP="+ request.getHeader("WL-Proxy-Client-IP"));
//            LOG.info("getRemoteAddrIPIP="+ request.getRemoteAddr());
//
//            if (ip == null || ip.length() == 0 || ip.equalsIgnoreCase("unknown")) {
//                ip = request.getHeader("x-forwarded-for");
//            }
//            if (ip == null || ip.length() == 0 || ip.equalsIgnoreCase("unknown")) {
//                ip = request.getHeader("Proxy-Client-IP");
//            }
//            if (ip == null || ip.length() == 0 || ip.equalsIgnoreCase("unknown")) {
//                ip = request.getHeader("WL-Proxy-Client-IP");
//            }
//            if (ip == null || ip.length() == 0 || ip.equalsIgnoreCase("unknown")) {
//                ip = request.getRemoteAddr();
//            }
//        }catch(Exception e){
//            e.getMessage().toString();
//            // LOG.info("获取ip异常："+e.getMessage().toString());
//        }
//        return ip.equals("0:0:0:0:0:0:0:1")?"127.0.0.1":ip;
//    }
//}
//
