package com.lenovo.m2.hsbuy.common.pruchase.enums;

public enum ComefromEnum {

	DEFAULT("0", "非推广"),
	CPS("1", "cps推广"),
	C2C("2","c2c推广"),
	HONEYBEEN("3","小蜜蜂");


	private final String type;
	private final String descr;

	public String getType() {
		return type;
	}

	public String getDescr() {
		return descr;
	}

	ComefromEnum(String type, String descr) {
		this.type = type;
		this.descr = descr;
	}
}
