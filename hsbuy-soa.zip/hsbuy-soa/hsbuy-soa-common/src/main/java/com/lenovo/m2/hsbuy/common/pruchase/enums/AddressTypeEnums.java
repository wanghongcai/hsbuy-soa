/**
 * Project Name:order-address-common
 * File Name:AddressTypeEnums.java
 * Package Name:com.lenovo.m2.buy.order.address.common.emuns
 * Date:2016年6月27日下午3:30:09
 * Copyright (c) 2016, chenzhou1025@126.com All Rights Reserved.
 *
*/

package com.lenovo.m2.hsbuy.common.pruchase.enums;
/**
 * ClassName:AddressTypeEnums <br/>
 * Function: 收货地址类型枚举. <br/>
 * Date:     2016年6月27日 下午3:30:09 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.6
 * @see 	 
 */
public enum AddressTypeEnums {
	DONGDE("dongde","懂得收货地址"),
	SH("SH","收货地址"),
	SP("SP","收票地址"),
	HT("HT","合同地址"),
	ZD("ZD","账单地址")
	;
	AddressTypeEnums(String code,String common){
		this.setCode(code);
		this.setCommon(common);
	}
	private String code;//code名称
	private String common;// 序列说明
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getCommon() {
		return common;
	}
	public void setCommon(String common) {
		this.common = common;
	}
	
	
}

