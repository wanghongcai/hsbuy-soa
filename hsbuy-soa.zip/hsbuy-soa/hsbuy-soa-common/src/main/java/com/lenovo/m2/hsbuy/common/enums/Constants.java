package com.lenovo.m2.hsbuy.common.enums;
/**
 * 
* @ClassName: Constants 
* @Description: 常量类
* @author yuzj7@lenovo.com 
* @date 2016年2月15日 下午3:33:19 
*
 */

public class Constants {

	/**
	 * appid appkey 需要重新设置
	 *
	 */
	//文件上传appid
	public final static String FILE_UPLOAD_APPID = "invoice";
	//文件上传appkey
	public final static String FILE_UPLOAD_APPKEY = "d1qtS9ReeFbwNyIL";
	//图片路径
	public final static String PIC_PATH = "http://invoice.app.lefile.cn/";

}
