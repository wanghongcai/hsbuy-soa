package com.lenovo.m2.hsbuy.common.pay.util.ordersoa;

import org.dom4j.*;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class XmlUtil {

	public static String format(Document doc) {
		StringWriter stringWriter = new StringWriter();
		OutputFormat format = OutputFormat.createPrettyPrint(); // 设置XML文档输出格式
		format.setEncoding("UTF-8"); // 设置XML文档的编码类型
		format.setSuppressDeclaration(true);
		format.setIndent(true); // 设置是否缩进
		format.setIndent("  "); // 以空格方式实现缩进
		format.setNewlines(true); // 设置是否换行
		XMLWriter writer = new XMLWriter(stringWriter, format);
		try {
			writer.write(doc);
			writer.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return stringWriter.toString();
	}

	public static Document getDocument(String xml) {
		Document doc;
		try {
			doc = new SAXReader().read(new ByteArrayInputStream(xml.getBytes("UTF-8")));
			return doc;
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (DocumentException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static Document getDocument(InputStream xml) {
		Document doc;
		try {
			doc = new SAXReader().read(xml);
			return doc;
		} catch (DocumentException e) {
			// e.printStackTrace();
		}
		return null;
	}

	public static Document createDocument() {
		return DocumentHelper.createDocument();
	}

	public static String document2String(Document doc) {
		StringWriter sw = new StringWriter();
		XMLWriter writer = new XMLWriter(sw);
		try {
			writer.write(doc);
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return sw.toString();
	}

	public static Map<String, String> element2Map(Element el) {
		if (el == null) {
			return new HashMap<String, String>();
		}
		Map map = new HashMap();
		List<Attribute> attrs = el.attributes();
		for (Attribute a : attrs) {
			map.put(a.getName(), a.getValue());
		}
		// textarea
		Object data = el.getData();
		if (data != null) {
			map.put("textarea", data.toString().trim());
		}
		return map;
	}

	public static List<Map<String, String>> element2ListMap(Element curentEL) {
		List<Map<String, String>> hcls = new ArrayList();
		if (curentEL == null) {
			return hcls;
		}
		List<Element> list = curentEL.elements();
		for (Element el : list) {
			Map map = new HashMap();
			hcls.add(element2Map(el));
		}
		return hcls;
	}

	public static Map<String, Object> Dom2Map(final Document doc) {
		class Dom2Map {
			public Map cache = new HashMap();

			Element el = doc.getRootElement();

			public Dom2Map() {
				parser(el, cache);
			}

			private void parser(Element e, Map parent) {
				List<Element> es = e.elements();
				Map cur = new HashMap();
				Map map = new HashMap();
				List<Attribute> attrs = e.attributes();
				for (Attribute attr : attrs) {
					map.put(attr.getName(), attr.getValue());
				}
				String text = e.getTextTrim();
				if (text != null && text.length() > 0) {
					map.put("text", text);
				}
				cur.put("attr", map);
				parent.put(e.attributeValue("name"), cur);
				Object childs = parent.get("child");
				if (childs == null) {
					List list = new ArrayList();
					list.add(cur);
					parent.put("child", list);
				} else {
					List list = (List) childs;
					list.add(cur);
				}
				for (Element et : es) {
					parser(et, cur);
				}
			}
		}
		Dom2Map dm = new Dom2Map();
		return dm.cache;
	}

	public static String getPath(Element el) {
		List<String> ps = new ArrayList<String>();
		ps.add(el.getName() + "[@name='" + el.attributeValue("name") + "']");
		Element parent = el;
		while ((parent = parent.getParent()) != null) {
			if (parent.attributeValue("name") != null) {
				ps.add(parent.getName() + "[@name='" + parent.attributeValue("name") + "']");
			} else {
				ps.add(parent.getName());
			}
		}
		StringBuffer sb = new StringBuffer();
		for (int i = ps.size() - 1; i >= 0; i--) {
			sb.append("/");
			sb.append(ps.get(i));
		}
		return sb.toString();
	}
}
