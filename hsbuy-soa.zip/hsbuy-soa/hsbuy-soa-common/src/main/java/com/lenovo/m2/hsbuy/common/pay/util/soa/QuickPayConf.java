package com.lenovo.m2.hsbuy.common.pay.util.soa;

/**
 * Created by Administrator on 2015/7/14.
 */
public class QuickPayConf {

    // 版本号
    public static String version = "1.0.0";

    // 编码方式
    public static String charset = "UTF-8";

    // 基础网址（请按相应环境切换）

    /* 前台交易测试环境 */
//    private static String UPOP_BASE_URL = "http://202.101.25.184/UpopWeb/api/";

	/* 前台交易PM环境（准生产环境） */
    //private final static String UPOP_BASE_URL = "https://www.epay.lxdns.com/UpopWeb/api/";

	/* 前台交易生产环境 */
    private static String UPOP_BASE_URL = "https://unionpaysecure.com/api/";

    /* 后台交易测试环境 */
    private static String UPOP_BSPAY_BASE_URL = "http://202.101.25.184/UpopWeb/api/";

	/* 后台交易PM环境（准生产环境） */
//	private final static String UPOP_BSPAY_BASE_URL = "https://www.epay.lxdns.com/UpopWeb/api/";

	/* 后台交易生产环境 */
    //private final static String UPOP_BSPAY_BASE_URL = "https://besvr.unionpaysecure.com/api/";

    /* 查询交易测试环境 */
    private static String UPOP_QUERY_BASE_URL = "http://202.101.25.184/UpopWeb/api/";

	/* 查询交易PM环境（准生产环境） */
//	private final static String UPOP_QUERY_BASE_URL = "https://www.epay.lxdns.com/UpopWeb/api/";

	/* 查询交易生产环境 */
    //private final static String UPOP_QUERY_BASE_URL = "https://query.unionpaysecure.com/api/";

    // 支付网址
    public static String gateWay = UPOP_BASE_URL + "Pay.action";

    // 后续交易网址
    public static String backStagegateWay = UPOP_BSPAY_BASE_URL + "BSPay.action";

    // 查询网址
    public static String queryUrl = UPOP_QUERY_BASE_URL + "Query.action";

    // 认证支付2.0网址
    public static String authPayUrl = UPOP_BASE_URL + "AuthPay.action";

    // 发短信网址
    public static String smsUrl = UPOP_BASE_URL + "Sms.action";

    // 商户代码
//    public static String merCode = "105550149170027";

    //正式环境商户代码
    public static String merCode = "898111157320112";

    // 商户名称
    public static String merName = "联想商城";

    public static String merFrontEndUrl = "http://thinkshopts.lenovo.com.cn/user/order.html";

    public static String merBackEndUrl = "http://www.yourdomain.com/your_path/yourBackEndUrl";

    // 加密方式
    public static String signType = "MD5";
    public static String signType_SHA1withRSA = "SHA1withRSA";

    // 商城密匙，需要和银联商户网站上配置的一样
//    public static String securityKey = "88888888";

    //正式环境商城秘钥
    public static String securityKey = "EWURYD23EUWD0EIDW0PODISK";

    // 签名
    public static String signature = "signature";
    public static String signMethod = "signMethod";

    //组装消费请求包
    public static String[] reqVo = new String[]{
            "version",
            "charset",
            "transType",
            "origQid",
            "merId",
            "merAbbr",
            "acqCode",
            "merCode",
            "commodityUrl",
            "commodityName",
            "commodityUnitPrice",
            "commodityQuantity",
            "commodityDiscount",
            "transferFee",
            "orderNumber",
            "orderAmount",
            "orderCurrency",
            "orderTime",
            "customerIp",
            "customerName",
            "defaultPayType",
            "defaultBankNumber",
            "transTimeout",
            "frontEndUrl",
            "backEndUrl",
            "merReserved"
    };

    public static String[] notifyVo = new String[]{
            "charset",
            "cupReserved",
            "exchangeDate",
            "exchangeRate",
            "merAbbr",
            "merId",
            "orderAmount",
            "orderCurrency",
            "orderNumber",
            "qid",
            "respCode",
            "respMsg",
            "respTime",
            "settleAmount",
            "settleCurrency",
            "settleDate",
            "traceNumber",
            "traceTime",
            "transType",
            "version"
    };

    public static String[] queryVo = new String[]{
            "version",
            "charset",
            "transType",
            "merId",
            "orderNumber",
            "orderTime",
            "merReserved"
    };

    public static String[] smsVo = new String[]{
            "version",
            "charset",
            "acqCode",
            "merId",
            "merAbbr",
            "orderNumber",
            "orderAmount",
            "orderCurrency",
            "merReserved"
    };



}
