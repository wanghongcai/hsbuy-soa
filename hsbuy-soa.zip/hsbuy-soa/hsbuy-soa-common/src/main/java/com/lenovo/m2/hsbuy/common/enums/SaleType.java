package com.lenovo.m2.hsbuy.common.enums;

/**
 * 销售类型
 */
public enum SaleType {
	
	NORMAL_SALES(0, "普通"),
	FLASH_SALES(1, "闪购"),
	PRESELLS(2, "预售"),
	TRY_BEFORE_BUY_SALES(3, "先试后买"),
	K_CODE_SALES(4, "K码商品"),
	CUSTOMIZING_SALES(5, "定制"),
	O2O_SALES(98,"o2o"),
	ZC_SALES(97,"众筹"),
	CTO_SALES(96,"cto");

	private final int type;
	private final String descr;
	
	public int getType() {
		return type;
	}

	public String getDescr() {
		return descr;
	}

	private SaleType(int type, String descr){
		this.type = type;
		this.descr = descr;
	}

	public static SaleType getSaleType(int type){
		SaleType result = null;
		switch(type){
			case 0:
				result = NORMAL_SALES;
				break;
			case 1:
				result = FLASH_SALES;
				break;
			case 2:
				result = PRESELLS;
				break;
			case 3:
				result = TRY_BEFORE_BUY_SALES;
				break;
			case 4:
				result = K_CODE_SALES;
				break;
			case 5:
				result = CUSTOMIZING_SALES;
				break;
			case 98:
				result = O2O_SALES;
				break;
			case 97:
				result = ZC_SALES;
				break;
			case 96:
				result = CTO_SALES;
				break;
			default:
				throw new IllegalArgumentException("unkown parameter type=" + type + "");
		}
		return result;
	}
	
}
