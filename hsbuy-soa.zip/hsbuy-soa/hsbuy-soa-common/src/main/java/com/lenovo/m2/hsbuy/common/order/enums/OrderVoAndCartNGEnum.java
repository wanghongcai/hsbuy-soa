package com.lenovo.m2.hsbuy.common.order.enums;

/**
 * Created by zhaocl1 on 2017/5/23.
 */
public enum OrderVoAndCartNGEnum {

    ORDERVO("orderVo"),
    CARTNG("cartNG");

    private String value;

    OrderVoAndCartNGEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
