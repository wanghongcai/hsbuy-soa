package com.lenovo.m2.hsbuy.common.address.utils;

import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * 懂得通信身份验证使用
 * md5文件校验【校验上传的两张图片是否一样】
 */
public class MD5CheckUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(MD5CheckUtil.class);
	/**
	* 默认的密码字符串组合，用来将字节转换成 16 进制表示的字符,apache校验下载的文件的正确性用的就是默认的这个组合
	*/
	protected char hexDigits[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
	protected  MessageDigest messagedigest = null;
	{
		try {
			messagedigest = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			LOGGER.error(e.getMessage(),e);
		}
	}

	public String getFileMD5String(File file) throws IOException {
		InputStream fis;
		fis = new FileInputStream(file);
		byte[] buffer = new byte[1024];
		int numRead = 0;
		while ((numRead = fis.read(buffer)) > 0) {
			messagedigest.update(buffer, 0, numRead);
		}
		fis.close();
		return bufferToHex(messagedigest.digest());
	}

	public String getFileMD5String(InputStream in) throws IOException {
		byte[] buffer = new byte[1024];
		int numRead = 0;
		while ((numRead = in.read(buffer)) > 0) {
			messagedigest.update(buffer, 0, numRead);
		}
		in.close();
		return bufferToHex(messagedigest.digest());
	}

	private String bufferToHex(byte bytes[]) {
		return bufferToHex(bytes, 0, bytes.length);
	}

	private String bufferToHex(byte bytes[], int m, int n) {
		StringBuffer stringbuffer = new StringBuffer(2 * n);
		int k = m + n;
		for (int l = m; l < k; l++) {
			appendHexPair(bytes[l], stringbuffer);
		}
		return stringbuffer.toString();
	}

	private void appendHexPair(byte bt, StringBuffer stringbuffer) {
		char c0 = hexDigits[(bt & 0xf0) >> 4];// 取字节中高 4 位的数字转换
		// 为逻辑右移，将符号位一起右移,此处未发现两种符号有何不同
		char c1 = hexDigits[bt & 0xf];// 取字节中低 4 位的数字转换
		stringbuffer.append(c0);
		stringbuffer.append(c1);
	}

	// 加密图片的url地址  用来当做redis中的存储key值
	public String getUrl(String url){
		/*byte [] bt = url.getBytes();
		byte []  rt = messagedigest.digest(bt);
		return  rt.toString();*/
		try {
			return DigestUtils.md5Hex(url.getBytes("utf-8"));
		} catch (UnsupportedEncodingException e) {
			LOGGER.error(e.getMessage(),e);
			return "";
		}
	}

	public static void main(String[] args) throws UnsupportedEncodingException {
		System.out.println(DigestUtils.md5Hex("aa".getBytes("utf-8")));
	}
}
