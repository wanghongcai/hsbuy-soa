package com.lenovo.m2.hsbuy.common.pruchase.enums;

/**
 * @author  zhanghs
 * fa类型
 */
public enum FaType {

	ZY(0, "直营"),
	AGENT(1, "代理"),
	MBG(2, "MBG"),
	THINK_ZY(3, "Think直营"),
	THINK_AGENT(4, "ThinkFA"),
	DONGDE_ZY(5,"懂得直营"),
	SMB_ZY_ALL(7,"smb 直营总代"),
	SMB_ZY(8,"smb 直营"),
	SMART_LENOVO_TV(9,"lenovoTV"),
	SMART_17_TV(10,"17TV");

	private final int type;
	private final String descr;

	public int getType() {
		return type;
	}

	public String getDescr() {
		return descr;
	}

	private FaType(int type, String descr){
		this.type = type;
		this.descr = descr;
	}

	public static FaType getSaleType(int type){
		FaType result = null;
		switch(type){
			case 0:
				result = ZY;
				break;
			case 1:
				result = AGENT;
				break;
			case 2:
				result = MBG;
				break;
			case 3:
				result = THINK_ZY;
				break;
			case 4:
				result = THINK_AGENT;
				break;
			case 5:
			    	result = DONGDE_ZY;
			    	break;
			case 7:
		    	result = SMB_ZY_ALL;
		    	break;
			case 8:
		    	result = SMB_ZY;
		    	break;
			case 9:
				result = SMART_LENOVO_TV;
				break;
			case 10:
				result = SMART_17_TV;
				break;

			default:
				throw new IllegalArgumentException("unkown parameter type=" + type + "");
		}
		return result;
	}
	
	



	
}
