package com.lenovo.m2.hsbuy.common.convert;

import com.lenovo.m2.arch.framework.domain.Money;
import org.apache.commons.lang.StringUtils;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;

/**
 * Created by zhangzhen on 17/1/3.
 */
@ReadingConverter
public class StringToMoneyConverter implements Converter<String, Money> {
    @Override
    public Money convert(String source) {
        if (StringUtils.isEmpty(source)){
            return new Money("0.00", Money.DEFAULT_CURRENCY_CODE);
        }else {
            return new Money(source, Money.DEFAULT_CURRENCY_CODE);
        }
    }
}
