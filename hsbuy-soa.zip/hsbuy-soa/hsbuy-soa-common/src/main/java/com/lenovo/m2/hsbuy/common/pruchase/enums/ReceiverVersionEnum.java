/**
 * Project Name:purchase-soa-common
 * File Name:ReceiverVersionEnum.java
 * Package Name:com.lenovo.m2.buy.purchase.common.enums
 * Date:2016年12月26日下午4:39:41
 * Copyright (c) 2016, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.hsbuy.common.pruchase.enums;
/**
 * ClassName:ReceiverVersionEnum <br/>
 * Function: TODO ADD FUNCTION. <br/>
 * Date:     2016年12月26日 下午4:39:41 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */
public enum ReceiverVersionEnum {
	
	IL18NMONDY("I18N-MONEY","国际化money版本");
	

	private ReceiverVersionEnum(String code, String common) {
		this.code = code;
		this.common = common;
	}

	private String code;
	
	private String common;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCommon() {
		return common;
	}

	public void setCommon(String common) {
		this.common = common;
	}
	
	
	
	
}

