package com.lenovo.m2.hsbuy.common.address.utils;

/**
 * Created by admin on 2017/8/1.
 */
//@Component
public class PropertiesUtil {

    //sec创建收货地址url
    private String secWebServiceUrl;
    //优惠券绑定经销商路径
    private String productUrl;

    public String getProductUrl() {
        return productUrl;
    }

    public void setProductUrl(String productUrl) {
        this.productUrl = productUrl;
    }

    public String getSecWebServiceUrl() {
        return secWebServiceUrl;
    }

    public void setSecWebServiceUrl(String secWebServiceUrl) {
        this.secWebServiceUrl = secWebServiceUrl;
    }
}
