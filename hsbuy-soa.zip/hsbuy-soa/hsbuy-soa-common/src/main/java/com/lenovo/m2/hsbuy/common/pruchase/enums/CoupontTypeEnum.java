package com.lenovo.m2.hsbuy.common.pruchase.enums;
/**
 * 
* @ClassName: CoupontTypeEnum 
* @Description: 优惠券类别
* @author yuzj7@lenovo.com 
* @date 2016年3月11日 下午8:09:20 
*
 */
public enum CoupontTypeEnum {
	//专属c2c ,大礼包，代金券 可以叠加使用

	COMMON(1, "普通优惠券"), C2C(4, "专属c2c优惠券"),GIFBAG(6,"大礼包"), VENDORS(7, "代金券");
	

	private final int type;
	private final String descr;

	private CoupontTypeEnum(int type, String descr) {
		this.type = type;
		this.descr = descr;
	}

	public int getType() {
		return type;
	}

	public String getDescr() {
		return descr;
	}
}
