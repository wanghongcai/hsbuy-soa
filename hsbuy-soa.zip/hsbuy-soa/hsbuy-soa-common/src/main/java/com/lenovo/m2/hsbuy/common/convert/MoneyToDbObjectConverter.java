package com.lenovo.m2.hsbuy.common.convert;

import com.lenovo.m2.arch.framework.domain.Money;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.WritingConverter;

/**
 * Created by zhangzhen on 17/1/3.
 */
@WritingConverter
public class MoneyToDbObjectConverter implements Converter<Money, DBObject> {
    @Override
    public DBObject convert(Money source) {
        if (source == null) {
            return null;
        }

        DBObject result = new BasicDBObject();
        result.put("amount", source.toString());
        result.put("currencyCode", source.getCurrencyCode());
        return result;
    }
}
