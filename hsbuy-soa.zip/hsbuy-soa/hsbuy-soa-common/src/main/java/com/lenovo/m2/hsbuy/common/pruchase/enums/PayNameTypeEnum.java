/**
 * Project Name:purchase-soa-common
 * File Name:PayNameTypeEnum.java
 * Package Name:com.lenovo.m2.buy.purchase.common.enums
 * Date:2017年7月5日下午2:34:04
 * Copyright (c) 2017, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.hsbuy.common.pruchase.enums;
/**
 * ClassName:PayNameTypeEnum <br/>
 * Function: 付款方名称类型. <br/>
 * Date:     2017年7月5日 下午2:34:04 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */
public enum PayNameTypeEnum {
	PERSON("0","个人"),
	COMPANY("1","公司");
	
	private final String type;
	private final String descr;

	private PayNameTypeEnum(String type, String descr) {
		this.type = type;
		this.descr = descr;
	}

	public String getType() {
		return type;
	}

	public String getDescr() {
		return descr;
	}
	
	public static boolean containsKey(String type){
		PayNameTypeEnum[] ts = PayNameTypeEnum.values();
		for(PayNameTypeEnum t :ts){
			if(t.getType().equals(type)){
				return true;
			}
		}
		return false;
	}
	
	public static void main(String[] args) {
		System.out.println(containsKey("3"));
	}
}

