package com.lenovo.m2.hsbuy.common.pay.common.soa;

/**
 * Created by mengqiang1 on 2016/4/8.
 */
public class PaySoaConstant {
    //退货状态
    public static final Integer REFUND_STATE_INIT = 0;//初始
    public static final Integer REFUND_STATE_SUCC = 1;//退货成功
    public static final Integer REFUND_STATE_SENDBACK = 2;//发送后台
    public static final Integer REFUND_STATE_FAIL = 3;//退货失败

    public static final String INPUT_CHARSET_UTF_8 = "utf-8";
}
