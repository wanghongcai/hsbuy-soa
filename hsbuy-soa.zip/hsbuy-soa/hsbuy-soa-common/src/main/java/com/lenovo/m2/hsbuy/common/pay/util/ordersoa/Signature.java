package com.lenovo.m2.hsbuy.common.pay.util.ordersoa;

import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

/**
 * 
 */
public class Signature {
	/**
	 * 签名算法
	 *
	 * @param o
	 *            要参与签名的数据对象
	 * @return 签名
	 * @throws IllegalAccessException
	 */
	public static String getSign(Object o,String key) throws IllegalAccessException {
		ArrayList<String> list = new ArrayList<String>();
		Class cls = o.getClass();
		Field[] fields = cls.getDeclaredFields();
		for (Field f : fields) {
			f.setAccessible(true);
			if (f.get(o) != null && f.get(o) != "") {
				list.add(f.getName() + "=" + f.get(o) + "&");
			}
		}

		int size = list.size();
		String[] arrayToSort = list.toArray(new String[size]);
		Arrays.sort(arrayToSort, String.CASE_INSENSITIVE_ORDER);
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < size; i++) {
			sb.append(arrayToSort[i]);
		}
		String result = sb.toString();
		result += "key=" + key;
		result = MD5.MD5Encode(result).toUpperCase();
		return result;
	}

	public static String getSign(Map<String, Object> map) {
		ArrayList<String> list = new ArrayList<String>();
		for (Map.Entry<String, Object> entry : map.entrySet()) {
			if (entry.getValue() != "") {
				list.add(entry.getKey() + "=" + entry.getValue() + "&");
			}
		}
		int size = list.size();
		String[] arrayToSort = list.toArray(new String[size]);
		Arrays.sort(arrayToSort, String.CASE_INSENSITIVE_ORDER);
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < size; i++) {
			sb.append(arrayToSort[i]);
		}
		String result = sb.toString();
		result += "key=" + map.get("key");
		// Util.log("Sign Before MD5:" + result);
        System.out.println("签名1---->"+result);
        result = MD5.MD5Encode(result).toUpperCase();
		// Util.log("Sign Result:" + result);
        System.out.println("签名2---->"+result);
        return result;
	}
    public static String getSign(Map<String, Object> map,String signKey) {
        ArrayList<String> list = new ArrayList<String>();
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (entry.getValue() != "") {
                list.add(entry.getKey() + "=" + entry.getValue() + "&");
            }
        }
        int size = list.size();
        String[] arrayToSort = list.toArray(new String[size]);
        Arrays.sort(arrayToSort, String.CASE_INSENSITIVE_ORDER);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; i++) {
            sb.append(arrayToSort[i]);
        }
        String result = sb.toString();
        result += "key=" + signKey;

        result = MD5.MD5Encode(result).toUpperCase();

        return result;
    }
	/**
	 * 从API返回的XML数据里面重新计算一次签名
	 *
	 * @param responseString
	 *            API返回的XML数据
	 * @return 新鲜出炉的签名
	 * @throws ParserConfigurationException
	 * @throws IOException
	 * @throws SAXException
	 */
	public static String getSignFromResponseString(String responseString) throws IOException, SAXException, ParserConfigurationException {
		Map<String, Object> map = XMLParser.getMapFromXML(responseString);
		// 清掉返回数据对象里面的Sign数据（不能把这个数据也加进去进行签名），然后用签名算法进行签名
		map.put("sign", "");
		// 将API返回的数据根据用签名算法进行计算新的签名，用来跟API返回的签名进行比较
		return Signature.getSign(map);
	}

	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer();
		sb.append("<xml>");
		sb.append("	<appid>wx5139487540446ebf</appid>");
		sb.append(" <attach>支付测试</attach>");
		sb.append("	<body>JSAPI支付测试</body>");
		sb.append("	<mch_id>1228575202</mch_id>");
		sb.append("	<nonce_str>1add1a30ac87aa2db72f57a2375d8fec</nonce_str>");
		sb.append("	<notify_url>http://www.wangjianlog.cn/test.jsp</notify_url>");
		sb.append("	<out_trade_no>1415659995</out_trade_no>");
		sb.append("	<spbill_create_ip>14.23.150.211</spbill_create_ip>");
		sb.append("	<total_fee>1</total_fee>");
		sb.append("	<trade_type>NATIVE</trade_type>");
		// sb.append("	<sign>8971A1F4428F4F673E15EE17D17C0082</sign>");
		sb.append("</xml>");

		try {
			System.out.println(Signature.getSign(XMLParser.getMapFromXML(sb.toString())));
		} catch (ParserConfigurationException e) {
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		}

	}

}
