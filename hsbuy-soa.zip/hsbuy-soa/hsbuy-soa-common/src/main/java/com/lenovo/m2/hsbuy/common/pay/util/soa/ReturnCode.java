package com.lenovo.m2.hsbuy.common.pay.util.soa;

/**
 * Created by caoxd2 on 2015/4/30.
 */
public enum ReturnCode {
    Success("100","支付成功"),
    //数据非法
    IllegalData("101","数据非法"),
    //支付获取失败
    PayParamError("102","支付参数错误"),
    UserChannel("103","用户已取消"),

    PayFail("104","支付失败"),
    CodeFail("105","生成二维码失败"),
    InNotifyFail("106","异步回调商户失败"),
    ClientException("107","客户端服务器异常"),
    OrderQueryFail("108","支付订单查询失败"),

    PreOrderFail("109","预支付订单生成失败"),
    OauthCodeError("110","code失效");
    private String code;
    private String message;

    ReturnCode(String code, String message){
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
