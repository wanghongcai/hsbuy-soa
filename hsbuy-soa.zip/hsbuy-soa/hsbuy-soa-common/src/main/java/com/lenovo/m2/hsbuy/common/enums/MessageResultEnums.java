package com.lenovo.m2.hsbuy.common.enums;

/**
 * Created by admin on 2017/8/21.
 */
public enum MessageResultEnums {

    SUCCESS("0000","success"),
    FAIL("9999","fail"),
    ERROR_PARAM("1000","参数错误！"),
    ERROR_NOT_FIND("1001","查询不到此记录！");

    private String code;//编码
    private String common;//说明

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCommon() {
        return common;
    }

    public void setCommon(String common) {
        this.common = common;
    }

    MessageResultEnums() {
    }

    MessageResultEnums(String code, String common) {
        this.code = code;
        this.common = common;
    }
}
