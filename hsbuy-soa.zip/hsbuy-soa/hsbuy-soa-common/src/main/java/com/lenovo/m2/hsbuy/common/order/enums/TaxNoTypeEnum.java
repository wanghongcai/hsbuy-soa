package com.lenovo.m2.hsbuy.common.order.enums;

/**
 * Created by zhaocl1 on 2017/6/21.
 */
public enum TaxNoTypeEnum {

    FIFTEENDIGIT("15位",1),
    EIGHTEENDIGIT("18位",2),
    NO("无",3);

    private String name;
    private int value;

    TaxNoTypeEnum(String name, int value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public int getValue() {
        return value;
    }
}
