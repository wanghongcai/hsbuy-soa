package com.lenovo.m2.hsbuy.common.enums;


import java.util.Map;
import java.util.TreeMap;

/**
 * 
* @ClassName: FileUploadReturnEnum 
* @Description: 文件上传返回值枚举
* @author yuzj7@lenovo.com 
* @date 2016年2月22日 下午1:49:51 
*
 */
public enum FileUploadReturnEnum {
	SUCCESS("001","成功"),
	ERROR_FILE_TOO_BIG("002","文件超过大小"),
	ERROR_FILE_FORMAT("003","文件格式不正确"),
	ERROR_FILE_SERVER("004","服务器端异常"),
	ERROR_FILE_PARAM("011","参数无效"),
	ERROR_FILE_COUDNOTREAD("012","文件不可读"),
	ERROR_FILE_SERVER_RESPONSE_NULL("013","服务端响应为空"),
	ERROR_FILE_CLIENT_EXCEPTION("014","ClientProtocolException"),
	ERROR_FILE_OTHER_EXCEPTION("015","IOException");
	
	private String code;// 代号
	private String common;// 说明
	
	
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getCommon() {
		return common;
	}
	public void setCommon(String common) {
		this.common = common;
	}
	FileUploadReturnEnum(String code, String common) {
		this.code = code;
		this.common = common;
	}

	static  Map<String, String> map = new TreeMap<String, String>();
	/**
	 * 获取枚举类型的所有<值,名称>对
	 * 
	 * @return
	 */
	public static Map<String, String> toMap() {
		if(map.size() > 0){
			return map;
		}
		for (int i = 0; i < FileUploadReturnEnum.values().length; i++) {
			map.put(FileUploadReturnEnum.values()[i].getCode(), ErrorMessageEnum.values()[i].getCommon());
		}
		return map;
	}
	
}
