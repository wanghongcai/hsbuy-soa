package com.lenovo.m2.hsbuy.common.address.enums;

import com.lenovo.m2.arch.framework.domain.Tenant;

import java.util.HashMap;
import java.util.Map;

/**
 * 商城列表
 * @author wangrq1
 *
 */
public enum ShopIdEnum {

	LENOVO(1, "lenovo"),
	THINK(2,"think"),
	EPP(3,"epp"),
	ROMING(4,"roming"),
	MOTO(5,"moto"),
	DONGDE(6,"dongde"),
	THINKCENTER(7,"thinkcenter"),
	SMB(8,"smb 商城"),
	SMB_SCORE(9,"17积分商城"),
	HUI_SANG(14,"慧商商城"),
	HUI_SANG_SCORE(15,"慧商积分商城"),
	INDIA_MOTO(16,"印度moto商城");
	
			
	private final int type;
	private final String descr;

	private ShopIdEnum(int type, String descr){
		this.type = type;
		this.descr = descr;
	}

	public int getType() {
		return type;
	}

	public String getDescr() {
		return descr;
	}
	
	private static Map<Integer, ShopIdEnum>lookupmap =new HashMap<>();
	
	static{
		for(ShopIdEnum type: ShopIdEnum.values()){
			lookupmap.put(type.type, type);
		}
		
	}


	public static ShopIdEnum getValueByType(int type){
		return lookupmap.get(type);
	}
	/**
	* @Title: 判断是否是Think商城
	* @Description:
	* @author 2015年9月16日 上午11:06:03 BY zhanghs
	* @return boolean
	* @throws
	 */
	public static boolean isThink(Integer shopid){
		if(null == shopid){
			return false;
		}
		return THINK.getType() == shopid;
	}

	/**
	* @Title: isEpp
	* @Description: 判断是否是Epp商城
	* @author 2015年9月16日 上午11:12:53 BY zhanghs
	* @return
	* @return boolean
	* @throws
	 */
	public static boolean isEpp(Integer shopid){
		return EPP.getType() == shopid;
	}

	/**
	* @Title: isB2C
	* @Description: 判断是否是B2C商城
	* @author 2015年9月16日 上午11:14:51 BY zhanghs
	* @return
	* @return boolean
	* @throws
	 */
	public static boolean isB2C(Integer shopId){
		if(null == shopId){
			return false;
		}
		return LENOVO.getType() == shopId;
	}
	public static boolean isMoto(Integer shopId){
		if(null == shopId){
			return false;
		}
		return MOTO.getType() == shopId;
	}
	public static boolean isIndia_Moto(Integer shopId){
		if(null == shopId){
			return false;
		}
		return INDIA_MOTO.getType() == shopId;
	}
	public static boolean isSmb(Integer shopId){
		if(null == shopId){
			return false;
		}
		return SMB.getType() == shopId;
	}
	public static boolean isSmb_Score(Integer shopId){
		if(null == shopId){
			return false;
		}
		return SMB_SCORE.getType() == shopId;
	}
	public static boolean isHuiSang(Integer shopId){
		if(null == shopId){
			return false;
		}
		return HUI_SANG.getType() == shopId;
	}
	
	public static boolean isHuiSang(Tenant tenant){
		if(null == tenant){
			return false;
		}
		return HUI_SANG.getType() == tenant.getShopId();
	}
	public static boolean isHuiSang_Score(Tenant tenant){
		if(null == tenant){
			return false;
		}
		return HUI_SANG_SCORE.getType() == tenant.getShopId();
	}

	/**
	* @Title: isRoming
	* @Description: 判断是否为ROMING商城
	* @author 2015年9月16日 上午11:16:34 BY zhanghs
	* @return
	* @return boolean
	* @throws
	 */
	public static boolean isRoming(Integer shopId){
		return false;
//		return ENUM.MallType.Roaming.getCode()==shopId;
	}
	/**
	 *
	 * 获取查询shopid. <br/>
	 *
	 * @author yuzj7@lenovo.com
	 * @param shopId
	 * @return
	 * @since JDK 1.7
	 */
	public static int getQueryShopId(int shopId) {
		switch(shopId) {
			case 1:
			case 2:
			case 3:
			case 5:
			case 6:
				return LENOVO.type;
			case 4:
				return ROMING.type;
			case 7:
				return THINKCENTER.type;
			case 8:
			case 9:
				return SMB.type;
			case 14:
				return HUI_SANG.type;
			case 15:
				return HUI_SANG_SCORE.type;
			case 16:
				return INDIA_MOTO.type;
			default:
				return LENOVO.type;
		}
	}

	public static void main(String[] args) {
		System.out.println(getQueryShopId(1));
	}
	/**
	 * 判断是否是B2C商城(i18n)
	 *
	 * @param tenant the tenant
	 * @return the boolean
	 */
	public static boolean isB2C(Tenant tenant) {
		if(null == tenant) {
			return false;
		}
		return isB2C(tenant.getShopId());
	}

	/**
	 * 判断是否是Think商城(i18n)
	 *
	 * @param tenant the tenant
	 * @return the boolean
	 */
	public static boolean isThink(Tenant tenant) {
		if(null == tenant) {
			return false;
		}
		return isThink(tenant.getShopId());
	}

	/**
	 * 判断是否是Epp商城(i18n)
	 *
	 * @param tenant the tenant
	 * @return the boolean
	 */
	public static boolean isEpp(Tenant tenant) {
		if(null == tenant) {
			return false;
		}
		return isEpp(tenant.getShopId());
	}

	/**
	 * 判断是否是Moto商城(i18n)
	 *
	 * @param tenant the tenant
	 * @return the boolean
	 */
	public static boolean isMoto(Tenant tenant) {
		if(null == tenant) {
			return false;
		}
		return isMoto(tenant.getShopId());
	}

	public static boolean isIndia_Moto(Tenant tenant) {
		if(null == tenant) {
			return false;
		}
		return isIndia_Moto(tenant.getShopId());
	}

	/**
	 * 判断是否是联想企业级商城(i18n)
	 *
	 * @param tenant the tenant
	 * @return the boolean
	 */
	public static boolean isSmb(Tenant tenant) {
		if(null == tenant) {
			return false;
		}
		return isSmb(tenant.getShopId());
	}

	/**
	 * 判断是否是联想积分商城(i18n)
	 *
	 * @param tenant the tenant
	 * @return the boolean
	 */
	public static boolean isSmb_Score(Tenant tenant) {
		if(null == tenant) {
			return false;
		}
		return isSmb_Score(tenant.getShopId());
	}

	/**
	 * 判断是否为ROMING商城
	 *
	 * @param tenant the tenant
	 * @return the boolean
	 */
	public static boolean isRoming(Tenant tenant) {
		return false;
	}

	/**
	 * 判断是否为惠商商城或惠商积分商城
	 * @param tenant
	 * @return
	 */
	public static boolean isHuiShang(Tenant tenant) {
		if(null == tenant.getShopId()){
			return false;
		}
		return HUI_SANG.getType() == tenant.getShopId();
	}


}
