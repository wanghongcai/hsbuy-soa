package com.lenovo.m2.hsbuy.common.util;

import com.lenovo.open.gateway.java.sdk.JavaSDKClient;
import com.lenovo.open.gateway.java.sdk.util.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * Created by yezhenyue on 2017/2/13.
 */
public class HsOpenApiUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(HsOpenApiUtil.class);
    private String appKey;
    private String appSecret;
    private String url;

    /**
     *
     * @param method 方法名
     * @param lenovo_param_json 应用参数
     * @param lenovo_sys_param_json 系统该参数
     * @param lenovo_headerparam_json header参数
     * @return
     */
    public Response callApi(String method,Map<String, Object> lenovo_param_json, Map<String, Object> lenovo_sys_param_json, Map<String, Object> lenovo_headerparam_json){
        try {
            return JavaSDKClient.proxy(url, appKey, appSecret, method, lenovo_param_json, lenovo_sys_param_json);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(),e);
        }
        return null;
    }

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public String getAppSecret() {
        return appSecret;
    }

    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
