package com.lenovo.m2.hsbuy.common.order;

/**
 * Created by fenglg1 on 2016/3/14.
 */
public class OrderConstance {

    /**
     * 40 57 代表服务的产品，84 主机 85 显示器 86选件
     */
    public static final String THINK_INDEPENDENCE_DEATLIKE = "40,57,84,85,86";



    public static final int DeliveryAddress_TYPE_D = 0;//送达方地址
    public static final int DeliveryAddress_TYPE_V = 1;//发票寄送地址
    public static final int DeliveryAddress_TYPE_C = 2;//合同寄送地址

    public static final int PaymentTypeId_online = 0;
    public static final int PaymentTypeId_HDFK = 1;
    public static final int PaymentTypeId_lineBankTransfer = 2;

    public static final int InvoiceTypeId_D = 0;//电票
    public static final int InvoiceTypeId_P = 1;//普票
    public static final int InvoiceTypeId_Z = 2;//增票
    public static final int InvoiceTypeId_N = 999;//不开票

    public static final int AuditStatus_NoNeed = 0;//自动过审 即不需要审核
    public static final int AuditStatus_Passed = 1;//审核通过
    public static final int AuditStatus_Pending = 2;//待审核
    public static final int AuditStatus_NoPass = 3;//拒审

    public static final int salesType_cto = 96;//cto


    public static String getInvoiceTypeDesc(int invoiceTypeId) {
        if (InvoiceTypeId_D == invoiceTypeId) {
            return "电票";
        } else if (InvoiceTypeId_P == invoiceTypeId) {
            return "普票";
        } else if (InvoiceTypeId_Z == invoiceTypeId) {
            return "增票";
        } else if (InvoiceTypeId_N == invoiceTypeId) {
            return "不开票";
        } else {
            return "";
        }
    }
}
