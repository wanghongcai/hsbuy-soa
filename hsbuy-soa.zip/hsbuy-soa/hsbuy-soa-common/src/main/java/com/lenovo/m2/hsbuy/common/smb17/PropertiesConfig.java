package com.lenovo.m2.hsbuy.common.smb17;


public class PropertiesConfig{

	private String openO2O = "on";
	private String openZy = "on";

	private String openDz = "on";

	private String huiShangZF = "off";

	private String interfaceUrl="";
	private String appKey="";
	private String appSecret="";
	private String method="";
	private String sts="";

	private String smbUrl="";
	public String getSmbUrl() {
		return smbUrl;
	}

	public void setSmbUrl(String smbUrl) {
		this.smbUrl = smbUrl;
	}

	public String getInterfaceUrl() {
		return interfaceUrl;
	}

	public void setInterfaceUrl(String interfaceUrl) {
		this.interfaceUrl = interfaceUrl;
	}
	public String getAppKey() {
		return appKey;
	}

	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}
	public String getAppSecret() {
		return appSecret;
	}

	public void setAppSecret(String appSecret) {
		this.appSecret = appSecret;
	}
	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}
	public String getSts() {
		return sts;
	}

	public void setSts(String sts) {
		this.sts = sts;
	}

	public String getOpenDz() {
		return openDz;
	}

	public void setOpenDz(String openDz) {
		this.openDz = openDz;
	}

	public String getHuiShangZF() {
		return huiShangZF;
	}
	public void setHuiShangZF(String huiShangZF) {
		this.huiShangZF = huiShangZF;
	}

	public String getOpenO2O() {
		return openO2O;
	}

	public void setOpenO2O(String openO2O) {
		this.openO2O = openO2O;
	}

	public String getOpenZy() {
		return openZy;
	}

	public void setOpenZy(String openZy) {
		this.openZy = openZy;
	}

}

