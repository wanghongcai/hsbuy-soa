package com.lenovo.m2.hsbuy.common.pruchase.enums;

public enum ExtraType {
	
	NORMAL(0, "普通"), 
	C2C(1, "C2C"), 
	OLD4NEW(2,"以旧换新"),
	DXM(3,"大侠码");
	
	private final int type;
	private final String desc;
	
	
	ExtraType(int type, String desc){
		this.type = type;
		this.desc = desc;
	}


	public int getType() {
		return type;
	}


	public String getDesc() {
		return desc;
	}

	
	
}
