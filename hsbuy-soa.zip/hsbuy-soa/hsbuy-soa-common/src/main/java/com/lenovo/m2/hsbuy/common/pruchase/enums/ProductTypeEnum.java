/**
 * Project Name:purchase-soa-common
 * File Name:ProductTypeEnum.java
 * Package Name:com.lenovo.m2.buy.purchase.common.enums
 * Date:2017年2月21日下午1:57:13
 * Copyright (c) 2017, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.hsbuy.common.pruchase.enums;
/**
 * ClassName:ProductTypeEnum <br/>
 * Function: 商品类型，实物,和虚拟. <br/>
 * Date:     2017年2月21日 下午1:57:13 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */
public enum ProductTypeEnum {
	REALY("0","实物"),
	VIRTUAL("1","虚拟");
	
	ProductTypeEnum(String code,String common){
		this.setCode(code);
		this.setCommon(common);
	}
	private String code;//code名称
	private String common;// 序列说明
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getCommon() {
		return common;
	}
	public void setCommon(String common) {
		this.common = common;
	}
}

