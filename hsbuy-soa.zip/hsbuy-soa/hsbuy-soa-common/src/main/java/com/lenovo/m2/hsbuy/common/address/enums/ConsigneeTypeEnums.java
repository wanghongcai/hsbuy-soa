package com.lenovo.m2.hsbuy.common.address.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * @Author licy13
 * @Date 2017/2/20
 */

public enum ConsigneeTypeEnums {
    SH(1, "SH"),
    SP(2, "SP"),
    HT(3, "HT"),
    DONGDE(4, "dongde"),
    ZD(5, "ZD");

    private int code;
    private String name;

    private static Map<String,ConsigneeTypeEnums> map=new HashMap<>();

    static{
        for(ConsigneeTypeEnums consigneeTypeEnums: ConsigneeTypeEnums.values()){
            map.put(consigneeTypeEnums.name, consigneeTypeEnums);
        }
    }
    public static  ConsigneeTypeEnums getTypeEnum(String name){
       return map.get(name);
    }

    ConsigneeTypeEnums(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
