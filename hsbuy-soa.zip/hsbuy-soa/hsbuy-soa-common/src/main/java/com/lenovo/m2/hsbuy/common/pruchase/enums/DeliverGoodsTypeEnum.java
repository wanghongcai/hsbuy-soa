/**
 * Project Name:purchase-soa-common
 * File Name:DeliverGoodsTypeEnum.java
 * Package Name:com.lenovo.m2.buy.purchase.common.enums
 * Date:2017年7月19日下午7:33:51
 * Copyright (c) 2017, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.hsbuy.common.pruchase.enums;

import java.util.HashMap;

/**
 * ClassName:DeliverGoodsTypeEnum <br/>
 * Function: MOTO送货方式. <br/>
 * Date:     2017年7月19日 下午7:33:51 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */
public enum DeliverGoodsTypeEnum {
	AIRE_MODE("L1","Air Mode"),//空运
	SURFACE_MODE("L2","Surface Mode"),//陆运
	SELF_PICK("S2","Customer will come and pick up")//自取
	;
	
	private static HashMap<String,DeliverGoodsTypeEnum> map = new HashMap<>();
	
	private String code;//code名称
	private String common;// 序列说明
	DeliverGoodsTypeEnum(String code,String common){
		this.setCode(code);
		this.setCommon(common);
	}
	//枚举转map
	public static  HashMap<String,DeliverGoodsTypeEnum> getMap(){
		if(!map.isEmpty()){
			return map;
		}
		DeliverGoodsTypeEnum temps [] = DeliverGoodsTypeEnum.values();
		for(DeliverGoodsTypeEnum temp : temps){
			map.put(temp.getCode(), temp);
		}
		return map;
	}
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getCommon() {
		return common;
	}
	public void setCommon(String common) {
		this.common = common;
	}
}

