package com.lenovo.m2.hsbuy.common.pay.constants.ordersoa;

import java.util.HashMap;
import java.util.Map;

/**
 * @Description:
 * @author: lijie14
 * @Date: 2017/3/17.
 * @Version:1.0
 */
public class OpTableMap {
    private static  Map<String,String> opMap=null;
    public  static Map<String,String> getOpMap(){
        if(null == opMap){
            opMap =new HashMap<String, String>();
        }
        return opMap;
    }
}
