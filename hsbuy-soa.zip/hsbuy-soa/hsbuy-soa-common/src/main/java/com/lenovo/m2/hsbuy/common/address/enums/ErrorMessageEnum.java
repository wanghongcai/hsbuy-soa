/**
 * Project Name:order-address-common
 * File Name:ErrorMessageEnums.java
 * Package Name:com.lenovo.m2.buy.order.address.common.emuns
 * Date:2016年6月29日下午4:19:48
 * Copyright (c) 2016, chenzhou1025@126.com All Rights Reserved.
 *
*/

package com.lenovo.m2.hsbuy.common.address.enums;
/**
 * 接口返回信息
 */
public enum ErrorMessageEnum {
	SUCCESS("00000","success"),
	ERROR_SYSTEM_BUSY("99999","系统繁忙,请稍后再试！"),
	ERROR_PARAM("10000","参数错误！"),
	ERROR_FAIL("10001","操作失败!"),
	ERROR_ADD_TOO_MANY01("10002","您可添加最多20条地址"),
	ERROR_NOT_FIND_RECORD("10003","没有找到对应记录"),
	ERROR_EMPTY_MOBILE_TEL("10004","手机号为必填项"),
	ERROR_MOBILE("10005","手机号格式不正确"),
	ERROR_TEL("10006","固定电话格式不正确"),
	ERROR_TOO_QUICK("10007","请不要频繁添加相同的地址记录!"),
	ERROR_DETAIL_TOO_LONG("10008","详细地址最多60个字符"),
	ERROR_JXS_REPEATED("10009","您已经添加过同维度的地址（省市区组成唯一维度）"),
	GETID_FAIL("10010","获取地址ID失败!"),
	NOT_ALLOW_UPDATE("10011","不支持修改收货地址!"),
	ERROR_GET_SEC_ID("10012","没有查到SecId信息！"),
	ERROR_GET_ADDRESS_BY_ID("10013","查询地址信息失败！"),
	ERROR_ADD_TOO_MANY02("10014","您可添加最多10条地址"),
	ERROR_IDENTITY_SAME_PHOTOS("10015","请不要上传两张一模一样的图片资质，否则审核无法通过"),
	ERROR_IDENTITY_MAX_SIZE_5M("10016","图片不能大于5M，请重新上传!"),
	ERROR_IDENTITY_NUM("10017","身份证号有误，请核对后重新填写！"),
	ERROR_RETURNADDRESS_BINDING_RETURNREASON("10018","退货地址绑定有退货原因，请解绑后再操作！"),
	ERROR_RETURNREASONCODE_EXIST("10019","退货原因编码已存在！"),
	ERROR_NOT_BINDING_RETURNADDRESS("10020","退货原因没有绑定退货地址，无法启用！");


	private String code;// 代号
	private String common;// 说明
	
	
	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public String getCommon() {
		return common;
	}


	public void setCommon(String common) {
		this.common = common;
	}


	ErrorMessageEnum(String code, String common) {
		this.code = code;
		this.common = common;
	}


}

