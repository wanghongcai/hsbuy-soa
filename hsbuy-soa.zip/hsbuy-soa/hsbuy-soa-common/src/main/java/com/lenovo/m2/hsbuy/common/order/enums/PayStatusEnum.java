package com.lenovo.m2.hsbuy.common.order.enums;

/**
 * Created by zhaocl1 on 2017/5/23.
 */
public enum PayStatusEnum {
    NOPAID("未支付",0),
    PAID("已支付",1),
    PARTPAID("部分支付",2);

    private String name;
    private int value;

    PayStatusEnum(String name, int value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public int getValue() {
        return value;
    }
}
