package com.lenovo.m2.hsbuy.common.pay.enums;

import com.lenovo.m2.arch.tool.util.StringUtils;

/**
 * 返回信息
 *
 * @Author zyg
 * @Date 2017/4/11
 */

public enum ResultMessageEnum {
    SUCCESS("1000", "操作成功"),
    PARAM_EMPTY("1002", "参数为空"),

    RS_EXIST("3001","数据已存在"),
    RS_NOT_EXIST("3002","未查询到数据信息"),

    DEL_FAILE("4001","删除失败"),

    ERROR_INTERFACE("9998", "异常"),
    ERROR_PARAM("9996", "参数有误"),
    ERROR("9999", "异常");



    private String code;
    private String desc;

    ResultMessageEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    /**
     * 判断成功
     *
     * @param code
     * @return
     */
    public static boolean isSuccess(String code) {
        if (StringUtils.isEmpty(code)) {
            return false;
        }
        return SUCCESS.getCode().equals(code);
    }

}
