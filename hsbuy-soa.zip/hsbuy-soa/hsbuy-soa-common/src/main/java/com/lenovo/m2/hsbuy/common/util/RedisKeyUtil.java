package com.lenovo.m2.hsbuy.common.util;

/**
 * @author wangrq1
 * @create 2017-07-18 下午7:53
 **/
public class RedisKeyUtil {



    private static String CART_KEY_PREFIX = "C|%s|%s";

    public static String getCartKey(Integer shopId, String userId){
        return String.format(CART_KEY_PREFIX, shopId, userId);
    }

    public static String getOrderedDealNo(int shopId){
        return String.format("ORDERED_DEALNO|%s", shopId);
    }


    public static String getSeckillCartKey(Integer shopId, String userId) {
        return String.format("S|%s|%s", shopId, userId);
    }

    public static String getPriceListCartKey(int shopid, String userid){
        return String.format("P|%s|%s", shopid, userid);
    }

}
