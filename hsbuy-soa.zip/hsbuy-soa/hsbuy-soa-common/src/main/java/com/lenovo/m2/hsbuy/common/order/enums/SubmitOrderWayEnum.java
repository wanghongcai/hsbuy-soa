package com.lenovo.m2.hsbuy.common.order.enums;

/**
 * Created by zhaocl1 on 2017/9/20.
 */
public enum  SubmitOrderWayEnum {

    SMB_SILENTORDER("SMB静默下单",1),
    SMB_HANDORDER("SMB手工单",2),
    SMB_ASKORDER("SMB询价单",3),
    HS_NOSILENTORDER("慧商非静默下单",1),
    HS_SILENTORDER("慧商静默下单",2);

    private String name;
    private int value;

    SubmitOrderWayEnum(String name, int value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public int getValue() {
        return value;
    }
}
