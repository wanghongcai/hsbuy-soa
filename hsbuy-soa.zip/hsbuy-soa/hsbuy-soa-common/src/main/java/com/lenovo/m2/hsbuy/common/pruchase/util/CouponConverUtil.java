package com.lenovo.m2.hsbuy.common.pruchase.util;

/**
 * 
* @ClassName: CouponConverUtil 
* @Description:优惠券需要的数据转化
* @author yuzj7@lenovo.com 
* @date 2016年3月12日 下午3:20:17 
*
 */
public class CouponConverUtil {
	/**
	 * 
	* @Title: getCouponShopId 
	* @Description: 转shopid
	* @param shopId
	* @return    设定文件
	 */
	public static String getCouponShopId(int shopId){
		/*if(shopId == ShopIdEnum.EPP.getType()){
			return "EPP";
		}else if(shopId == ShopIdEnum.LENOVO.getType()){
			return "Lenovo";
		}else if(shopId == ShopIdEnum.THINK.getType()){
			return "Think";
		}else if(shopId == ShopIdEnum.ROMING.getType() ){
			return "Roaming";
		}else if(shopId == ShopIdEnum.MOTO.getType() ){
			return "Moto";
		}else{
			return "Lenovo";
		}*/
		return shopId+"";
		
	}
	/**
	 * 
	* @Title: getTerminal 
	* @Description: 转 terminal
	* @param termial
	* @return    设定文件
	 */
	public static int getTerminal(int termial){
		/*if(Terminal.WAP.getType() == termial){
			return 1;
		}else if(Terminal.WECHAT.getType() == termial){
			return 3;
		}else if(Terminal.APP.getType() == termial){
			return 2;
		}else{//PC
			return 0;
		}*/
		return termial;
	}
	
}
