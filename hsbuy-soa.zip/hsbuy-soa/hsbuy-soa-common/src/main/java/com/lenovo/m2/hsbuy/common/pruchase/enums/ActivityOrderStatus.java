package com.lenovo.m2.hsbuy.common.pruchase.enums;

/**
 * 活动关心的订单状态， 没订单状态多
 * @author wangrq1
 *
 */
public enum ActivityOrderStatus {
	
	NEW_ORDER(0, "下单未支付"), CANCELD(1,"已撤销"), PAYED(2, "已支付"), REFUND(3,"已退货");
	
	
	private int status;
	private String desc;
	
	
	ActivityOrderStatus(int status, String desc){
		this.status = status;
		this.desc = desc;
	}



	public String getDesc() {
		return desc;
	}


	public void setDesc(String desc) {
		this.desc = desc;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
	

}
