package com.lenovo.m2.hsbuy.common.pruchase.enums;

/**
 * 
 * @ClassName: CheckOutTypeEnum
 * @Description: 结算叶特殊订单信息【为了方便标示，减少从复判断】
 * @author yuzj7@lenovo.com
 * @date 2016年5月5日 下午2:48:04
 *
 */
public enum CheckOutTypeEnum {
	NORMAL("normal", "普通"),
	SPECAIL1("dongde", "懂得通信"),
	DONGDE_NONUMBER("dongdenonumber", "懂得没有号码"),
	LENOVO_MAKER("lenovo_maker","lenovo 定制"),
	PRESELL("presell","预售订单");

	private String code;// 代号
	private String common;// 说明

	CheckOutTypeEnum(String code, String common) {
		this.code = code;
		this.common = common;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCommon() {
		return common;
	}

	public void setCommon(String common) {
		this.common = common;
	}
}
