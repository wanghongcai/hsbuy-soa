package com.lenovo.m2.hsbuy.common.util;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.common.enums.GloablMessageEnum;
import org.apache.commons.lang3.StringUtils;

/**
 * @author wangrq1
 * @create 2017-03-17 下午4:00
 **/
public class RemoteResultFactory {

    private RemoteResultFactory(){};



    public static RemoteResult getErrorResult(GloablMessageEnum messageEnum, String reason){
        RemoteResult ret = new RemoteResult(false);
        ret.setResultCode(messageEnum.getCode());
        if(StringUtils.isEmpty(reason)){
           ret.setResultMsg(messageEnum.getCommon());
        }else{
            ret.setResultMsg(reason);
        }
        return  ret;
    }


    public static RemoteResult getErrorResult(GloablMessageEnum messageEnum){
        return getErrorResult(messageEnum, null);
    }


    public static <T> RemoteResult getSuccessResult(T t){
        RemoteResult ret = new RemoteResult(true);
        ret.setResultCode(GloablMessageEnum.SUCCESS.getCode());
        ret.setT(t);
        return ret;
    }


    public static RemoteResult getSuccessResult(){
        RemoteResult ret = new RemoteResult(true);
        ret.setResultCode(GloablMessageEnum.SUCCESS.getCode());
        return ret;
    }



}
