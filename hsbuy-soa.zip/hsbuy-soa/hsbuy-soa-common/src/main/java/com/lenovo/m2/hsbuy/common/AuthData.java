package com.lenovo.m2.hsbuy.common;

import org.apache.commons.collections.CollectionUtils;

import java.io.Serializable;
import java.util.List;

/**
 * Created by lihc5 on 2017/3/21.
 */
public class AuthData implements Serializable {



    private List<String> faIds;

    private List<String> storeIds; //门店id

    private String userid;

    //经销商Id
    private String agencyId;

    //310 经销商
    private List<String> roleType;


    private List<String> buOwner;


    //true 零售商  flase  店员
    private boolean retailerOrClerk = true;

    private String storeId;



    private List<String> shopIds;


    public List<String> getFaIds() {
        return faIds;
    }

    public void setFaIds(List<String> faIds) {
        this.faIds = faIds;
    }

    public List<String> getStoreIds() {
        return storeIds;
    }

    public void setStoreIds(List<String> storeIds) {
        this.storeIds = storeIds;
    }



    private static String RETAILER_ROLE = "310";

    private static String MAIN_BUOWNER = "70002";



    public void init(){
        if(roleType != null && roleType.contains(RETAILER_ROLE)){
            retailerOrClerk = true;
        }else{
            retailerOrClerk = false;
        }


        if(CollectionUtils.isNotEmpty(buOwner)){
            int size = buOwner.size();
            if(size == 2 && buOwner.contains(MAIN_BUOWNER)){
                for(String str: buOwner){
                    if(!MAIN_BUOWNER.equals(str)){
                        this.agencyId = str;
                        break;
                    }
                }
            }
        }

        //只有一个门店权限 && 非经销商
        if(faIds != null && faIds.size() == 1 && !retailerOrClerk){
            this.storeId = faIds.get(0);
        }

    }


	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public List<String> getShopIds() {
        return shopIds;
    }

    public void setShopIds(List<String> shopIds) {
        this.shopIds = shopIds;
    }

    public String getAgencyId() {
        return agencyId;
    }

    public void setAgencyId(String agencyId) {
        this.agencyId = agencyId;
    }


    public boolean isRetailerOrClerk() {
        return retailerOrClerk;
    }

    public void setRetailerOrClerk(boolean retailerOrClerk) {
        this.retailerOrClerk = retailerOrClerk;
    }


    public List<String> getRoleType() {
        return roleType;
    }

    public void setRoleType(List<String> roleType) {
        this.roleType = roleType;
    }

    public List<String> getBuOwner() {
        return buOwner;
    }

    public void setBuOwner(List<String> buOwner) {
        this.buOwner = buOwner;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }
}
