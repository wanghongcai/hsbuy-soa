package com.lenovo.m2.hsbuy.common;

/**
 * Cache Key汇总
 */
public class CacheConstant {
    /*================ 相关缓存常量=====================*/
    public static final String CACHE_PREFIX_INIT_MEMBERVATINVOICE = "INVOICE_MEMBERVATINVOICE_";
    public static final String CACHE_PREFIX_INIT_FAID = "INVOICE_MEMBERFAID_";

    public static final String CACHE_PREFIX_OWNERKEY = "SEQUENCE_OWNER_KEY_";
    public static final String CACHE_PREFIX_LOCKKEY = "SEQUENCE_LOCKED_KEY_";
    public static final String CACHE_PREFIX_SETTING = "SEQUENCE_SETTING";

}
