package com.lenovo.m2.hsbuy.common.pay.util.ordersoa;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @Description:
 * @author: lijie14
 * @Date: 2017/5/3.
 * @Version:1.0
 */
public class LoggerUtil {
    private static Logger logger;;

    public  LoggerUtil(String name) {
        logger=LogManager.getLogger(name);
    }
    public void warn(String content){
        logger.warn(content);
    }
    public void warn(String content,Exception e){
        logger.warn(content,e);
    }
    public void info(String content){
        logger.info(content);
    }
    public void info(String content,Exception e){
        logger.info(content,e);
    }
    public void error(String content,Object obj){
        logger.error(content,obj);
    }
    public void error(String content){
        logger.error(content);
    }
}
