package com.lenovo.m2.hsbuy.common.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * @author hangb1
 * @create 2017/11/22 10:05
 **/
public enum GloablErrorMessageEnum {

    SUCCESS("0", "操作成功"),
    ERROR_OPERATIONDATA("10000", "数据操作失败"),
    ERROR_PARAM_ILLEGAL("10001", "参数不合法"),
    ERROR_PRODUCT_NOTFOUND("10002", "未找到商品"),
    ERROR_USER_NOTLOGIN("10003", "请重新登录"),
    ERROR_PUSH_REDIS("10004", "推送redis失败"),
    ERROR_VERIFY_SIGN_FAILD("10005", "验签失败"),
    ERROR_SYSTEM_ERROR("99999", "系统错误"),
    IS_OPERATIONDATA("1", "true");

    private String code;
    private String common;
    static final Map<String, GloablErrorMessageEnum> enumMap = new HashMap();

    private GloablErrorMessageEnum(String code, String common) {
        this.code = code;
        this.common = common;
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCommon() {
        return this.common;
    }

    public void setCommon(String common) {
        this.common = common;
    }

    public static GloablErrorMessageEnum getDisabledByType(String code) {
        if(enumMap.size() > 0) {
            return (GloablErrorMessageEnum)enumMap.get(code);
        } else {
            GloablErrorMessageEnum[] gloablErrorMessageEnums = values();
            GloablErrorMessageEnum[] arr$ = gloablErrorMessageEnums;
            int len$ = gloablErrorMessageEnums.length;

            for(int i$ = 0; i$ < len$; ++i$) {
                GloablErrorMessageEnum gloablErrorMessageEnum = arr$[i$];
                enumMap.put(gloablErrorMessageEnum.getCode(), gloablErrorMessageEnum);
            }

            return (GloablErrorMessageEnum)enumMap.get(code);
        }
    }

}
