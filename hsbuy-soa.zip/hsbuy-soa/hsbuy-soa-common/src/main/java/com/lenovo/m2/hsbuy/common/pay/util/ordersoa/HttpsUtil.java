package com.lenovo.m2.hsbuy.common.pay.util.ordersoa;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;

import javax.net.ssl.*;
import java.io.*;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;


public class HttpsUtil {

	private static class TrustAnyTrustManager implements X509TrustManager {

		public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
		}

		public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
		}

		public X509Certificate[] getAcceptedIssuers() {
			return new X509Certificate[] {};
		}
	}

	private static class TrustAnyHostnameVerifier implements HostnameVerifier {
		public boolean verify(String hostname, SSLSession session) {
			return true;
		}
	}

	/**
	 * post方式请求服务器(https协议)
	 * 
	 * @param url
	 *            请求地址
	 * @param content
	 *            参数
	 * @param charset
	 *            编码
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws KeyManagementException
	 * @throws IOException
	 */
	public static byte[] post(String url, String content, String charset) throws NoSuchAlgorithmException, KeyManagementException, IOException {
		SSLContext sc = SSLContext.getInstance("SSL");
		sc.init(null, new TrustManager[] { new TrustAnyTrustManager() }, new SecureRandom());

		URL console = new URL(url);
		HttpsURLConnection conn = (HttpsURLConnection) console.openConnection();
		conn.setSSLSocketFactory(sc.getSocketFactory());
		conn.setHostnameVerifier(new TrustAnyHostnameVerifier());
		conn.setDoOutput(true);
		conn.connect();
		DataOutputStream out = new DataOutputStream(conn.getOutputStream());
		out.write(content.getBytes(charset));
		// 刷新、关闭
		out.flush();
		out.close();
		InputStream is = conn.getInputStream();
		if (is != null) {
			ByteArrayOutputStream outStream = new ByteArrayOutputStream();
			byte[] buffer = new byte[1024];
			int len = 0;
			while ((len = is.read(buffer)) != -1) {
				outStream.write(buffer, 0, len);
			}
			is.close();
			return outStream.toByteArray();
		}
		return null;
	}


    public static String zsPostHttps(String url,String data,String pkcs12Key,String pkcs12Path,String charset) throws Exception {

        //TODO 注意PKCS12证书 是从微信商户平台-》账户设置-》 API安全 中下载的
        KeyStore keyStore  = KeyStore.getInstance("PKCS12");
        //TODO P12文件目录
        FileInputStream instream = new FileInputStream(new File(pkcs12Path));
        try {
            //TODO 修改更换密码,默认mch_id。修改完成
            keyStore.load(instream, pkcs12Key.toCharArray());
        } finally {
            instream.close();
        }
        // Trust own CA and all self-signed certs
       //TODO 此处需要修改，这里也是写密码的。修改完成
        SSLContext sslcontext = SSLContexts.custom().loadKeyMaterial(keyStore, pkcs12Key.toCharArray()).build();
        // Allow TLSv1 protocol only
        SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext, new String[] { "TLSv1" }, null, SSLConnectionSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER);
        CloseableHttpClient httpclient = HttpClients.custom().setSSLSocketFactory(sslsf).build();
        try {
            // TODO 设置响应头信息
            HttpPost httpost = new HttpPost(url);
            httpost.addHeader("Connection", "keep-alive");
            httpost.addHeader("Accept", "*/*");
            httpost.addHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            httpost.addHeader("Host", "api.mch.weixin.qq.com");
            httpost.addHeader("X-Requested-With", "XMLHttpRequest");
            httpost.addHeader("Cache-Control", "max-age=0");
            httpost.addHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0) ");
            // TODO 请求信息
            httpost.setEntity(new StringEntity(data, charset));
            CloseableHttpResponse response = httpclient.execute(httpost);
            try {
                HttpEntity entity = response.getEntity();
                String jsonStr = EntityUtils.toString(response.getEntity(),charset);
                EntityUtils.consume(entity);
                return jsonStr;
            } finally {
                response.close();
            }
        } finally {
            httpclient.close();
        }
    }



	public static void main3(String[] args) {
		try {
			byte[] buf = post("https://api.weixin.qq.com/sns/oauth2/access_token", "appid=wx5139487540446ebf&secret=ad759c4f16f0ec8233d299156fabf350&code=04195b778bb31b69b3f428a5e1935d2S&grant_type=authorization_code", "UTF-8");
			System.out.println(new String(buf));
		} catch (KeyManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void mainx(String[] args) {
		try {
			byte[] buf = post("weixin://wxpay/bizpayurl", "appid=wx5139487540446ebf&mch_id=1228575202&nonce_str=5K8264ILTKCH1XCQ2502SI8ZNMTM67VS&product_id=11&time_stamp=1429108692", "UTF-8");
			System.out.println(new String(buf));
		} catch (KeyManagementException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


    public static void main333(String[] args) {
		try {
			StringBuffer sb = new StringBuffer();
			sb.append("<xml>");
			sb.append("	<appid>wx5139487540446ebf</appid>");
			sb.append(" <attach>支付测试</attach>");
			sb.append("	<body>JSAPI支付测试</body>");
			sb.append("	<mch_id>1228575202</mch_id>");
			sb.append("	<nonce_str>1add1a30ac87aa2db72f57a2375d8fec</nonce_str>");
			sb.append("	<notify_url>http://www.wangjianlog.cn/test.jsp</notify_url>");
			sb.append("	<out_trade_no>1415659993</out_trade_no>");
			sb.append("	<spbill_create_ip>14.23.150.211</spbill_create_ip>");
			sb.append("	<total_fee>1</total_fee>");
			sb.append("	<trade_type>NATIVE</trade_type>");
			sb.append("	<sign>4079F18F9F2A8E0A3F47865DA7F72B1A</sign>");
			sb.append("</xml>");
			byte[] buf = post("https://api.mch.weixin.qq.com/pay/unifiedorder", sb.toString(), "UTF-8");
			System.out.println(new String(buf));
		} catch (KeyManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
