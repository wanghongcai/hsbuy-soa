
package com.lenovo.m2.hsbuy.common.util;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;


/**
 * @Description:
 * @author:
 */
public class HttpUtil {


	private static Log log = LogFactory.getLog(HttpUtil.class);
	
	private static int conTimeOutMs = 10000;
	private static int soTimeOutMs = 30000;

	/**
	 * @description 发送httpClient post 请求，json 格式返回
	 * @author qinhc
	 * @2015下午6:03:09
	 * @param url
	 * @param body
	 * @return
	 * @throws Exception
	 */
	public static String executeHttpPost(String url, String body)
			throws Exception {
		CloseableHttpClient httpclient = HttpClients.createDefault();
		StringEntity entity = new StringEntity(body, "utf-8");// 解决中文乱码问题
		entity.setContentEncoding("UTF-8");
		entity.setContentType("application/json");
		String resData = "";

		HttpPost method = new HttpPost(url);
		method.setEntity(entity);
		// 请求超时
		RequestConfig config = RequestConfig.custom().setSocketTimeout(soTimeOutMs).setConnectTimeout(conTimeOutMs).build();
		method.setConfig(config);
		try {
			HttpResponse result = httpclient.execute(method);
			// 请求结束，返回结果
			resData = EntityUtils.toString(result.getEntity());
			log.info("executeHttpPost返回：" + resData);
		} catch (Exception e) {
			log.error("executeHttpPost请求出错：" + e.getMessage());
		} finally {
			method.releaseConnection();
			httpclient.close();
			
		}
		return resData;
	}
	
	/**
	 * @description
	 * @author qinhc
	 * @2015下午6:00:41
	 * @param url
	 * @param body
	 * @param type 请求的类型
	 * @return
	 * @throws Exception
	 */
	public static String executeHttpPostType(String url, String body,String type)
			throws Exception {
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost method = new HttpPost(url);
		StringEntity entity = new StringEntity(body, "utf-8");// 解决中文乱码问题
		entity.setContentEncoding("UTF-8");
		entity.setContentType(type);
		method.setEntity(entity);
		String resData = "";
		// 请求超时
		RequestConfig config = RequestConfig.custom().setSocketTimeout(soTimeOutMs).setConnectTimeout(conTimeOutMs).build();
		method.setConfig(config);
		try {
			HttpResponse result = httpclient.execute(method);
			// 请求结束，返回结果
			resData = EntityUtils.toString(result.getEntity());
			log.info("executeHttpPostType返回的数据：" + resData);
		} catch (Exception e) {
			log.error("executeHttpPostType请求出错：" + e.getMessage());
		} finally {
			method.releaseConnection();
			httpclient.close();
		}
		return resData;
	}
	
	/**
	 * 
	* @Description: post 提交
	* @author yuzj7@lenovo.com  
	* @date 2015年5月15日 上午10:41:49
	* @param url
	* @param params
	* @return
	 */
	public static String postStr(String url, Map<String, String> params) throws UnsupportedEncodingException{
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost(url);
		httpPost.setHeader("Content-Type", "text/html;charset=UTF-8");
		List<NameValuePair> nvps = new ArrayList<NameValuePair>();
		if (params != null && !params.isEmpty()) {
			for (Entry<String, String> entry : params.entrySet()) {
				nvps.add(new BasicNameValuePair(entry.getKey(), entry
						.getValue()));
			}
		}
		httpPost.setEntity(new UrlEncodedFormEntity(nvps, "utf-8"));
		String line = null;   
		String str="";
		 try { 
			HttpResponse response=httpclient.execute(httpPost);
			HttpEntity entity = response.getEntity();
			InputStreamReader inputstream = new InputStreamReader(entity.getContent(), "UTF-8");
			BufferedReader reader = new BufferedReader(inputstream);   
			// 显示结果   
			while ((line = reader.readLine()) != null) {   
				str+=line;   
			} 
			reader.close();
			inputstream.close();
		 }catch(Exception e){
			log.error("postStr error -->", e);
		 }finally{
			 try{
				 if(httpclient != null){
					 httpclient.close();
				 }
			 }catch(Exception e){
				 log.error("httpclient error -->", e);
			 }
		 }
		return str;
	}
	
	
	/**
	 * post 方法
	 * @param url
	 * @return
	 * @author mamj
	 * @throws UnsupportedEncodingException 
	 * @date 2013-11-19 下午03:46:58
	 */
	public static String PostStr(String url, Map<String, String> params,String referer,String cookie,boolean isproxy,String charset) throws UnsupportedEncodingException{
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost(url);
		// 请求超时
		RequestConfig config = RequestConfig.custom().setSocketTimeout(soTimeOutMs).setConnectTimeout(conTimeOutMs).build();
		httpPost.setConfig(config);

		List<NameValuePair> nvps = new ArrayList<NameValuePair>();
		if (params != null && !params.isEmpty()) {
			for (Entry<String, String> entry : params.entrySet()) {
				nvps.add(new BasicNameValuePair(entry.getKey(), entry
						.getValue()));
			}
		}
		if(!StringUtils.isEmpty(cookie)){
			httpPost.setHeader("Cookie", cookie);
		}
		if(!StringUtils.isEmpty(referer)){
			httpPost.addHeader("Referer", referer);
		}
         
         if(StringUtils.isEmpty(charset)){
        	 charset = "utf-8";
         }
		httpPost.setEntity(new UrlEncodedFormEntity(nvps, charset));
		String line = null;   
		 StringBuffer str = new StringBuffer("");  
		 InputStreamReader inreader = null;
		 BufferedReader reader = null;
		 try { 
			HttpResponse response=httpclient.execute(httpPost);
			HttpEntity entity = response.getEntity();
			inreader = new InputStreamReader(entity.getContent(), charset);
			reader  = new BufferedReader(inreader);   
			// 显示结果   
			while ((line = reader.readLine()) != null) {   
				str.append(line);
			} 
		 }catch(Exception e){
			log.error("httpPost error -->", e);
		 }finally{
			 if (reader != null) {
	        	  try {
	        		  reader.close();// 最后要关闭BufferedReader  
				} catch (Exception e) {
					  log.error("reader error -->", e);
				}
	          }
	    	  if(inreader != null){
	    		  try {
	    			  inreader.close();
	    			  httpclient.close();
				} catch (Exception e) {
					  log.error("inreader error -->", e);
				}
	    	  }
		 }
		return str.toString();
	}
	
	
	/**
	 * 
	* @Description: http get 请求
	* @author yuzj7@lenovo.com  
	* @date 2015年6月11日 下午5:53:28
	* @param url
	* @return
	 */
	public static String getStr(String url) {
		
		  BufferedReader in = null;  
	      // 定义HttpClient  
		  CloseableHttpClient client = HttpClients.createDefault();
	      // 实例化HTTP方法  
	      HttpGet request = new HttpGet();
	      String line = "";  
	      String tmp="";
	      try {  
		  //修改特殊字符bu
		     URL url1 = new URL(url);
		     URI uri = new URI(url1.getProtocol(), url1.getHost(), url1.getPath(), url1.getQuery(), null);
		      request.setURI(uri);  
		      request.setHeader("Content-Type", "text/html;charset=UTF-8");
		      HttpResponse response = client.execute(request);
	          in = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF-8"));   
	          while ((tmp=in.readLine()) != null) {   
	            line+=tmp;   
	          }
	      }catch (Exception e) {
			  log.error("url error -->", e);
		  }finally{
	    	  if (in != null) {
	        	  try {
					in.close();// 最后要关闭BufferedReader  
					client.close();
				} catch (Exception e) {
					  log.error("in error -->", e);
				}
	          }
	      }  
	      return line;  
	            
	}

    /**
     *
     * @Description: http get 请求
     * @author yuzj7@lenovo.com
     * @date 2015年6月11日 下午5:53:28
     * @param url
     * @return
     */
    public static String getStrSend(String url) {

        BufferedReader in = null;
        // 定义HttpClient
        CloseableHttpClient client = HttpClients.createDefault();
        // 实例化HTTP方法
        HttpGet request = new HttpGet();
        String line = "";
        String tmp="";
        try {
            //修改特殊字符bu
            URL url1 = new URL(url);
            URI uri = new URI(url1.getProtocol(), url1.getUserInfo(), url1.getHost(),url1.getPort(), url1.getPath() , url1.getQuery(), null);
            request.setURI(uri);
            request.setHeader("Content-Type", "text/html;charset=UTF-8");
            HttpResponse response = client.execute(request);
            in = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
            while ((tmp=in.readLine()) != null) {
                line+=tmp;
            }
        }catch (Exception e) {
			log.error("url error -->", e);
        }finally{
            if (in != null) {
                try {
                    in.close();// 最后要关闭BufferedReader
                    client.close();
                } catch (IOException e) {
					log.error("in error -->", e);
                }
            }
        }
        return line;

    }



	public static void main(String[] args) throws UnsupportedEncodingException {
        String CTO_LENOVO_MAKER = (String) CustomizedPropertyConfigurer.getContextProperty("cto.lenovo.maker");

        String usr = "?orderId=1&terminal=1";

        System.out.println(CTO_LENOVO_MAKER);

        String url = CTO_LENOVO_MAKER + usr;

        String str =  getStrSend(url);

        System.out.println(str);


//
//		List<String> temp = new ArrayList<>(1);
//		for(int i=0;i<2;i++){
//			temp.add("djfajdf");
//		}
//		System.out.println(JsonUtil.toJson(temp));
//		/*String ids = "84f339fe-73fd-b375-c58e-0154dc39e9f9";
//
//		 System.out.println("releaseStock paras is {}"+ids);
//		    List<String> temp = new ArrayList<>(1);
//		    temp.add(ids);
//		    Map<String, Object> map = new HashMap<>();
//		    map.put("listReservationIds", temp);
//		    String json = JsonUtil.toJson(map);
//		    System.out.println("after convert :{}"+json);
//		    String url = String.format("%s/api/special/releaseStockNum.jhtm?json=%s", "http://stock.front.lenovouat.cn", json);
//		    System.out.println("url :{}"+ url);
//		    String response = HttpUtil.postStr(url, params);
//		    System.out.println("releaseStock return :"+response);*/
//		List<String> ids = new ArrayList<>(2);
//		ids.add("84f339fe-73fd-b375-c58e-0154dc39e9f9");
//		System.out.println("releaseStock paras is {}"+ids);
//		Map<String, Object> map = new HashMap<>();
//		map.put("listReservationIds", ids);
//		String json = JsonUtil.toJson(map);
//		System.out.println("after convert :{}"+json);
//		String jsonString =  Base64.encode(json.getBytes());
//		Map<String, String> requestMap = new HashMap<>();
//        requestMap.put("json", jsonString);
//
//		String url = String.format("%s/api/special/releaseStockNum.jhtm?json=%s", "http://stock.front.lenovouat.cn",jsonString);
//		System.out.println(jsonString+"url :{}"+ url);
//		String response = HttpUtil.getStr(url);
//		System.out.println("releaseStock return :"+response);
	}

}
