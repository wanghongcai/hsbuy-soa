package com.lenovo.m2.hsbuy.common.pay.util.soa;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import net.sf.json.JSONException;
import net.sf.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by tianchuyang on 2017/5/9.
 */
public class LePayUtil {

    public static final String SHOP_ID_HUISHANG = "14";
    public static final String SHOP_ID_MOTO = "16";

    public static final Integer ACCOUNT_TYPE_B2C = 1;
    public static final Integer ACCOUNT_TYPE_B2B = 2;

    /**
     * 判断多字符串参数全不为空
     * @param args
     * @return
     */
    public static boolean isParamsEmpty(String... args){
        for (String arg : args) {
            if (null == arg || "".equals(arg.trim())){
                return true;
            }
        }
        return false;
    }

    /**
     * 组装返回结果
     * @param remoteResult
     * @param t
     * @param status
     * @param resultCode
     * @param resultMsg
     * @param <T>
     * @return
     */
    public static <T> RemoteResult<T> getRemoteResult(RemoteResult<T> remoteResult, T t, boolean status, String resultCode, String resultMsg) {
        remoteResult.setT(t);
        remoteResult.setResultCode(resultCode);
        remoteResult.setResultMsg(resultMsg);
        remoteResult.setSuccess(status);
        return remoteResult;
    }

    /**
     * Json转Map
     * @param jsonString
     * @return
     * @throws JSONException
     */
    public static Map<String, String> jsonToMap(String jsonString)
            throws JSONException {
        JSONObject jsonObject = JSONObject.fromObject(jsonString);
        Map<String, String> result = new HashMap<String, String>();
        Iterator iterator = jsonObject.keys();
        String key = null;
        String value = null;
        while (iterator.hasNext()) {
            key = String.valueOf(iterator.next());
            value = String.valueOf(jsonObject.get(key));
            result.put(key, value);
        }
        return result;
    }
}
