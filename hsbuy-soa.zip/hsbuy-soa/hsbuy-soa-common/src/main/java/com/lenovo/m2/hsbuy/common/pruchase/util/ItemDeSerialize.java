package com.lenovo.m2.hsbuy.common.pruchase.util;

import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.DeserializationContext;
import org.codehaus.jackson.map.JsonDeserializer;

import java.io.IOException;


public class ItemDeSerialize extends JsonDeserializer{

	@Override
	public Object deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException, JsonProcessingException {
		
//		ctxt.
		
		
		return null;
	}

}
