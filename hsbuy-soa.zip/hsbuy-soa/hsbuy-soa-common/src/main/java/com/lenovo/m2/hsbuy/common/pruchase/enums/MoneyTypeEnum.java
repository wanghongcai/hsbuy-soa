/**
 * Project Name:purchase-soa-common
 * File Name:MoneyTypeEnum.java
 * Package Name:com.lenovo.m2.buy.purchase.common.enums
 * Date:2016年7月29日下午4:06:17
 * Copyright (c) 2016, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.hsbuy.common.pruchase.enums;
/**
 * ClassName:MoneyTypeEnum <br/>
 * Function: money type. 默认是钱，积分商城时表示积分<br/>
 * Date:     2016年7月29日 下午4:06:17 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */
public enum MoneyTypeEnum {
	MONEY,SCORE;
}

