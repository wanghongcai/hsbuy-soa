package com.lenovo.m2.hsbuy.common.pruchase.constants;
/**
 * 
* @ClassName: Contants
* @Description: 常量类
* @author yuzj7@lenovo.com
* @date 2015年5月18日 下午12:22:32
*
 */
public class Contants {
	//接口签名校验key
	public static final String 	MD5_KEY = ")(*&^%$#@!MNBVCX76543";
	//乐豆接口校验key 
	public static final String MD5_HAPPYBEAN = "@#$23@89_lenovo_ledou#00";
	//md5 订单退货取消md5校验
	public static final String MD5_ORDER = "!@#$%^&*()";

	//购物车行选中标记 1选中 0未勾选
	public static final int CART_CHECK_STATUS_TRUE = 1;
	public static final int CART_CHECK_STATUS_FALSE = 0;
    //购物车不使用促销规则标记
	public static final String CART_NO_USE_PROMOTION = "-1";
	
	//首单立减 redis key
	public final static String FIRST_ORDER_ = "FIRST_ORDER_";
	
	//超时异常订单redis key 
	public final static String TIME_OUT_ORDER_ = "TIME_OUT_ORDER_";
	
	
	//不需要扣除库存返回特殊id
	public static final long SPECIAL_STOCKID= 999l;

}
