package com.lenovo.m2.hsbuy.common.order.enums;

/**
 * Created by zhaocl1 on 2017/10/25.
 */
public enum TerminalEnum {

    PC(1),
    WAP(2),
    APP(3),
    WEIXIN(4);

    private int termianl;

    TerminalEnum(int termianl) {
        this.termianl = termianl;
    }

    public int getTermianl() {
        return termianl;
    }
}
