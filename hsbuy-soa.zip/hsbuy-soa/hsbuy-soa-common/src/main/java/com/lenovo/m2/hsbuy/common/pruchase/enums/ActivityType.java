package com.lenovo.m2.hsbuy.common.pruchase.enums;


public enum ActivityType  {

	GROUP_BUY(1, "团购"), FLUAH_SALE(2,"闪购"), TIME_LIMIT_SALE(3,"限时抢购");


	private int type;
	private String desc;


	ActivityType(int type, String desc){
		this.type = type;
		this.desc = desc;
	}


	public static ActivityType getActivityType(int type){
		switch(type){
			case 1:
				return GROUP_BUY;
			case 2:
				return FLUAH_SALE;
			case 3:
				return TIME_LIMIT_SALE;
			default:
				return null;
		}
	}

	public static void main(String[] args) {
		Integer a = null;
		System.out.print(ActivityType.getActivityType(a));
	}


	public int getType() {
		return type;
	}


	public void setType(int type) {
		this.type = type;
	}


	public String getDesc() {
		return desc;
	}


	public void setDesc(String desc) {
		this.desc = desc;
	}






}
