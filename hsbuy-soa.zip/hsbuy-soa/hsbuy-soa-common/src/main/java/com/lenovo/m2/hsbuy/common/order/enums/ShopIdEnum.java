package com.lenovo.m2.hsbuy.common.order.enums;

/**
 * Created by zhaocl1 on 2017/5/23.
 */
public enum ShopIdEnum {
    SMB(8),
    SCORE(9),
    HUISHANG(14),
    HUISHANGJF(15);

    private int shopId;

    ShopIdEnum(int shopId) {
        this.shopId = shopId;
    }

    public int getShopId() {
        return shopId;
    }
}
