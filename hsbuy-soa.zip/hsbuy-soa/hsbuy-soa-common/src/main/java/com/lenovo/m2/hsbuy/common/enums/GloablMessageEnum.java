package com.lenovo.m2.hsbuy.common.enums;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

/**
 * Created by lihc5 on 2017-03-15.
 */
public enum GloablMessageEnum {

	SUCCESS("0", "操作成功"),
	ERROR_OPERATIONDATA("10000","数据操作失败"),	
	ERROR_PARAM_ILLEGAL("10001","参数不合法"),
    ERROR_PRODUCT_NOTFOUND("10002","未找到商品"),
    ERROR_USER_NOTLOGIN("10003","请重新登录"),
    ERROR_PUSH_REDIS("10004","推送redis失败"),
    ERROR_VERIFY_SIGN_FAILD("10005","验签失败"),
    ERROR_hsbuy_ID("10006","未知的hsbuyId"),
    ERROR_NO_PERMISSION("10007","没有数据权限"),
    ERROR_GOODS_ILLEGAL("10008","商品数据不合法"),
    ERROR_NULL_REASON("10009","拒绝原因不能为空"),
    ERROR_CONDITION_REFUSE("10010","不符合审核驳回条件"),
    ERROR_CONDITION_PASS("10011","不符合审核通过条件"),
    ERROR_USER_ID("10012","未知的cartKey"),
    ERROR_NO_GROUPCODE("10013","没有组编码"),
    ERROR_NO_GROUPNAME("10014","没有组名称"),

    ERROR_SYSTEM_ERROR("99999","系统错误"),
    IS_OPERATIONDATA("1","true"),

	//-----   购物车 提示
    ERROR_CART_BEYOND("10016","超出最大购买数量"),
	ERROR_PN_NOTNULL("10015","pn码无对应商品数据"),
	ERROR_CART_REPERTORY_IS_NULL("11000","库存信息为空"),


    //------  订单 提示
    ERROR_ORDER_RETURNED("50001","商品已退货！"),
    ERROR_ORDER_GAIN_ORDER_FAILED("50002","生成订单号失败，请稍后再试！"),
    ERROR_ORDER_EXCHANGE_OUT_INVENTRY_FAILED("50003","换货出库失败，请稍后再试！"),
    ERROR_ORDER_SAVE_FAILED("50004","保存订单失败"),
    ORDER_SAVE_SUCCESS("50005","保存订单成功"),
    ERROR_ORDER_SAVE_REVERSE_FAILED("50006","保存反向订单失败"),
    ORDER_SAVE_REVERSE_SUCCESS("50007","保存反向订单成功"),
    ORDER_UPDATE_DELIVERY_SUCCESS("50008","订单交付成功"),
    ORDER_UPDATE_DELIVERY_FAILED("50009","订单交付失败"),
    ORDER_NOT_DELIVERED("50010","订单未交付"),
    ORDER_TO_CHANGE("50011","商品以换货"),


    ERROR_ORDER_TYPE_NOT_MATCH_WITH_PAYMENTWAY("10017","订单类型与支付方式不匹配！"),
    ERROR_GAIN_ORDER("10018","生成订单失败，请稍后再试！"),
    ERROR_SAVE_ORDER_INFO("10019","保存订单信息失败！"),
    ERROR_GET_CART_INFO("10020","购物车为空！"),
    ERROR_NOTICE_STOCK_SAIL("10021","扣减库存失败，请稍后再试！"),









    //库存
    INVENTORY_SUCCESSFUL("0000","成功！"),
    INVENTORY_FAILURE("9999","失败！"),
    INVENTORY_PARAM_ERROR("1000","参数不能为空!"),
    INVENTORY_REPEAT_ERROR("1001","库存入库重复!"),
    INVENTORY_RETURN_ERROR("1002","库存采购退货失败,已分配库存或没找到库存。"),
    INVENTORY_IN_ERROR("1003","此商品是直营商品不可录入自有!"),
    INVENTORY_ASSIGNSTORE_ERROR("1004","此商品不是直营商品!"),
    INVENTORY_OUT_ERROR("1005","库存不够!"),
    INVENTORY_OUT_DEFECTIVEGOODS_ERROR("1006","次品不可出库!"),
    ROLLBACKINVENTORY_ERROR("1007","没有找到可会滚的订单，回滚失败！"),
    HAVEBEENALLOCATED_ERROR("1008","已分配的"),
    UPDATE_STOREINFO_ERROR("2001","门店更新失败!"),
    DISTRIBUTION_ERROR("2002","分配数更新失败!")







    ;

    private String code;
    private String common;
    GloablMessageEnum(String code, String common){
        this.code = code;
        this.common = common;
     }

    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public String getCommon() {
        return common;
    }
    public void setCommon(String common) {
        this.common = common;
    }

    final  static Map<String,GloablMessageEnum> enumMap = new HashMap<String,GloablMessageEnum>();
    public static GloablMessageEnum getDisabledByType(String code){
        if(enumMap.size() > 0){
            return enumMap.get(code);
        }
        GloablMessageEnum[]gloablErrorMessageEnums =  GloablMessageEnum.values();
        for (GloablMessageEnum gloablErrorMessageEnum:gloablErrorMessageEnums){
            enumMap.put(gloablErrorMessageEnum.getCode(),gloablErrorMessageEnum);
        }
        return enumMap.get(code);
    }
    
    
    //  ** -- -- ---用于国际化
    //存储 国际化 国家信息     key 国家   value(map: key:code - value:common)
    static Map<String,Map<String,String>> intMap = new HashMap<String,Map<String,String>>();
    private  static String intCode ;  //当前用户的国家信息
   
    //获得 国际化编码信息
    public String getIntCommon(){
//    	if("zh".equals(intCode)){  //直接返回
//    		return getCommon(); 
//    	}
    	
    	if(intMap.size() > 0){
    		Map<String, String> map = intMap.get(intCode);
    		if(map != null && map.size() > 0){
    			return map.get(code);
    		}
    		map = new HashMap<String,String>();
    		//组装数据  组装  code  对应的 提示   这 加载 要加载对应的 国家信息
    		assembleInt(map);
    		return map.get(code);
    	}
    	//组装数据  默认组装当前国家的
    	assemble();
    	
		return intMap.get(intCode).get(code);
    }
  

	//组装数据  
   	private void assemble() {
   		Map<String,String> map = new HashMap<String,String>();
   		assembleInt(map);
   		intMap.put(intCode, map); //中文
   	}
   	
	private void assembleInt(Map<String, String> map) {
		//
		ResourceBundle bundle = ResourceBundle.getBundle("hsbuy-soa_"+intCode);
		
		Enumeration<String> keys = bundle.getKeys();
		 
		while(keys.hasMoreElements()){
			String nextk = keys.nextElement();   //这个是名称
			String value = bundle.getString(nextk);
			map.put(nextk, value);
		}
	}
   

	public static void setIntCode(String intCode) {
		GloablMessageEnum.intCode = intCode;
	}
}

