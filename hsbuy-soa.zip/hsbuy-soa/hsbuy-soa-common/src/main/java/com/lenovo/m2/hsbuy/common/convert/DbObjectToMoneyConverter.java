package com.lenovo.m2.hsbuy.common.convert;

import com.lenovo.m2.arch.framework.domain.Money;
import com.mongodb.DBObject;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;

/**
 * Created by zhangzhen on 17/1/3.
 */
@ReadingConverter
public class DbObjectToMoneyConverter implements Converter<DBObject, Money> {
    @Override
    public Money convert(DBObject source) {
        if (source==null){
            return new Money("0.00",Money.DEFAULT_CURRENCY_CODE);
        }
        String amount = String.valueOf(source.get("amount"));
        String currencyCode = (String) source.get("currencyCode");
        return new Money(amount == null ? "0" : amount, currencyCode == null ? Money.DEFAULT_CURRENCY_CODE : currencyCode);
    }
}
