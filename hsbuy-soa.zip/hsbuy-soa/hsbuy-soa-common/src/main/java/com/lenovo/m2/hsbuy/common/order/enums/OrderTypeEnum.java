package com.lenovo.m2.hsbuy.common.order.enums;

/**
 * Created by zhaocl1 on 2017/5/23.
 */
public enum OrderTypeEnum {

    NORMAL("普通",0),
    CUSTOM_MADE("定制",5),
    CTO("CTO",9);

    private String name;
    private int value;

    OrderTypeEnum(String name, int value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public int getValue() {
        return value;
    }
}
