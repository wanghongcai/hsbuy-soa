package com.lenovo.m2.hsbuy.common.convert;

import com.lenovo.m2.arch.framework.domain.Money;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;

/**
 * Created by zhangzhen on 17/1/3.
 */
@ReadingConverter
public class DoubleToMoneyConverter implements Converter<Double, Money> {
    @Override
    public Money convert(Double source) {
        return new Money(source, Money.DEFAULT_CURRENCY_CODE);
    }
}
