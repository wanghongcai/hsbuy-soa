package com.lenovo.m2.hsbuy.common.order.enums;

/**
 * Created by zhaocl1 on 2017/5/25.
 */
public enum InvoiceTypeIdEnum {

    INVOICE_TYPE_ID_D("电票",0) ,
    INVOICE_TYPE_ID_P("普票",1),
    INVOICE_TYPE_ID_Z("增票",2) ,
    INVOICE_TYPE_ID_N("不开票",999);

    private String name;
    private int value;

    InvoiceTypeIdEnum(String name, int value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public int getValue() {
        return value;
    }
}
