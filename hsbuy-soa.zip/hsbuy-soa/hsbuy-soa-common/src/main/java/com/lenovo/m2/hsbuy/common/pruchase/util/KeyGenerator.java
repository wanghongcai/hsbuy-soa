package com.lenovo.m2.hsbuy.common.pruchase.util;

import java.util.UUID;

public class KeyGenerator {
	
	
	
	public static String uuidKey(){
		return UUID.randomUUID().toString();
	} 
	

}
