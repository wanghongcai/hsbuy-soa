package com.lenovo.m2.hsbuy.common.util;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import java.security.MessageDigest;

/**
 * Created by liucf6 on 2015/8/27.
 */
public class MessageMD5Utils {
    private static Logger logger = Logger.getLogger(MessageMD5Utils.class);
    public static String md5Digest(String src)
    {
        try {
            //MessageDigest md = MessageDigest.getInstance("MD5");
            //byte[] b = md.digest(src.getBytes("utf-8"));
            byte[] b = DigestUtils.md5(src.getBytes("utf-8"));
            return byte2HexStr(b);
        }catch (Exception e){
            logger.error("获取MD5出错"+e.getMessage(),e);
        }
        return null;
    }

    private static String byte2HexStr(byte[] b)
    {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < b.length; ++i) {
            String s = Integer.toHexString(b[i] & 0xFF);
            if (s.length() == 1){
                sb.append("0");
            }
            sb.append(s);
        }
        return sb.toString();
    }

    /**
     * 比较MD5是否相等
     * @param value
     * @param compareMD5Value
     * @return
     */
    public static boolean md5Equal(String value,String compareMD5Value){
        if (StringUtils.isEmpty(value) || (StringUtils.isEmpty(compareMD5Value))){
            return false;
        }
        String md5Value = md5Digest(value);
        if (md5Value.toUpperCase().equals(compareMD5Value.toUpperCase())){
            return true;
        }else {
            return false;
        }
    }

    public static void main(String[] args) {
        String str = md5Digest("10017xx578j##x!$cds89dfsd1501493664238");
        System.out.println(str);

        System.out.println(str.length());
    }
}
