package com.lenovo.m2.hsbuy.common.order.enums;

/**
 * Created by zhaocl1 on 2017/5/23.
 */
public enum AuditStatusEnum {

    NONEED("自动过审 即不需要审核",0),
    PASSED("审核通过(如需合同，则已生成合同)",1),
    PENDING("待审核",2),
    REFUSAL("拒审",3) ,
    PENDING_CONTRACT("审批通过，待生成合同",4),
    SIGN_CONTRACT("签署合同",5);

    private String name;
    private int value;

    AuditStatusEnum(String name, int value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public int getValue() {
        return value;
    }
}
