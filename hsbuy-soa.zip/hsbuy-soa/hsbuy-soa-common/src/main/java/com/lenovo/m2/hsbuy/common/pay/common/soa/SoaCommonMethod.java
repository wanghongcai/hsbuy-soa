package com.lenovo.m2.hsbuy.common.pay.common.soa;

/**
 * Created by luyang on 2016/3/18.
 */
public class SoaCommonMethod {
    private static final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(SoaCommonMethod.class);

    public static String getPlatFromShopIdTerminal(String shopId, String terminal) {
        String plat = "";
        if(Constant.SHOPID_LENOVO.equals(shopId)){
            if(Constant.TERMINAL_PC.equals(terminal)){
                plat = Constant.PLAT_PC;
            }else if(Constant.TERMINAL_WAP.equals(terminal)){
                plat = Constant.PLAT_WAP;
            }else if(Constant.TERMINAL_APP.equals(terminal)){
                plat = Constant.PLAT_APP;
            }else if(Constant.TERMINAL_WECHAT.equals(terminal)){
                plat = Constant.PLAT_WX;
            }
        }else if(Constant.SHOPID_THINK.equals(shopId)){
            if(Constant.TERMINAL_PC.equals(terminal)){
                plat = Constant.PLAT_THINK_PC;
            }else if(Constant.TERMINAL_WAP.equals(terminal)){
                plat = Constant.PLAT_THINK_WAP;
            }else if(Constant.TERMINAL_APP.equals(terminal)){
                plat = Constant.PLAT_THINK_APP;
            }else if(Constant.TERMINAL_WECHAT.equals(terminal)){
                plat = Constant.PLAT_THINK_WX;
            }
        }else if(Constant.SHOPID_EPP.equals(shopId)){
            if(Constant.TERMINAL_PC.equals(terminal)){
                plat = Constant.PLAT_EPP_PC;
            }else if(Constant.TERMINAL_WAP.equals(terminal)){
                plat = Constant.PLAT_EPP_WAP;
            }else if(Constant.TERMINAL_APP.equals(terminal)){
                logger.info("商城及平台错误");
            }else if(Constant.TERMINAL_WECHAT.equals(terminal)){
                logger.info("商城及平台错误");
            }
        }else if(Constant.SHOPID_ROAMING.equals(shopId)){
            plat = Constant.PLAT_ROAMING;
        }else if(Constant.SHOPID_MOTO.equals(shopId)){
            if(Constant.TERMINAL_PC.equals(terminal)){
                plat = Constant.PLAT_MOTO_PC;
            }else if(Constant.TERMINAL_WAP.equals(terminal)){
                plat = Constant.PLAT_MOTO_WAP;
            }else if(Constant.TERMINAL_APP.equals(terminal)){
                plat = Constant.PLAT_MOTO_APP;
            }else if(Constant.TERMINAL_WECHAT.equals(terminal)){
                plat = Constant.PLAT_MOTO_WX;
            }
        }else if(Constant.SHOPID_DONGDE.equals(shopId)){

        }else if(Constant.SHOPID_THINKCENTER.equals(shopId)){

        }
        return plat;
    }
    public static String getShopIdFromPlat(String plat){
        String shopId = "";
        if(Constant.PLAT_PC.equals(plat)|| Constant.PLAT_WAP.equals(plat)|| Constant.PLAT_APP.equals(plat)|| Constant.PLAT_WX.equals(plat)){
            shopId = Constant.SHOPID_LENOVO;
        }else if(Constant.PLAT_THINK_PC.equals(plat)|| Constant.PLAT_THINK_WAP.equals(plat)|| Constant.PLAT_THINK_APP.equals(plat)|| Constant.PLAT_THINK_WX.equals(plat)){
            shopId = Constant.SHOPID_THINK;
        }else if(Constant.PLAT_EPP_PC.equals(plat)|| Constant.PLAT_EPP_WAP.equals(plat)){
            shopId = Constant.SHOPID_EPP;
        }else if(Constant.PLAT_ROAMING.equals(plat)){
            shopId = Constant.SHOPID_ROAMING;
        }else if(Constant.PLAT_MOTO_PC.equals(plat)|| Constant.PLAT_MOTO_WAP.equals(plat)|| Constant.PLAT_MOTO_APP.equals(plat)|| Constant.PLAT_MOTO_WX.equals(plat)){
            shopId = Constant.SHOPID_MOTO;
        }
        return shopId;
    }
    public static String getTerminalFromPlat(String plat){
        String terminal = "";
        if(Constant.PLAT_PC.equals(plat)|| Constant.PLAT_THINK_PC.equals(plat)|| Constant.PLAT_EPP_PC.equals(plat)|| Constant.PLAT_MOTO_PC.equals(plat)){
            terminal = Constant.TERMINAL_PC;
        }else if(Constant.PLAT_WAP.equals(plat)|| Constant.PLAT_THINK_WAP.equals(plat)|| Constant.PLAT_EPP_WAP.equals(plat)|| Constant.PLAT_MOTO_WAP.equals(plat)){
            terminal = Constant.TERMINAL_WAP;
        }else if(Constant.PLAT_APP.equals(plat)|| Constant.PLAT_THINK_APP.equals(plat)|| Constant.PLAT_MOTO_APP.equals(plat)|| Constant.PLAT_ROAMING.equals(plat)){
            terminal = Constant.TERMINAL_APP;
        }else if(Constant.PLAT_WX.equals(plat)|| Constant.PLAT_THINK_WX.equals(plat)|| Constant.PLAT_MOTO_WX.equals(plat)){
            terminal = Constant.TERMINAL_WECHAT;
        }
        return terminal;
    }
}
