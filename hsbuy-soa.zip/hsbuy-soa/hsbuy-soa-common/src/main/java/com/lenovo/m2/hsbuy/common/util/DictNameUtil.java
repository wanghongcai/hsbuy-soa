package com.lenovo.m2.hsbuy.common.util;

import com.lenovo.dict.DICT;
import com.lenovo.dict.DictUtil;
import com.lenovo.m2.arch.tool.util.StringUtils;

import java.util.Map;

/**
 * Created by Administrator on 2017-08-17.
 */
public class DictNameUtil {

    public static String getName(String key,String value) {
        if (StringUtils.isEmpty(key) || StringUtils.isEmpty(value)) {
            return "";
        }
        Map<String, String> map =  DictUtil.getDictMap(DICT.LangCode.en, key);
        String  name = map.get(value);
        return name;
    }
}
