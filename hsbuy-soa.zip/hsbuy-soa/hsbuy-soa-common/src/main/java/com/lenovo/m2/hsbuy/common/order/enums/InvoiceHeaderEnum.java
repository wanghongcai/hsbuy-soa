package com.lenovo.m2.hsbuy.common.order.enums;

/**
 * Created by zhaocl1 on 2017/6/21.
 */
public enum InvoiceHeaderEnum {

    PERSION("个人","0"),
    COMPANY("公司","1");

    private String name;
    private String value;

    InvoiceHeaderEnum(String name, String value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public String getValue() {
        return value;
    }
}
