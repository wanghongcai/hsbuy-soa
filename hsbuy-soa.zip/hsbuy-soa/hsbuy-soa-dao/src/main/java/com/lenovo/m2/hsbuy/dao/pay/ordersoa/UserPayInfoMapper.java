package com.lenovo.m2.hsbuy.dao.pay.ordersoa;


import com.lenovo.m2.arch.framework.domain.PageModel;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.UserPayInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface UserPayInfoMapper {

    /**
     * 用户支付渠道查询
     *
     * @return
     */
    UserPayInfo findUserPayInfoAll(@Param("id") Integer id);


    /**
     * 添加用户支付渠道
     *
     * @param userPayInfo
     * @return
     */
    int saveUserPayInfo(UserPayInfo userPayInfo);

    /**
     * 修改
     *
     * @param userPayInfo
     * @return
     */
    int updateUserPayInfo(UserPayInfo userPayInfo);

    /**
     * 批量删除
     *
     * @param map
     * @return
     */
    int deleteUserPayInfo(Map map);

    /**
     * 根据userNo 查询商户 支付渠道信息
     *
     * @param userNo
     * @return
     */
    List<UserPayInfo> getUserPayInfoByUserNo(@Param("userNo") String userNo);

    /**
     * 根据id查询
     *
     * @param id
     * @return
     */

    UserPayInfo findById(@Param("id") Integer id);

    /**
     * 查询唯一
     *
     * @param userNo
     * @param accountType
     * @param payTypeCode
     * @return
     */

    List<UserPayInfo> getUserPayInfoByOnly(@Param("userNo") String userNo, @Param("accountType") Integer accountType, @Param("payTypeCode") Integer payTypeCode);

    /**
     * 分页
     *
     * @param pageQuery
     * @param map
     * @return
     */
    PageModel<UserPayInfo> getUserPayInfoPage(PageQuery pageQuery, Map map);

    /**
     * 根据userNo  查询渠道启用数量
     *
     * @param userNo
     * @return
     */
    int getEnableByUserNo(@Param("userNo") String userNo);

    /**
     * 修改状态
     *
     * @param userPayInfo
     * @return
     */
    int updateEnable(UserPayInfo userPayInfo);

    /**
     * 获取启用状态的信息
     *
     * @param userNo
     * @param payTypeCode
     * @return
     */
    int getUserPayInfoCountByUserNo(@Param("userNo") String userNo, @Param("payTypeCode") Integer payTypeCode);

}
