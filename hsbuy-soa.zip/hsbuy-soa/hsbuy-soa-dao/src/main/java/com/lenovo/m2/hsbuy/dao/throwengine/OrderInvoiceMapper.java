package com.lenovo.m2.hsbuy.dao.throwengine;


import com.lenovo.m2.hsbuy.domain.order.OrderInvoice;
import org.springframework.stereotype.Repository;

/**
 * Created by jiazy on 2017/6/1.
 */
@Repository("throwOrderInvoiceMapper")
public interface OrderInvoiceMapper {


    /**
     * 通过订单号获取发票信息
     *
     * @param orderId
     * @return
     */
    OrderInvoice getOrderInvoiceByOrderCode(Long orderId);

    /**
     * 更新普票审核信息
     *
     * @param orderInvoice
     * @return
     */
    int updateInvoiceAuditInfo(OrderInvoice orderInvoice);
}
