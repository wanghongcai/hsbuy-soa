package com.lenovo.m2.hsbuy.dao.pay.soa;

import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.PayFakeRules;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by luyang on 2016/5/6.
 */
public interface PayFakeRulesMapper {
    /**
     * 保存假支付规则
     * @param payFakeRules
     * @return
     */
    public int insertPayFakeRules(PayFakeRules payFakeRules);

    /**
     * 修改假支付规则
     * @param payFakeRules
     * @return
     */
    public int updatePayFakeRules(PayFakeRules payFakeRules);

    /**
     * 查询假支付规则
     * @param lenovoId
     * @return
     */
    public List<PayFakeRules> selectPayFakeRules(@Param("lenovoId") String lenovoId);
}
