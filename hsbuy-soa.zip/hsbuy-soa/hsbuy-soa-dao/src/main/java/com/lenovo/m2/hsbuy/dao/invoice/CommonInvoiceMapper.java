package com.lenovo.m2.hsbuy.dao.invoice;

import com.lenovo.m2.hsbuy.domain.invoice.VatInvoice;

/**
 * Created by admin on 2017/3/16.
 */
public interface CommonInvoiceMapper {

    //查询单个发票信息
    public VatInvoice getInvoiceById(Long id);

    //前台页面，保存发票信息
    public int saveInvoice(VatInvoice vatInvoice);

    //前台页面根据发票抬头带出发票信息，必须是已审核的
    public VatInvoice getInvoiceByTitle(VatInvoice vatInvoice);

    //根据发票抬头，税号，开票方式和发票类型查询，用于判断发票是否已存在
    public VatInvoice invoiceIsExist(VatInvoice vatInvoice);

}
