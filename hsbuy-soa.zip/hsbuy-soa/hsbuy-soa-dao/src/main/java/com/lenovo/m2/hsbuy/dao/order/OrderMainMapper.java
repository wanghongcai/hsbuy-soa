package com.lenovo.m2.hsbuy.dao.order;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.hsbuy.domain.order.OrderMain;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * Created by fenglg1 on 2015/5/19.
 */
public interface OrderMainMapper extends GenericDao<OrderMain, Long> {

     List<OrderMain> getOrderMainById(Long orderId);

     OrderMain getOrderMain(@Param("orderId") Long orderId, @Param("orderCode") Long orderCode);

     OrderMain getOrderMainByOrderCode(@Param("orderCode") Long orderCode);

     int saveOrderMain(OrderMain orderMain);

     int saveOrderMainList(List<OrderMain> orderMainList);

     int updateOrderStatusToCancelByOrderCode(Map paramMap);

     int updateOrderStatusToRevokeByOrderCode(Map paramMap);

     int updateOrderPayStatusByOrderCode(Map paramMap);

     int updateAbnormalOrderStatus(Map paramMap);

//     List<OrderMainItemVO> getAbnormalOrderItemsByOrderType(Map paramMap);
//
//     List<OrderMainItemVO> getAbnormalOrderItemsByOrderTypeExcludeSpecial(Map paramMap);
//
//     List<OrderMainItemVO> getAbnormalOrderItemByOrderTypeForSpecial(Map paramMap);
//
//     List<OrderMainItemVO> getOrderItemsByOrderCode(Map paramMap);

     int updateRewardLeDouOnOrderMain(Map paramMap);

     /**
      * 根据主单号取消订单
      * @param paramMap
      * @return
      */
     int updateAbnormalOrderStatusById(Map paramMap);

     /**
      * 根据主订单号更新支付信息
      * @param paramMap
      * @return
      */
     int updateOrderPayStatusByID(Map paramMap);

     List<OrderMain> getSignOrderList();
}
