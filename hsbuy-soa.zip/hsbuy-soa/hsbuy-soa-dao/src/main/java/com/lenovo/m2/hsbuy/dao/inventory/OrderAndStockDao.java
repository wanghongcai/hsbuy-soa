package com.lenovo.m2.hsbuy.dao.inventory;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.hsbuy.domain.inventory.OrderAndStock;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by zhangzhen10 on 15-7-8.
 */
public interface OrderAndStockDao extends GenericDao<OrderAndStock, Long> {


    /**
     * 增加新订单,订单和库存的关系
     *
     * @param orderAndStock
     * @return
     */
    public int insertOrderAndStock(OrderAndStock orderAndStock);

    /**
     * 查询订单相关的库存信息
     * @param orderId
     * @return
     */
    public List<OrderAndStock> queryOrderAndStocks(@Param("orderId") long orderId, @Param("shopId") Integer shopId);
    /**
     * 根据订单号查询库存扣减记录
     * @param orderCode
     * @return
     */
    List<OrderAndStock> getStockInfoByOrderCode(String orderCode);
}
