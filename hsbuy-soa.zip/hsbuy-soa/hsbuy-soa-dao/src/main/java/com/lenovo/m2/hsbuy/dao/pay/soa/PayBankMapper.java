package com.lenovo.m2.hsbuy.dao.pay.soa;


import com.lenovo.m2.hsbuy.domain.pay.soa.outpay.PayBank;

import java.util.List;

/**
 * 惠商银行查询
 * Created by tianchuyang on 2017/1/5.
 */
public interface PayBankMapper {

    /**
     * 获取惠商支持的所有银行
     * @return 银行列表
     */
    List<PayBank> getAllPayBanks();

    /**
     * 根据条件查询
     * @param bankQo
     * @return
     */
    PayBank getPayBankByParams(PayBank bankQo);
}
