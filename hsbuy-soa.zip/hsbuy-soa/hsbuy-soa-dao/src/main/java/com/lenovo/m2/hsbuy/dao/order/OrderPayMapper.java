package com.lenovo.m2.hsbuy.dao.order;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.hsbuy.domain.order.OrderPay;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by fenglg1 on 2015/6/6.
 */
public interface OrderPayMapper extends GenericDao<OrderPay, Long> {

    int saveOrderPay(OrderPay orderPay);

    int saveOrderPayList(List<OrderPay> orderPayList);

    List<OrderPay> getOrderPayByPayNo(String payNo);

    List<OrderPay> getOrderPayByOrderId(@Param("orderId") Long orderId);

    int saveOrderPaySmb(OrderPay orderPay);
}
