package com.lenovo.m2.hsbuy.dao.order;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.hsbuy.domain.order.Goodsmaterials;
import org.apache.ibatis.annotations.Param;

/**
 * Created by zhaocl1 on 2016/8/3..
 */
public interface GoodsmaterialsMapper extends GenericDao<Goodsmaterials, String> {

    String getMtart(@Param("lenovoMaterialNumber") String lenovoMaterialNumber, @Param("productGroupNo") String productGroupNo);
}
