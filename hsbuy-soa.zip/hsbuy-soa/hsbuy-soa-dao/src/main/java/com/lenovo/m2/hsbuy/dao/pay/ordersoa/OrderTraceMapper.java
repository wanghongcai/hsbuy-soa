package com.lenovo.m2.hsbuy.dao.pay.ordersoa;

import com.lenovo.m2.arch.framework.domain.PageModel;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.baseInfo.OrderTrace;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface OrderTraceMapper {
    int deleteByPrimaryKey(@Param("id") Integer id);
    int insert(OrderTrace record);
    int insertOrderTraceSelective(OrderTrace record);
    OrderTrace selectByPrimaryKey(@Param("id") Integer id);
    int updateByPrimaryKeySelective(OrderTrace record);
    int updateByPrimaryKey(OrderTrace record);

    List<OrderTrace> queryOrderTraceSelective(Map param);

    /**
     * 通过 主单号查询  支付数据
     * @param paramQuery  orderMainCodes   payStatus
     * @return
     */
    List<OrderTrace> queryUnpaidOrderByOrderMainCode(Map paramQuery);

    /**
     * 更新
     * @param orderTraceUpdate
     * @return
     */
    Integer updateOrderTtraceByPayCallBack(OrderTrace orderTraceUpdate);


    public List<OrderTrace> selectChannelOrderForCheck(Map param);

    /**
     * 批量取消order_trace订单
     * @param map
     * @returen
     */
    public int cancelOrderTraceList(Map map);

    /**
     * 查询OrderTrace表订单
     * @param map orderList
     * @return
     */
    public List<OrderTrace> queryOrderTraceList(Map map);

    /**
     * 对账查询
     * @param param mainFlag 1 orderDateS yyyy-MM-dd HH:mm:ss orderDateE payStatus 1 paymentWay 1
     * @return
     */
    List<OrderTrace> queryOrderTraceForCheckAccount(Map param);

    public PageModel<OrderTrace> queryOrderTracePage(PageQuery pageQuery, Map map);

    public Integer updateOrderTtraceHanndel(@Param("orderCode") String orderCode, @Param("payment") Integer payment, @Param("payFlowId") String payFlowId, @Param("payTime") String payTime);

    public PageModel<OrderTrace> queryOrderTraceCheckPage(PageQuery pageQuery, Map map);

    public Integer insertOrderTraceByJobSelective(OrderTrace orderTraceInsert);
}