package com.lenovo.m2.hsbuy.dao.pay.ordersoa;

import com.lenovo.m2.hsbuy.domain.pay.ordersoa.wxpay.ChannelOrderInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface ChannelOrderSubMapper {


    /**
     * 插入记录
     */
    int insertChannelOrderSubSelective(ChannelOrderInfo record);

    /**
     * 查询记录
     */
    List<ChannelOrderInfo> selectChannelOrderSubByExample(Map map);

    ChannelOrderInfo getChannelOrderSubDetail(@Param("orderCode") String orderCode, @Param("lenovoId") String lenovoId, @Param("shopId") String shopId);

    Integer updateChannelOrderSubByOrderRefund(@Param("orderCode") String orderCode, @Param("transationId") String refundNo, @Param("refundTime") String refundTime);

    List<ChannelOrderInfo> queryChannelOrderSubByTime(Map param);

    List<ChannelOrderInfo> queryChannelOrderSubBytransationId(Map paramQuery);
}