package com.lenovo.m2.hsbuy.dao.order;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MDeliveryAddress;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by fenglg1 on 2016/2/24.
 */
public interface MDeliveryAddressMapper extends GenericDao<MDeliveryAddress, Long> {

     MDeliveryAddress getMDeliveryAddressByOrderId(@Param("orderId") Long orderId);

     List<MDeliveryAddress> getMDeliveryAddressByOrderIdList(@Param("orderId") Long orderId);

     int saveMDeliveryAddress(MDeliveryAddress mDeliveryAddress);

     int saveMDeliveryAddressList(List<MDeliveryAddress> deliveryAddressList);

     int updateMDeliveryAddress(MDeliveryAddress mDeliveryAddress);
}
