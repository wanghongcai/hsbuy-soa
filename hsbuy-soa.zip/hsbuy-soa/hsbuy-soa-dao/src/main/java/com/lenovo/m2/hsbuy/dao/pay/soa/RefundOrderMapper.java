package com.lenovo.m2.hsbuy.dao.pay.soa;


import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.RefundOrderInfo;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by mengqiang1 on 2015/12/24.
 */
public interface RefundOrderMapper{

    /**
     * 保存退货记录
     * @param refundOrderInfo
     * @return
     */
    public Long saveRefundOrder(RefundOrderInfo refundOrderInfo);

    /**
     * 查询退款状态为初始状态的记录
     * @return
     */
    public List<RefundOrderInfo> queryRefundOrder();

    /**
     * 更新退货订单信息
     * @param refundNo
     * @param refundState
     * @param refundErrorMsg
     * @param updateTime
     * @param refundDesc
     */
    public void updateRefundOrder(@Param("refund_no") String refundNo, @Param("refund_state") int refundState, @Param("refund_error_msg") String refundErrorMsg, @Param("update_time") Date updateTime, @Param("refund_desc") String refundDesc);

    /**
     * 根据退货批次号更新记录
     * @param batchNo
     * @param refundState
     * @param refundErrorMsg
     * @param notifyFlag
     * @param updateTime
     */
    public void updateRefundOrderByBatchNo(@Param("batchNo") String batchNo, @Param("refundState") int refundState, @Param("refundErrorMsg") String refundErrorMsg, @Param("notifyFlag") int notifyFlag, @Param("updateTime") Date updateTime);

    /**
     * 根据退货号更新记录
     * @param refundNo
     * @param refundState
     * @param refundErrorMsg
     * @param notifyFlag
     * @param updateTime
     */
    public void updateRefundOrderByRefundNo(@Param("refundNo") String refundNo, @Param("refundState") int refundState, @Param("refundErrorMsg") String refundErrorMsg, @Param("notifyFlag") int notifyFlag, @Param("updateTime") Date updateTime);

    /**
     * 查询招行所需参数
     * @return
     */
    public Map<String,Object> queryCmbRefundOrder();
    /**
     * 查询招行分期所需参数
     * @return
     */
    public Map<String,Object> queryCmbFqRefundOrder();

    /**
     * 根据退款单号查询退货记录
     * @param refundNo
     * @return
     */
    public List<RefundOrderInfo> queryRefundOrderByRefundNo(@Param("refundNo") String refundNo);

    /**
     * 按条件查询
     * @param param
     * @return
     */
    public List<RefundOrderInfo> getRefundOrderByConf(Map param);

    /**
     * 获取退款记录列表
     * @param refundNo
     * @param shopId
     * @return
     */
    public List<RefundOrderInfo> getRefundOrderByRefundNoShopId(@Param("refundNo") String refundNo, @Param("shopId") String shopId);
}
