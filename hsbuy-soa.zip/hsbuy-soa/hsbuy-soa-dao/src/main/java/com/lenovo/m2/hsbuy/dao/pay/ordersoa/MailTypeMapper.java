package com.lenovo.m2.hsbuy.dao.pay.ordersoa;


import com.lenovo.m2.hsbuy.domain.pay.ordersoa.baseInfo.MailType;

import java.util.List;
import java.util.Map;

public interface MailTypeMapper {
    /**
     * 根据条件删除
     * @mbggenerated
     */
    int deleteMailType(Map param);

    /**
     * 选择性添加
     *
     * @mbggenerated
     */
    int insertMailTypeSelective(MailType record);

    /**
     * 选择性查找
     *
     * @mbggenerated
     */
    List<MailType> selectMailType(Map map);

    /**
     * 选择性修改
     * @mbggenerated
     */
    int updateMailTypeSelective(Map param);

}