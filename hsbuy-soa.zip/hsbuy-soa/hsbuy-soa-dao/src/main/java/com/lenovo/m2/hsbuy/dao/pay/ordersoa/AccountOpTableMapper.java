package com.lenovo.m2.hsbuy.dao.pay.ordersoa;




import com.lenovo.m2.hsbuy.domain.pay.ordersoa.wxpay.AccountOpTable;

import java.util.List;
import java.util.Map;

public interface AccountOpTableMapper {
    /**
     * 查询商户科目
     * @param example
     * @return
     */
    List<AccountOpTable> selectByExample(Map example);

}