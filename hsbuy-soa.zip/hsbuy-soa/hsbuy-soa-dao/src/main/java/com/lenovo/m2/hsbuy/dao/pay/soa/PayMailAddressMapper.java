package com.lenovo.m2.hsbuy.dao.pay.soa;

import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.PayMailAddress;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by luyan on 2016/3/25.
 */
public interface PayMailAddressMapper {
    /**
     * 获取收件人信息
     * @param mailType
     * @return
     */
    public List<PayMailAddress> queryAddressList(@Param("mailType") String mailType);
}
