package com.lenovo.m2.hsbuy.dao.pay.soa;

import com.lenovo.m2.hsbuy.domain.pay.soa.outpay.PayChannelBank;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by tianchuyang on 2017/1/13.
 */
public interface PayChannelBankMapper {

    PayChannelBank getPayChannelBankByParams(@Param("payplatId") Integer payplatId, @Param("bankCode") Integer bankCode,
                                             @Param("bankType") Integer bankType, @Param("cardType") Integer cardType);

    List<PayChannelBank> getPayChannelBanksByParams(PayChannelBank payChannelBank);

    List<PayChannelBank> getAllPayChannelBanks();
}
