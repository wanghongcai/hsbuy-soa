package com.lenovo.m2.hsbuy.dao.pricelist;


import com.lenovo.m2.hsbuy.domain.pricelist.PriceListPdf;

import java.util.List;

public interface PriceListPdfMapper {

	
	int deleteByPrimaryKey(Long id);

    int insert(PriceListPdf record);

    int insertSelective(PriceListPdf record);

    PriceListPdf selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(PriceListPdf record);

    int updateByPrimaryKey(PriceListPdf record);
    
    /**
     * 
     * @param example
     * @return
     * @desc userId必须设置
     */
    List<PriceListPdf> selectByExample(PriceListPdf example);
    
    
}