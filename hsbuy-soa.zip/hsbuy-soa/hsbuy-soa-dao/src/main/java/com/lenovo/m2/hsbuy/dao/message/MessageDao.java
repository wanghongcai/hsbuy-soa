package com.lenovo.m2.hsbuy.dao.message;

import com.lenovo.m2.arch.framework.domain.PageModel;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.hsbuy.domain.message.Message;

/**
 * Created by admin on 2017/3/14.
 */
public interface MessageDao {

    public int addMessage(Message message);

    public int updateMessage(Message message);

    public Message getMessage(Message message);

    public PageModel<Message> getMessageByPage(PageQuery pageQuery, Message message);

}
