package com.lenovo.m2.hsbuy.dao.order;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderInvoice;
import org.apache.ibatis.annotations.Param;

/**
 * Created by fenglg1 on 2016/2/25.
 */
public interface MOrderInvoiceMapper extends GenericDao<MOrderInvoice, Long> {

    public MOrderInvoice getMOrderInvoiceByOrderId(@Param("orderId") Long orderId);

    public int saveMOrderInvoice(MOrderInvoice mOrderInvoice);
}
