package com.lenovo.m2.hsbuy.dao.address;

import com.lenovo.m2.arch.framework.domain.PageModel;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.hsbuy.domain.address.Memberaddrs;
import com.lenovo.m2.hsbuy.domain.address.param.QueryAddressParam;

import java.util.List;

/**
 * Created by admin on 2017/7/27.
 * 用户地址
 */
public interface AddressMapper {

    /**
     * 保存用户地址
     * @param memberaddrs
     * @return
     */
    public int saveAddress(Memberaddrs memberaddrs);

    /**
     * 伪删除用户地址
     * @param queryAddressParam
     * @return
     */
    public int deleteAddress(QueryAddressParam queryAddressParam);

    /**
     * 更新用户地址
     * @param memberaddrs
     * @return
     */
    public int updateAddress(Memberaddrs memberaddrs);

    /**
     * 根据地址ID获取单条地址信息
     * @param queryAddressParam
     * @return
     */
    public Memberaddrs getAddressById(QueryAddressParam queryAddressParam);

    /**
     * 根据地址ID获取单条地址信息
     * @param id
     * @return
     */
    public Memberaddrs getAddressByPrimaryKey(String id);

    /**
     * 根据用户获取用户地址列表
     * @param queryAddressParam
     * @return
     */
    public List<Memberaddrs> getAddressListByUser(QueryAddressParam queryAddressParam);

    /**
     * 设置为用户所有地址为非默认
     * @param queryAddressParam
     * @return
     */
    public int setAllNoDefault(QueryAddressParam queryAddressParam);

    /**
     * 设置该地址为用户的默认地址
     * @param queryAddressParam
     * @return
     */
    public int setDefaultAddress(QueryAddressParam queryAddressParam);

    /**
     * 获取首选收货地址信息（即默认地址，如果没有默认地址，返回第一条）
     * @param queryAddressParam
     * @return
     */
    public Memberaddrs getPreferredAddress(QueryAddressParam queryAddressParam);

    /**
     * 个人中心获取用户地址总条数
     * @param queryAddressParam
     * @return
     */
    public int getAddressCount(QueryAddressParam queryAddressParam);

    /**
     * 个人中心获取分页数据
     * @param pageQuery
     * @param queryAddressParam
     * @return
     */
    public PageModel<Memberaddrs> getAddressListByPage(PageQuery pageQuery, QueryAddressParam queryAddressParam);

    /**
     * 根据地址ID获取guid，smb商城使用
     * @param id
     * @return
     */
    public String getGuidById(String id);

    /**
     * 根据guid获取地址ID，smb商城使用
     * @param guid
     * @return
     */
    public String getIdByGuid(String guid);


}
