package com.lenovo.m2.hsbuy.dao.order;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderMain;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * Created by fenglg1 on 2016/2/24.
 */
public interface MOrderMainMapper extends GenericDao<MOrderMain, Long> {

    MOrderMain getOrderMainByOrderCode(@Param("orderCode") Long orderCode);

    int saveMOrderMain(MOrderMain mOrderMain);

    int saveMOrderMainList(List<MOrderMain> mOrderMainList);

    int updateStatusByOrderCode(@Param("orderCode") Long orderCode, @Param("status") int status);

    int updateAbnormalOrderStatus(Map paramMap);

    /**
     * 更新订单的 应支付金额、客户备注、信用支付额度、审核状态
     * @param mOrderMain
     * @return
     */
    int updateMOrderMainAuditStatus(MOrderMain mOrderMain);

    int updateOrderPayStatusByOrderCode(Map paramMap);

    MOrderMain getOrderMainByOrderCodeByTest(@Param("orderCode") Long orderCode);
}
