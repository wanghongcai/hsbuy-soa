package com.lenovo.m2.hsbuy.dao.pay.ordersoa;


import com.lenovo.m2.hsbuy.domain.pay.ordersoa.PayWay;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface PayWayMapper {

    /**
     * 删除不可用支付方式
     *
     * @param id
     * @return
     */
    int deleteById(@Param("id") Integer id);

    /**
     * 单条插入 支付方式
     *
     * @param payWay
     * @return
     */
    int savePayWay(PayWay payWay);

    /**
     * 按照支付方式分组 查询支付渠道列表
     *
     * @return List<PayWay>
     */
    List<PayWay> getPayWayByGroupByPayWayCode();

    /**
     * 查询支付方式列表
     *
     * @param payWayCode
     * @param payTypeCode
     * @return
     */
    List<PayWay> queryPayWayList(@Param("payWayCode") Integer payWayCode, @Param("payTypeCode") Integer payTypeCode);

}