package com.lenovo.m2.hsbuy.dao.inventory;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.arch.framework.domain.PageModel;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.hsbuy.domain.inventory.GetStockInfoResult;
import com.lenovo.m2.hsbuy.domain.inventory.OrderAndStock;
import com.lenovo.m2.hsbuy.domain.inventory.StockInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * Created by Jiazy on 15-6-19.
 * Add by yezhenyue on 2015/8/17.批量删除
 */
public interface StockDao extends GenericDao<StockInfo,Long> {

    //增加新库存
    public Long addStockInfo(StockInfo stockInfo);

    //增加失效库存
    public int selectIntoInvalidStockInfo(StockInfo stockInfo);

    public int deleteStockInfo(StockInfo stockInfo);

    /**
     * 库存信息分页查询
     * @param pageQuery

     * @return
     */
    public PageModel<StockInfo> getStockInfoPage(PageQuery pageQuery, Map map);

    /**
     * 库存信息分页查询
     * @param pageQuery

     * @return
     */
    public PageModel<StockInfo> getActiveStockInfoPage(PageQuery pageQuery, Map map);
    /**
     * thinko2o库存信息分页查询
     * @param pageQuery

     * @return
     */
    public PageModel<StockInfo> getO2OStockInfoPage(PageQuery pageQuery, Map map);

    public GetStockInfoResult getStockInfo(Map map);

    /**
     * 库存详细信息分页查询
     * @param pageQuery

     * @return
     */
    public PageModel<StockInfo> getDetailStockInfoPage(PageQuery pageQuery, Map map);

    /**
     * 检查库存是否存在
     * @param productCode
     * @return
     */
    public List<StockInfo> checkStockExist(@Param("productCode") String productCode, @Param("activityType") int activityType, @Param("shopId") Integer shopId, @Param("storeId") String storeId);
    /*
        获取stockinfo信息
    */
    public StockInfo getStockInfoByProductCode(Map map);

    /**
     * 待支付
     * 减少可卖数，增加待支付(占用数)
     * @return
     */
    public int waitPay(@Param("goodsNumber") int goodsNumber,
                       @Param("productCode") String productCode, @Param("activityType") int activityType, @Param("shopId") Integer shopId);

    /**
     * 占用区域代理库存 thinko2o适用
     * @param goodsNumber
     * @param productCode
     * @param activityType
     * @param shopId
     * @param storeId
     * @return
     */
    public int waitPayByRegion(@Param("goodsNumber") int goodsNumber,
                               @Param("productCode") String productCode,
                               @Param("activityType") int activityType, @Param("shopId") Integer shopId, @Param("storeId") String storeId);
    /**
     * 补单 取消变已支付
     * @param goodsNumber
     * @param productCode
     * @param activityType
     * @param shopId
     * @param storeId
     * @return
     */
    public int freeToPaidStock(@Param("goodsNumber") int goodsNumber,
                               @Param("productCode") String productCode,
                               @Param("activityType") int activityType, @Param("shopId") Integer shopId, @Param("storeId") String storeId);
    /**
     * 已支付
     * 减少待支付数量(占用),增加已支付数量(冻结)
     * @param orderAndStock
     * @return
     */
    public int paidPay(OrderAndStock orderAndStock);

    /**
     * 取消订单
     * 减少待支付(占用)，增加可卖数
     * @param orderAndStock
     * @return
     */
    public int freePay(OrderAndStock orderAndStock);

    /**
     * 撤销订单
     * 减少抛单数,增加可卖数，增加库存上限
     * @param orderAndStock
     * @return
     */
    public int revocationPay(OrderAndStock orderAndStock);

    /**
     * 抛单
     * 减少已支付数量(冻结),增加抛单数量
     * 减少库存上限数量
     * @param orderAndStock
     * @return
     */
    public int castOrder(OrderAndStock orderAndStock);

    /**
     * 上架，修改上架状态
     * @param stockInfo
     * @return
     */
    public int putaway(StockInfo stockInfo);

    /**
     * 库存失效,直营。校验占用，冻结及库存上限
     * @param stockInfo
     * @return
     */
    public int invalid(StockInfo stockInfo);

    /**
     * 库存失效,非直营。校验占用，冻结
     * @param stockInfo
     * @return
     */
    public int invalidIsNotDirect(StockInfo stockInfo);

    /**
     * 通过id 查找库存信息
     * @param stockInfoId
     * @return
     */
    public StockInfo getStockInfoById(Long stockInfoId);


    /**
     * 获取MBG库存信息
     * @param stockInfo
     * @return
     */
    public List<StockInfo> getAtp(StockInfo stockInfo);

    /**
     * MBG 查询 商品编号
     * @param stockInfo
     * @return
     */
    public StockInfo getProductCode(StockInfo stockInfo);

    /**
     * MBG 修改库存
     * @param stockInfo
     * @return
     */
    public int updateProductCode(StockInfo stockInfo);

    public List<StockInfo> getStockInfoList(Map map);
    public List<StockInfo> getO2OStockInfoList(Map map);


    /**
     * 批量删除
     * @param list
     * @return
     */
    public int deleteByBatch(List<StockInfo> list);

    /**
     * 判断物料编号是否存在
     */

    public int getMaterielExist(StockInfo stockInfo);

    //只下架
    public int unPutAway(StockInfo stock);

    int updateStockInfo(@Param("stockInfo") StockInfo stockInfo, @Param("operNum") int operNum, @Param("salesNum") int salesNum);

    int addActivityStock(@Param("stockInfo") StockInfo stockInfo, @Param("activityType") int activityType, @Param("operNum") int operNum);

    /**
     * 根据商品code获取库存列表，上下架使用
     * @param productCode
     * @return
     */
    public List<StockInfo> getStockListByProductCode(@Param("productCode") String productCode, @Param("shopId") Integer shopId);

    /**
     * 懂得通信赠品占用
     * @param productCode
     * @param activityType
     * @param goodsNumber
     * @return
     */
    int waitPayTelGift(@Param("productCode") String productCode, @Param("activityType") int activityType, @Param("goodsNumber") int goodsNumber, @Param("shopId") Integer shopId);

    /**
     * 根据商品code和活动类型查询库存
     * @param productCode
     * @param activityType
     * @return
     */
    StockInfo getStockInfoByProCodeAndActType(@Param("productCode") String productCode, @Param("activityType") int activityType, @Param("shopId") Integer shopId);

    /**
     *修改通知标志
     * @param stockInfoId 主键ID
     * @param noticeFlag 通知标志
     * @return
     */
    int updateNoticeFlag(@Param("stockInfoId") long stockInfoId, @Param("noticeFlag") int noticeFlag);

    /**
     * 获取可买数
     * @param productCode
     * @param activityType
     * @return
     */
    int getStockSalesNumber1(@Param("productCode") String productCode, @Param("activityType") Integer activityType);

    /**
     * 活动结束，把活动库存加到普通库存上
     * @param salesNumber
     * @return
     */
    int revokeSaleNumToOnlineStock(@Param("salesNumber") int salesNumber, @Param("productCode") String productCode, @Param("shopId") Integer shopId, @Param("storeId") String storeId);

    /**
     * 活动结束，将活动库存释放（把活动库存清空）
     * @param salesNumber
     * @param activityType
     * @return
     */
    int releaseActivitySalesNum(@Param("salesNumber") int salesNumber, @Param("activityType") int activityType, @Param("productCode") String productCode, @Param("shopId") Integer shopId, @Param("storeId") String storeId);


    /**
     * 更新库存的商品信息，上下架，商品名称等
     * @param stockInfo
     * @return
     */
    int updateStockInfoByPK(StockInfo stockInfo);

    /**
     * 将库存置失效，is_valid 0失效  1有效
     * @param stockInfoId
     * @param operator
     * @return
     */
    int invalidStockInfo(@Param("stockInfoId") long stockInfoId, @Param("operator") String operator);


   /**
     * 批量插入库存记录
     * @param list
     * @return
     */
    int insertStockInfoBatch(List<StockInfo> list);
}
