package com.lenovo.m2.hsbuy.dao.pay.soa;

import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.PayPointRules;
import org.apache.ibatis.annotations.Param;

/**
 * Created by jh on 2017/8/10.
 */
public interface PayPointRulesMapper {

    /**
     * 获取积分可用 规则
     * @param faId
     * @return
     */
    PayPointRules getPayPointRulesByfaId(@Param("faId") String faId);
}
