package com.lenovo.m2.hsbuy.dao.throwengine;

import com.lenovo.m2.hsbuy.domain.throwengine.SmbSendSn;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author : 朝阳
 * @version : v1.0
 * @email : licy13@lenovo.com
 * @time : 2017/12/20 18:23
 */
public interface SendSmbSnMapper {


    /**
     * 保存 待 send sn
     *
     * @param smbSendSn
     * @return
     */
    int save(SmbSendSn smbSendSn);

    /**
     * 获取待send 的sn
     *
     * @param env
     * @return
     */
    List<SmbSendSn> querySmbSn(@Param("env") String env);


    /**
     * 待 send
     *
     * @param orderId
     * @return
     */
    int updatePendingStatus(@Param("orderId") Long orderId);

    /**
     * send成功
     *
     * @param smbSendSn
     * @return
     */
    int updateSuccessStatus(SmbSendSn smbSendSn);

    /**
     * send 失败
     *
     * @param smbSendSn
     * @return
     */
    int updateFailStatus(SmbSendSn smbSendSn);


    /**
     * 修改状态
     *
     * @param smbSendSn
     * @return
     */
    int updateStatus(SmbSendSn smbSendSn);

}
