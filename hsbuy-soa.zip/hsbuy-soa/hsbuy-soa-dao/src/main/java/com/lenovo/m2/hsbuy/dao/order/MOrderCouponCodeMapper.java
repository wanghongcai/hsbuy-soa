package com.lenovo.m2.hsbuy.dao.order;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderCouponCode;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by fenglg1 on 2016/2/25.
 */
public interface MOrderCouponCodeMapper extends GenericDao<MOrderCouponCode, Long> {

    List<MOrderCouponCode> getMOrderCouponCodeByOrderId(@Param("orderId") Long orderId);

    int saveMOrderCouponCode(MOrderCouponCode mOrderCouponCode);

    int saveMOrderCouponCodeList(List<MOrderCouponCode> mOrderCouponCodeList);
}
