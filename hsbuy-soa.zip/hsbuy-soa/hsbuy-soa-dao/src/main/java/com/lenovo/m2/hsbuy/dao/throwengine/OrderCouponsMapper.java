package com.lenovo.m2.hsbuy.dao.throwengine;

import com.lenovo.m2.hsbuy.domain.order.OrderCoupons;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by jiazy on 2017/6/1.
 */
@Repository("throwOrderCouponsMapper")
public interface OrderCouponsMapper {
    /**
     * 根据订单编号获取优惠码列表
     *
     * @param orderId
     * @return
     */
    List<OrderCoupons> getOrderCouponsListByOrderCode(Long orderId);
}
