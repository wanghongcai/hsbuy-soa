package com.lenovo.m2.hsbuy.dao.pay.soa;

import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.PayMailInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by mengqiang1 on 2015/12/24.
 */
public interface PayMailMapper {

    /**
     * 保存邮件信息
     * @param payMailInfo
     * @return
     */
    public Long savePayMailInfo(PayMailInfo payMailInfo);

    /**
     * 查询失败邮件
     * @param mailType
     * @return
     */
    public List<PayMailInfo> getFailedMail(@Param("mailType") int mailType);

    /**
     * 更新失败邮件
     * @param payMailInfo
     */
    public void updatePayMailState(PayMailInfo payMailInfo);
}
