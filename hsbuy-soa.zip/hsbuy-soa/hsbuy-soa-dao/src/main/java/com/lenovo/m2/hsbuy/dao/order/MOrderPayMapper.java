package com.lenovo.m2.hsbuy.dao.order;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderPay;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by fenglg1 on 2016/2/25.
 */
public interface MOrderPayMapper extends GenericDao<MOrderPay, Long> {

    MOrderPay getMOrderPayByOrderId(@Param("orderId") Long orderId);

    int saveMOrderPay(MOrderPay mOrderPay);

    int saveMOrderPayList(List<MOrderPay> mOrderPayList);
}
