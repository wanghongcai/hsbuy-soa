package com.lenovo.m2.hsbuy.dao.throwengine;


import com.lenovo.m2.hsbuy.domain.order.OrderPay;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by jiazy on 2017/6/1.
 */
@Repository("throwOrderPayMapper")
public interface OrderPayMapper {

    /**
     * 根据订单编号获取支付信息
     *
     * @param orderId
     * @return
     */
    List<OrderPay> getOrderPayListByOrderId(Long orderId);

    /**
     * 更新抛送支付状态
     *
     * @param orderPayThrow
     * @return
     */
    int updatePayInfoStatus(OrderPay orderPayThrow);
}
