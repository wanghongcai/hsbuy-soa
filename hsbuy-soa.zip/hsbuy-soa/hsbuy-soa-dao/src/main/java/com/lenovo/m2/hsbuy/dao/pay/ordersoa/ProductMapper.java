package com.lenovo.m2.hsbuy.dao.pay.ordersoa;

import com.lenovo.m2.hsbuy.domain.pay.ordersoa.wxpay.ChannelOrderProduct;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface ProductMapper {
    public int  insertProductSelective(ChannelOrderProduct record);
    public int  betchInsertProduct(List<ChannelOrderProduct> list);
    public List<ChannelOrderProduct> selectByExample(Map param);

    /**
     * 根据主单号查询商品信息
     * @param order_code
     * @return
     */
    public List<ChannelOrderProduct> selectChannelOrderProductList(@Param("order_code") String order_code);
    /**
     * 根据单号查询商品信息
     * @param param
     * @return
     */
    public List<ChannelOrderProduct> selectOrderProductListSelective(Map param);
}