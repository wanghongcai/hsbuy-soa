package com.lenovo.m2.hsbuy.dao.address;

import com.lenovo.m2.hsbuy.domain.address.HsAddress;

import java.util.List;

/**
 * Created by admin on 2017/7/25.
 * 惠商商城地址库
 */
public interface HSAddressMapper {

    /**
     * 获取所有省市县信息
     * @return
     */
    public List<HsAddress> getAll();

    /**
     * 删除数据库中三级地址信息
     * @return
     */
    public int deleteThreeLevelHSAddress();

    /**
     * 批量插入三级地址信息
     * @param list
     * @return
     */
    public int initBatchInsertThreeLevelAddress(List<HsAddress> list);
}
