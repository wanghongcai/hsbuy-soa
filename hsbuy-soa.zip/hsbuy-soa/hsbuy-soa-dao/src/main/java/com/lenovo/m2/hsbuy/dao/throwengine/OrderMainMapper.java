package com.lenovo.m2.hsbuy.dao.throwengine;


import com.lenovo.m2.hsbuy.domain.order.OrderMain;
import com.lenovo.m2.hsbuy.domain.order.OrderPay;
import com.lenovo.m2.hsbuy.domain.throwengine.OrderMainSmbThrow;
import com.lenovo.m2.hsbuy.domain.throwengine.SmbSendSn;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by jiazy on 2017/5/27.
 */
@Repository("throwOrderMainMapper")
public interface OrderMainMapper {

    /**
     * 通过订单号获取订单信息
     *
     * @param orderCode
     */
    OrderMain getOrderMainByOrderCode(Long orderCode);


    /**
     * 非SMB非惠商订单抛单列表(排除充值类订单)
     *
     * @return
     */
    List<Long> getCommonThrowOrderCodes(@Param("env") String env);

    /**
     * 非SMB非惠商订单抛单列表
     *
     * @return
     */
    List<OrderMain> getCommonThrowOrders();

    /**
     * 更新抛单状态
     *
     * @param orderMainThrow
     * @return
     */
    int updateOrderThrowStatus(OrderMain orderMainThrow);

    /**
     * 更新库存减冻结状态
     *
     * @param orderMainThrow
     */
    int updateFreezeStockStatus(OrderMain orderMainThrow);

    /**
     * 更新-更新全量库状态
     *
     * @param orderMainThrow
     * @return
     */
    int updateFullDbStatus(OrderMain orderMainThrow);

    /**
     * 更新主单的更新时间
     *
     * @param orderMainThrow
     * @return
     */
    int updateOrderUpdateTime(OrderMain orderMainThrow);

    /**
     * 更新 rule 返回结果
     *
     * @param orderMainThrow
     * @return
     */
    int updateRuleResult(OrderMain orderMainThrow);


    /**
     * 获取smb待抛单 smb单号
     *
     * @return
     */
    List<String> getSmbThrowCustomerOrderCodes(@Param("env") String env);

    /**
     * 获取smb待抛单列表，根据smb号抛单
     *
     * @return
     */
    List<OrderMainSmbThrow> getSmbThrowOrders();

    /**
     * 根据 customerOrderCode 获取待抛单信息
     *
     * @param customerOrderCode
     * @return
     */
    OrderMainSmbThrow getSmbThrowOrderByCustomerOrderCode(String customerOrderCode);


    /**
     * 根据smb 主单号获取smb子单
     *
     * @param customerOrderCode
     * @return
     */
    List<OrderMain> getSmbSonOrder(String customerOrderCode);

    /**
     * 更新smb抛单状态
     *
     * @param orderMainThrow
     * @return
     */
    int updateSmbOrderThrowStatus(OrderMain orderMainThrow);


    /**
     * 获取smb支付信息，主单号
     *
     * @return
     */
    List<Long> getSmbPayInfoOrderIds(@Param("env") String env);

    /**
     * 获取smb支付信息
     *
     * @return
     */
    List<OrderPay> getSmbPayInfo();

    /**
     * 根据主订单号获取smb支付信息
     *
     * @param orderId 主单号
     * @return
     */
    OrderPay getSmbPayInfoByOrderId(Long orderId);




    /**
     * 批量修改抛单次数为2次
     *
     * @param orderIds
     * @return
     */
    int batchUpdateThrowTimes(List<Long> orderIds);

    /**
     * 获取 sn
     * @param startTime
     * @param endTime
     * @return
     */
    List<SmbSendSn> getSmbSn(@Param("startTime") String startTime, @Param("endTime") String endTime);


    /**根据CustomerOrderCode得到抛单状态
     * @param orderMainThrow
     * @return
     */
    int getSmbThrowStatusByCustomerOrderCode(OrderMain orderMainThrow);
}
