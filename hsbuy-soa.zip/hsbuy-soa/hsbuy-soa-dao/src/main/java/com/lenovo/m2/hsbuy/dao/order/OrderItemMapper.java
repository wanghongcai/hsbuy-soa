package com.lenovo.m2.hsbuy.dao.order;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.hsbuy.domain.order.OrderItem;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * Created by fenglg1 on 2015/5/19.
 */
public interface OrderItemMapper extends GenericDao<OrderItem, Long> {

    public int saveOrderItem(OrderItem orderItem);

    public int saveOrderItemList(List<OrderItem> orderItemList);

    public List<Map<String,Object>> getItemByOrderIdAndCode(@Param("orderId")Long orderId, @Param("shopList")List<String> shopList);
}
