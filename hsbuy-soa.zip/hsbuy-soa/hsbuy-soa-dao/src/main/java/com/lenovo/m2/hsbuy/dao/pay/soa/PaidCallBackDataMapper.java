package com.lenovo.m2.hsbuy.dao.pay.soa;


import com.lenovo.m2.hsbuy.domain.pay.soa.outpay.PaidCallBackData;

import java.util.List;

/**
 * 已支付回调数据映射接口
 * Created by tianchuyang on 2017/6/2.
 */
public interface PaidCallBackDataMapper {

    /**
     *
     * @param paidCallBackData 查询参数，参数说明详见类型
     * @return
     */
    List<PaidCallBackData> getPaidCallBackDataList(PaidCallBackData paidCallBackData);

    int addPaidCallBackData(PaidCallBackData paidCallBackData);

    /**
     * 更新
     * WHERE trade_no = #{tradeNo} AND out_trade_no = #{outTradeNo}
     * @param paidCallBackData
     * @return
     */
    int updatePaidCallBackData(PaidCallBackData paidCallBackData);

    int deletePaidCallBackData(PaidCallBackData paidCallBackData);

}
