package com.lenovo.m2.hsbuy.dao.order;

import com.lenovo.m2.hsbuy.domain.order.logistics.Orderdeliveryinfoe;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 非直营物流轨迹
 * update by licy13 on 2017/4/17
 */
public interface OrderdeliveryinfoeMapper {
    /**
     * 根据物流单号删除物流轨迹
     *
     * @param id
     * @return
     */
    int deleteByLogiNo(@Param("logiNo") String id);

    /**
     * 批量插入物流轨迹信息
     *
     * @param record
     * @return
     */
    int insertOrderdeliveryinfoes(List<Orderdeliveryinfoe> record);


    /**
     * 获取需要处理的物流单号
     *
     * @return
     */
    List<String> selectFaPreHandleLogisticsNo();

    /**
     * 根据物流号获取物流轨迹
     *
     * @param logiNo
     * @return
     */
    List<Orderdeliveryinfoe> getOrderdeliveryinfoeList(String logiNo);

    /**
     * 更新物流轨迹为已读
     *
     * @param logiNo
     * @return
     */
    int updateorderdeliveryinfoeRead(String logiNo);

    /**
     * 物流轨迹更新未读状态
     *
     * @param logiNo
     * @return
     */
    int updateorderdeliveryinfoeUnRead(String logiNo);

}