package com.lenovo.m2.hsbuy.dao.hslogistics;


import com.lenovo.m2.hsbuy.domain.order.logistics.HsLogistics;

import java.util.List;

/**
 * 惠商物流信息同步
 *
 * @Author licy13
 * @Date 2017/3/13
 */

public interface HuishanglogisticsMapper {
    /**
     * 获取惠商的最旧的10条物流信息
     *
     * @return
     */
    public List<HsLogistics> getHsLogisticsInfos();

    /**
     * 批量删除操作
     *
     * @param ids
     */
    public void batchDeleteHsLogisticsInfos(List ids);

    /**
     * 批量更新物流已读状态
     *
     * @param ids
     * @return
     */
    public int batchUpdateHsLogisticsInfos(List ids);


}
