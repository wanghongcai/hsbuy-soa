package com.lenovo.m2.hsbuy.dao.pricelist;

import com.lenovo.m2.arch.framework.domain.PageModel;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.hsbuy.domain.pricelist.PriceList;
import org.apache.ibatis.annotations.Param;

import java.util.Map;

public interface PriceListMapper {
    int deleteByPrimaryKey(Long id);

    int insert(PriceList record);

    int insertSelective(PriceList record);

    PriceList selectByPrimaryKey(Long id);
    
    PriceList selectByDealNo(Map map);

    int updateByPrimaryKeySelective(PriceList record);

    int updateByPrimaryKey(PriceList record);

    /**
     * 获取报价单列表
     * @param map
     * @return
     */
    public PageModel<PriceList> getPriceListPage(PageQuery pageQuery, Map map);
    
    /**
     * 获取总条数
     * @return
     */
    public Long getCount(Map map);
    
    /**
     * 更新报价单状态为已下单
     * @return
     */
    int updateToOrdered(@Param(value = "dealNo") String dealNo, @Param(value = "userId") String userId);

    /**
     * 更新报价单状态为等待后台确认
     * @return
     */
    int updateOrderWaitToCheck(@Param(value = "dealNo") String dealNo, @Param(value = "userId") String userId);


}