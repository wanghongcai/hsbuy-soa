package com.lenovo.m2.hsbuy.dao.throwengine;

import com.lenovo.m2.hsbuy.domain.order.OrderItem;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by jiazy on 2017/6/1.
 */
@Repository("throwOrderItemMapper")
public interface OrderItemMapper {


    /**
     * 根据订单号和行号删除订单商品信息
     *
     * @param orderId
     * @param orderItemId
     * @return
     */
    int deleteOrderItemByOrderIdAndItemId(@Param("orderId") Long orderId, @Param("orderItemId") int orderItemId);

    /**
     * 根据订单号和行号获取订单商品信息
     *
     * @param orderId
     * @param orderItemId
     * @return
     */
    OrderItem getOrderItemByOrderIdAndItemId(@Param("orderId") Long orderId, @Param("orderItemId") int orderItemId);

    /**
     * 根据订单号获取商品最大行项目ID
     *
     * @param orderId
     * @return
     */
    int getMaxOrderItemId(@Param("orderId") Long orderId);

    /**
     * 保存订单商品信息
     *
     * @param orderItem
     * @return
     */
    int saveOrderItem(OrderItem orderItem);

    /**
     * 批量保存订单商品信息
     *
     * @param orderItemList
     * @return
     */
    int saveOrderItemList(List<OrderItem> orderItemList);

    /**
     * 根据订单号获取商品列表
     *
     * @param orderId
     * @return
     */
    List<OrderItem> getOrderItemsByOrderId(Long orderId);

    /**
     * 防止多次抛单，设置抛单中间状态
     *
     * @param orderId
     * @param orderItemId
     * @return
     */
    int updateMidThrowStatusByOrderIdAndItemId(@Param("orderId") Long orderId, @Param("orderItemId") int orderItemId);

    /**
     * 更新抛单状态
     *
     * @param orderItem
     * @return
     */
    int updateOrderItemThrowStatus(OrderItem orderItem);

    /**
     * 更新单个行项目 库存信息
     *
     * @param orderItem
     * @return
     */
    int updateOrderItemWarehouse(OrderItem orderItem);

    /**
     * 获取smb主品信息
     *
     * @param orderId
     * @return
     */
    List<OrderItem> getSmbMainSkuItems(Long orderId);

    /**
     * 获取smb配件信息
     *
     * @param orderId
     * @param packGroupId
     * @return
     */
    List<OrderItem> getSmbPackItems(@Param("orderId") Long orderId, @Param("packGroupId") String packGroupId);

    /**
     * 手动调用，请勿使用
     * @param orderItem
     * @return
     */
    int updateOrderItemProductsName(OrderItem orderItem);

}
