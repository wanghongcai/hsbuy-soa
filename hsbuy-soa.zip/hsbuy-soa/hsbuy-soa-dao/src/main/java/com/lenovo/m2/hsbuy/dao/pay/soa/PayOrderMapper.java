package com.lenovo.m2.hsbuy.dao.pay.soa;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.arch.framework.domain.PageModel;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by caoxd2 on 2015/4/29.
 */
public interface PayOrderMapper extends GenericDao<PayOrder,Long> {
    public Long add(PayOrder payOrder);

    public Long getExistedPayOrder(PayOrder payOrder);

    public void updateOrderPayState(@Param("orderCode") String orderCode, @Param("wxPayCode") String wxPayCode, @Param("userId") String userId, @Param("merchantFlag") int merchantFlag, @Param("tradeState") int tradeState, @Param("payType") int payType);

    public void updateMerchantNotifyState(@Param("orderCode") String orderCode, @Param("userId") String userId, @Param("transactionId") String transactionId, @Param("merchantFlag") int merchantFlag);

    public void updateAliPayNotifyState(@Param("orderCode") String orderCode, @Param("userId") String userId, @Param("transactionId") String transactionId, @Param("merchantFlag") int merchantFlag, @Param("notifyId") String notifyId, @Param("tradeState") int tradeState, @Param("bankSeqNo") String bankSeqNo, @Param("payType") int payType);

    public PayOrder getPayOrderDetail(@Param("orderCode") String orderCode, @Param("userId") String userId, @Param("transactionId") String transactionId);

    public void updateAliIphonePayNotifyState(@Param("orderCode") String orderCode, @Param("transactionId") String transactionId, @Param("merchantFlag") int merchantFlag, @Param("notifyId") String notifyId, @Param("tradeState") int tradeState, @Param("bankSeqNo") String bankSeqNo, @Param("payType") int payType);

    public int getPayOrderByOutTradeNo(@Param("orderCode") String orderCode);

    public List<PayOrder> getOrderStatus(@Param("orderCode") String orderCode, @Param("userId") String userId);

    public PayOrder getTwoStatus(@Param("orderCode") String orderCode);

    public PayOrder getPayOrderById(@Param("orderCode") String orderCode);

    public Map<String,Object> getRefundInfo(@Param("orderCode") String orderCode);

    public PayOrder getPayOrderByPrimaryId(@Param("payOrderId") long payOrderId);

    public List<PayOrder> getStatusByOrderCode(@Param("orderCode") String orderCode);

    public List<PayOrder> getOrderListByOrderCode(@Param("orderCode") String orderCode);

    /**
     * 按条件查询
     * @param param
     * @return
     */
    public List<PayOrder> getPayOrderByConf(Map param);

    public List<PayOrder> getOrderListByPayType(@Param("orderCode") String ordercode, @Param("payType") Integer payType);

    public int updatePayBankByID(@Param("id") String keyId, @Param("payBank") String defaultbank, @Param("feeType") Integer feeType);

    public void updateFqInfo(@Param("id") String id, @Param("fqNum") String hbfqNum, @Param("fqRate") String fqRate, @Param("fqCode") String fqRatePro, @Param("plat") String plat, @Param("shopId") String shopId, @Param("terminal") String terminal);

    public PayOrder getPayOrderByTradeState(@Param("orderMainCode") String orderMainCode, @Param("tradeState") int tradeState);

    //支付流水分页查询
    public PageModel<PayOrder> getPayOrderPage(PageQuery pageQuery, Map map);

    public PayOrder getPayOrderByTransactionId(@Param("transactionId") String transactionId);

    /**
     * 招商银行更新商家状态接口
     * @param orderCode
     * @param userId
     * @param transactionId
     * @param merchantFlag
     * @param notifyId
     * @param tradeState
     * @param bankSeqNo
     * @param payType
     * @param trade_state
     * @return
     */
    public Integer updateCmbPayNotifyState(@Param("orderCode") String orderCode, @Param("userId") String userId, @Param("transactionId") String transactionId, @Param("merchantFlag") int merchantFlag, @Param("notifyId") String notifyId, @Param("tradeState") int tradeState, @Param("bankSeqNo") String bankSeqNo, @Param("payType") int payType, @Param("trade_state") int trade_state);

    /**
     * 平安银行更新商家状态接口
     * @param orderCode
     * @param userId
     * @param transactionId
     * @param merchantFlag
     * @param tradeState
     * @param payType
     * @return
     */
    public Integer updatePingAnPayNotifyState(@Param("orderCode") String orderCode, @Param("userId") String userId, @Param("transactionId") String transactionId, @Param("merchantFlag") int merchantFlag, @Param("tradeState") int tradeState, @Param("payType") int payType);
    public void updatePayOrderShopIdTerminal(@Param("id") String id, @Param("plat") String plat, @Param("shopId") String shopId, @Param("terminal") String terminal);

    /**
     * 更新CreateTime
     * @param orderPrimaryId
     * @param lenovoId
     * @param createTime
     * @return
     */
    public Integer updatePayOrderCreateTime(@Param("orderPrimaryId") String orderPrimaryId, @Param("lenovoId") String lenovoId, @Param("createTime") Date createTime);

    /**
     * 获取支付流水列表
     * @param outTradeNo
     * @param tradeState
     * @return
     */
    public List<PayOrder> getPayOrderListByTradeState(@Param("outTradeNo") String outTradeNo, @Param("tradeState") int tradeState);

    @Override
    PageModel<PayOrder> getAll(PageQuery pageQuery);

    @Override
    PayOrder get(Long aLong);

    @Override
    boolean exists(Long aLong);

    @Override
    int remove(Long aLong);

    @Override
    Long insert(PayOrder payOrder);

    @Override
    int update(PayOrder payOrder);

}
