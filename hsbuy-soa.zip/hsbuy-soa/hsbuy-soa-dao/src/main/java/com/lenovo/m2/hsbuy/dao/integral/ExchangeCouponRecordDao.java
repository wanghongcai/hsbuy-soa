package com.lenovo.m2.hsbuy.dao.integral;

import com.lenovo.m2.arch.framework.domain.PageModel;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.hsbuy.domain.integral.ExchangeCouponRecord;

/**
 * Created by admin on 2017/2/24.
 */
public interface ExchangeCouponRecordDao {

    public int addExchangeRecord(ExchangeCouponRecord exchangeCouponRecord);

    public int deleteExchangeRecord(String uuid);

    public ExchangeCouponRecord getExchangeRecord(String uuid);

    public PageModel<ExchangeCouponRecord> getExchangeRecordByPage(PageQuery pageQuery, ExchangeCouponRecord exchangeCouponRecord);

}
