package com.lenovo.m2.hsbuy.dao.order;

import com.lenovo.m2.hsbuy.domain.order.logistics.OrderLogistics;
import com.lenovo.m2.hsbuy.domain.order.logistics.OrderLogisticsInfo;
import com.lenovo.m2.hsbuy.domain.ordercenter.LogisticsPlatform;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 订单物流关系
 *
 * @Author licy13
 * @Date 2017/3/8
 */

public interface OrderLogisticsMapper {
    /**
     * 批量插入订单物流关系
     *
     * @param logisticsList
     * @return
     */
    long insertOrderLogistics(List<OrderLogistics> logisticsList);

    /**
     * 获取已发货的物流信息（30天前）
     *
     * @return
     */
    List<OrderLogistics> getUnreceiptedOrder();

    /**
     * 根据订单编号和物流单号获取获取订单和物流关系
     *
     * @param orderId
     * @param logisticsNo
     * @return
     */
    OrderLogistics getOrderLogisticsByOrderIdAndLogisticsNo(@Param("orderId") long orderId, @Param("logisticsNo") String logisticsNo);

    /**
     * 根据物流单号获取订单和物流关系列表
     * （物流单号和订单多对多的关系）
     *
     * @param logisticsNo
     * @return
     */
    List<OrderLogistics> getOrderLogisticsByLogisticsNo(@Param("logisticsNo") String logisticsNo);

    /**
     * 根据订单号获取订单和物流关系列表
     *
     * @param orderId
     * @return
     */
    List<OrderLogistics> getOrderLogisticsByOrderId(@Param("orderId") String orderId);

    List<com.lenovo.m2.hsbuy.domain.ordercenter.OrderLogistics> getOrderLogisticsByOrderCenter(@Param("orderId") String orderId);


    /**
     * 插入直营物流轨迹
     *
     * @param logisticsInfoList
     * @return
     */
    public int insertOrderLogisticsInfo(List<OrderLogisticsInfo> logisticsInfoList);

    /**
     * 查重
     *
     * @param orderLogisticsInfo
     * @return
     */
    public int countOrderLogistics(OrderLogisticsInfo orderLogisticsInfo);

    List<com.lenovo.m2.hsbuy.domain.ordercenter.OrderLogistics> getOrderLogistics(@Param("orderId") String orderId);


    /**
     * 根据code 查询物流信息
     *
     * @param code
     * @return
     */
    String getLogisticsName(@Param("code") String code);


    /**
     * 物流公司
     *
     * @return
     */
    List<LogisticsPlatform> getLogiInfo();
}



