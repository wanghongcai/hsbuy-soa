package com.lenovo.m2.hsbuy.dao.ordercenter;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.arch.framework.domain.PageModel;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.hsbuy.domain.order.OrderMain;
import com.lenovo.m2.hsbuy.domain.ordercenter.HSReportVo;
import org.apache.ibatis.annotations.Param;

import java.util.Map;

/**
 * Created by Administrator on 2017-12-21.
 */
public interface OrderQueryMapper extends GenericDao<OrderMain, Long> {
    /**
     * 惠商订单报表 查询分页
     * @param pageQuery
     * @param map
     * @return
     */
    PageModel<HSReportVo> getHSOrderReportlist(PageQuery pageQuery, @Param("conditions") Map<String, Object> map);

    /**
     * 惠商平安对账
     * @param pageQuery
     * @param map
     * @return
     */
    PageModel<OrderMain> getHSOrderReconciliationList(PageQuery pageQuery, @Param("conditions") Map<String,Object> map);

}
