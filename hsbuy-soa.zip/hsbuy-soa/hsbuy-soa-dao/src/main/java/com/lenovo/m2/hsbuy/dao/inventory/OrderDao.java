package com.lenovo.m2.hsbuy.dao.inventory;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.arch.framework.domain.PageModel;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.hsbuy.domain.inventory.MainAndSubOrder;
import com.lenovo.m2.hsbuy.domain.inventory.OrderAndStock;
import com.lenovo.m2.hsbuy.domain.inventory.OrderInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * Created by zhangzhen10 on 15-6-30.
 */
public interface OrderDao extends GenericDao<OrderInfo, Long> {


    /**
     * 增加新订单,第一次请求占用
     *
     * @param orderInfo
     * @return
     */
    public int insertOrderInfo(OrderInfo orderInfo);

    /**
     * 根据订单id更新订单号码，第一次请求占用后，使订单生效
     * @param orderId
     * @param orderCode
     * @return
     */
    public int updateOrderCode(@Param("orderId") long orderId, @Param("orderCode") String orderCode, @Param("shopId") Integer shopId);

    /**
     * 修改订单状态，根据订单id
     * @param orderId
     * @param fromOrderState
     * @param toOrderState
     * @return
     */
    public int updateOrderStateById(@Param("orderId") long orderId, @Param("fromOrderState") int fromOrderState, @Param("toOrderState") int toOrderState);

    /**
     * 修改订单状态，根据订单code
     * @param orderCode
     * @param fromOrderState
     * @param toOrderState
     * @return
     */
    public int updateOrderStateByCode(@Param("orderCode") String orderCode, @Param("shopId") Integer shopId, @Param("fromOrderState") int fromOrderState, @Param("toOrderState") int toOrderState);

    /**
     *
     * @param pageQuery
     * @param map stock_info_id 库存id，必输
     *            order_state 订单状态，非必输.1--待支付;2--已支付
     * @return
     */
    public PageModel<OrderAndStock> getOrderInfoPage(PageQuery pageQuery, Map map);

    /**
     * 订单信息查询
     *
     * @param orderId
     * @return
     */
    public OrderInfo getOrderInfoById(@Param("orderId") long orderId);

    /**
     * 订单信息查询
     *
     * @param orderCode
     * @return
     */
    public OrderInfo getOrderInfoByCode(@Param("orderCode") String orderCode, @Param("shopId") Integer shopId);

    public List<OrderAndStock> getStockAndOrderByCode(@Param("orderCode") String orderCode, @Param("shopId") Integer shopId);

    public int insertMainOrderAndSubOrder(@Param("mOrderInfoId") long mOrderInfoId, @Param("sOrderInfoId") long sOrderInfoId, @Param("shopId") Integer shopId);

    /**
     * 根据子订单id查询
     * @param sOrderInfoId
     * @return
     */
    MainAndSubOrder getMainAndSubOrderBySubOrderId(@Param("sOrderInfoId") long sOrderInfoId, @Param("shopId") Integer shopId);

    int updateMainAndSubOrder(@Param("mainAndSubOrder") MainAndSubOrder mainAndSubOrder, @Param("shopId") Integer shopId);
}
