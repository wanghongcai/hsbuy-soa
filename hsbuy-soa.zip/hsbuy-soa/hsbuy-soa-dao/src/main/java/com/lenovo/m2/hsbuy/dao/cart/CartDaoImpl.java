package com.lenovo.m2.hsbuy.dao.cart;

import com.lenovo.m2.hsbuy.common.util.CustomizedPropertyConfigurer;
import com.lenovo.m2.hsbuy.common.util.JsonUtil;
import com.lenovo.m2.hsbuy.common.util.RedisKeyUtil;
import com.lenovo.m2.hsbuy.domain.cart.CartEntry;
import com.lenovo.m2.hsbuy.domain.cart.CartNG;
import com.lenovo.m2.hsbuy.redis.MyRedisConn;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by jack on 2016/1/22.
 */
@Repository
public class CartDaoImpl implements CartDao {

    @Resource(name = "sentryRedisConn")
    private MyRedisConn redisConn;
	private static Logger log = LogManager.getLogger(CartDaoImpl.class.getName());

    @Override
	public void addOrUpdateItem(String cartkey, CartEntry entry){
    	Assert.notNull(cartkey);
    	String field = entry.getStoreField();
//    	获取购物车单行数量限制
    	int limit = getCartRowLimit(entry.getShopid());
    	if(entry.getNum() > limit){
    		entry.setNum(limit);
    	}
        log.info("商品放入购物车,cartEntity={}", JsonUtil.toJson(entry));
    	redisConn.hset(cartkey, field, JsonUtil.toJson(entry));
    }
    
    /**
	 * 获取购物车单行数量限制
	 * @param shopId
	 * @return
	 */
	private int getCartRowLimit(int shopId){

		String value = CustomizedPropertyConfigurer.getContextProperty(String.format("cart_entry_num_limit_%s", shopId));
		if(StringUtils.isEmpty(value)){
			value = CustomizedPropertyConfigurer.getContextProperty("cart_entry_num_limit_default");
		}
		if(StringUtils.isEmpty(value)){
			throw new RuntimeException("配置错误");
		}
		return Integer.parseInt(value);

	}
    

    @Override
    public boolean delAllCart(String userCartKey) {
        boolean flag = false;
        long lon = redisConn.del(userCartKey);
        if (1 == lon || 0 == lon){
            flag = true;
        }
        return flag;
    }

    @Override
    public List<CartEntry> getCart(String userCartKey, boolean check) {
    	List<CartEntry> sortedEntries = new ArrayList<CartEntry>();

        Map<String, String> map = redisConn.hgetAll(userCartKey);
        if(map == null || map.size() == 0){
            return sortedEntries;
        }
		for (Map.Entry<String,String> entry : map.entrySet()){
        	String key = entry.getKey();
        	String val = entry.getValue();
        	
        	CartEntry redisEntry = JsonUtil.fromJson(val, CartEntry.class);
        	if(redisEntry == null){
        		log.warn("cart entry null, key={}, field={}, val={}", new Object[]{userCartKey, key, val});
        		redisConn.hdel(userCartKey, key);//转换失败，删除
        		continue;
        	}
            if (check){
                if (redisEntry.getCheck() == 1){
                    sortedEntries.add(redisEntry);
                }
            }else {
                sortedEntries.add(redisEntry);
            }
        }
        return sortedEntries;
    }

    @Override
    public Map<String, CartEntry> getCartMap(String cartkey, boolean check) {
    	Map<String,CartEntry> ret = new HashMap<>();

        Map<String, String> map = redisConn.hgetAll(cartkey);
        if(map == null || map.size() == 0){
            return ret;
        }
        
        for (Map.Entry<String,String> entry : map.entrySet()){
        	String key = entry.getKey();
        	String val = entry.getValue();
        	CartEntry redisEntry = JsonUtil.fromJson(val, CartEntry.class);
        	if(redisEntry == null){
        		log.warn("cart entry null, key={}, field={}, val={}", new Object[]{cartkey, key, val});
        		redisConn.hdel(cartkey, key);
        		continue;
        	}
        	ret.put(key, redisEntry);
        }
        return ret;
    }


	@Override
	public boolean delItem(String cartkey, String itemid) {
		long r = redisConn.hdel(cartkey, itemid);
		return r > 0;
	}

	@Override
	public CartEntry getCartEntry(String cartkey, String itemid) {
		String json = redisConn.hget(cartkey, itemid);
    	if(StringUtils.isEmpty(json)){
    		return null;
    	}else{
    		return JsonUtil.fromJson(json, CartEntry.class);
    	}
	}

	@Override
	public List<CartEntry> getCartEntrys(String cartkey, String... itemid) {
		List<CartEntry> ret = new ArrayList<>(itemid.length);
		List<String> entries = redisConn.hmget(cartkey, itemid);
		for(String entry: entries){
			if(entry == null){
				continue;
			}
			CartEntry redisEntry = JsonUtil.fromJson(entry, CartEntry.class);
			if(redisEntry != null){
				ret.add(redisEntry);
			}
		}
		return ret;
	}

	@Override
	public boolean delItem(String cartkey, CartEntry entry) {
    	String field = entry.getStoreField();
    	redisConn.hdel(cartkey, field);
    	return true;
	}

	@Override
	public boolean delItems(String cartkey, String... fields) {
		redisConn.hdel(cartkey, fields);
		return true;
	}

	@Override
	public void addOrUpdateItems(String cartkey, List<CartEntry> entries) {
		if(CollectionUtils.isEmpty(entries)){
			return;
		}
		Map<String,String> values = new HashMap<>();
		for(CartEntry entry: entries){
			Assert.notNull(entry);
			String field = entry.getId();
			values.put(field, JsonUtil.toJson(entry));
		}
    	redisConn.hmset(cartkey, values);
	}

	@Override
	public void addTempItem(String cartkey, CartEntry entry) {
		Assert.notNull(cartkey);
    	String field = entry.getStoreField();
    	redisConn.hset(cartkey, field, JsonUtil.toJson(entry));
    	redisConn.expire(cartkey, 60 * 60); 
	}


    @Override
	public CartNG getPriceListCart(String key){
        String json = redisConn.get(key);
        //if(StringUtil.isEmpty(json)){
        //    return null;
        //}
        return JsonUtil.fromJson(json, CartNG.class);
    }


    @Override
	public boolean delPriceListCart(String key){
        redisConn.del(key);
        return true;
    }

	@Override
	public void addPriceListCart(String key, CartNG cartNG) {
		Assert.notNull(key);
		redisConn.set(key,JsonUtil.toJson(cartNG));
	}

	@Override
	public long pushDealNo(int shopid, String dealNo) {
		String key = RedisKeyUtil.getOrderedDealNo(shopid);
		return redisConn.rpush(key, dealNo);
	}

	@Override
	public long cartSize(String key) {
		return redisConn.hlen(key);
	}

	@Override
	public int getRowNumLimit(Integer shopId) {
		return getCartRowLimit(shopId);
	}


}


