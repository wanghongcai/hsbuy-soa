package com.lenovo.m2.hsbuy.dao.order;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.hsbuy.domain.order.OrderCouponCode;

import java.util.List;

/**
 * Created by fenglg1 on 2015/6/9.
 */
public interface OrderCouponCodeMapper extends GenericDao<OrderCouponCode, Long> {

    public int saveOrderCouponCode(OrderCouponCode orderCouponCode);

    public int saveOrderCouponCodeList(List<OrderCouponCode> orderCouponCodeList);

}

