package com.lenovo.m2.hsbuy.mongo.impl;

import com.lenovo.m2.hsbuy.common.pruchase.util.MongoBeanUtil;
import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrderDetail;
import com.lenovo.m2.hsbuy.domain.ordercenter.OrderMainConstant;
import com.lenovo.m2.hsbuy.mongo.BaseMongoDao;
import com.mongodb.*;
import com.mongodb.util.JSON;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Created by fenglg1 on 2015/5/21.
 */
@Repository("baseMongoDao")
@SuppressWarnings("unchecked")
public class BaseMongoDaoImpl<T> implements BaseMongoDao<T> {
    private static Logger logger = LogManager.getLogger(BaseMongoDaoImpl.class.getName());

    /**
     * 泛型Class实例
     */
    protected Class entityClass;



    /**
     * 无参构造
     * 初始化entityClass
     */
    public BaseMongoDaoImpl() {
        entityClass = (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
    }

    /**
     * mongo模板
     */
    @Resource
    protected MongoTemplate mongoTemplate;



    public void findlike(String field , String regex){
        DBCollection dbc = this.getMCollection();
        Pattern pattern= Pattern.compile("^.*" + regex + ".*$");
    }

    /**
     * 获取数据库
     * @return
     */
    public DB getMDB(){
        return this.mongoTemplate.getDb();
    }

    /**
     * 根据实体获取Collection
     * @return
     */
    public DBCollection getMCollection(){
        System.out.println(entityClass.getSimpleName().toLowerCase());
        return getMDB().getCollection(entityClass.getSimpleName().toLowerCase());
    }

    public DBCollection getMCollection(String collectionName){
        return getMDB().getCollection(collectionName);
    }


    @Override
    public String insert(String entity) {
        DBObject obj = (DBObject) JSON.parse(entity);
        String pk = obj.get("id").toString();
        if(pk!=null){
            obj.put("_id", pk);
        }
        WriteResult wr = this.getMCollection().insert(obj);
        return obj.get("_id").toString();
    }

    @Override
    public int insertN(String entity) {
        DBObject obj = (DBObject) JSON.parse(entity);
        String pk = obj.get("id").toString();
        if(pk!=null){
            obj.put("_id", pk);
            obj.removeField("id");
        }
        WriteResult wr = this.getMCollection().insert(obj);
        return wr.getN();
    }

    @Override
    public int insertObj(String entity) {
        DBObject obj = (DBObject) JSON.parse(entity);
        WriteResult wr = this.getMCollection().insert(obj);
        return wr.getN();
    }

    @Override
    public T findOne(String id) {
        return (T) this.mongoTemplate.findById(id, entityClass);
    }

    @Override
    public List<T> findAll() {
        Query query = new Query();
        Criteria criteria = new Criteria();
        criteria.regex("");
        query.addCriteria(criteria);
//		this.mongoTemplate.find(query, entityClass)
        return this.mongoTemplate.findAll(entityClass);
    }

    @Override
    public void removeOne(String id) {
        Query query =new Query();
        query.addCriteria(Criteria.where("_id").is(id));
        this.mongoTemplate.remove(query, entityClass);

    }

    @Override
    public void removeAll() {
        this.getMCollection().drop();
    }



    @Override
    public void findAndModify(String id,String entity) {
        DBObject obj = new BasicDBObject();
        obj.put("_id", id);
        this.getMCollection().findAndModify(obj, (DBObject) JSON.parse(entity));
    }

    @Override
    public List<MongoOrderDetail> getOrderMessageByOrderMainCode(String orderMainCode, String lenovoId, String merchantId) {

        BasicDBObjectBuilder start = BasicDBObjectBuilder.start();
        if (orderMainCode != null) {
            start = start.add("orderMainCode", orderMainCode);
        }
        DBObject ref = start.get();
        ref.put("shopId",merchantId);
        ref.put("lenovoId",lenovoId);
        ref.put("activeStatus", OrderMainConstant.IS_ACTIVE_STATUS);
        DBCursor cur = getMCollection().find(ref);
        List<MongoOrderDetail> list = new ArrayList<>();
        while (cur.hasNext()) {
            DBObject dbObject = (DBObject) cur.next();
            MongoOrderDetail mongoOrder = MongoBeanUtil.handle(dbObject,MongoOrderDetail.class,new MongoOrderDetail());
            list.add(mongoOrder);
        }
        return list;

    }
}
