package com.lenovo.m2.hsbuy.dao.pay.soa.base;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.arch.framework.domain.PageModel;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.FakeRule;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.MerchantPayPlat;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.OrderSupportPayType;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * Created by chenww3 on 2015/4/17.
 */
public interface MerchantPlatMapper extends GenericDao<MerchantPayPlat,Long> {

    @Override
    public MerchantPayPlat get(Long id);
    @Override
    public PageModel<MerchantPayPlat> getAll(PageQuery pageQuery);
    @Override
    public Long insert(MerchantPayPlat merchantPayPlat);
//    public void update(MerchantInfo merchantInfo);
//    public void remove(Long userId);

    /**
     * 根据商户编码和支付方式获取商户所属的第三方支付的具体信息
     * @param merchantId 商户编码
     * @param payType 支付方式
     * @return
     */
    public MerchantPayPlat getMerchantPayPlatByMerchantId(@Param("merchantId") String merchantId, @Param("payType") int payType);

    /**
     * 根据商户编码和支付方式和业务类型获取商户所属的第三方支付的具体信息
     * @param merchantId
     * @param payType
     * @param accountType
     * @return
     */
    public MerchantPayPlat getMerchantPayPlatByAccountType(@Param("merchantId") String merchantId, @Param("payType") int payType, @Param("accountType") Integer accountType);
    /**
     * 根据商户编码和支付方式获取商户所属的第三方支付的具体信息
     * @param merchantId 商户编码
     * @param payType 支付方式
     * @return
     */
    public MerchantPayPlat getMerchantPayPlatByMechId(@Param("mechId") String merchantId, @Param("payType") int
            payType);

    /**
     *
     * @param merchantId
     * @return
     */
    public  Map<String,Object> getMerchantInfoById(@Param("merchantId") int merchantId);

    /**
     *
     * @param merchId
     * @return
     */
    public MerchantPayPlat getMerchantPayPlatByMerchId(@Param("merchId") String merchId);

    public List<MerchantPayPlat> getMerchantPayPlatsByMerchantId(@Param("merchantId") String merchId);

    /**
     * Create For Cashier
     * @param FAID
     * @return
     */
    public List<OrderSupportPayType> getOrderSupportPayTypeList(@Param("merchantId") String FAID);
    /**
     * 获取MerchantPayPlat
     * @return
     */
    public List<MerchantPayPlat> getMerchantList();


    /**
     * 条件查询分页
     * @param pageQuery
     * @param map
     * @return
     */
    public PageModel<MerchantPayPlat> getPayPlatPage(PageQuery pageQuery, Map map);

    /**
     * 选择性插入
     * @param mpp
     * @return
     */
    public Integer insertSelective(MerchantPayPlat mpp);

     int updateMerchantPayPlatById(MerchantPayPlat merchantPayPlat);

    /**
     * 选择性修改
     * @param map
     * @return
     */
    public Integer updateSelective(Map map);

    /**
     * 批量删除
     * @param map
     * @return
     */
    public Integer delsome(Map map);

    /**
     * 查询所有FA信息
     * @return
     */
    public List<FakeRule> getMerchantPayPlatByGroupBy();

    public List<OrderSupportPayType> getOrderSupportPayTypeListByFaIDPayment(@Param("merchantId") String faId, @Param("payTypeList") List<Integer> payTypeList);

    public MerchantPayPlat getMerchantPayPlatForWeChat(@Param("merchantId") String merchantId, @Param("payType") int payType, @Param("shopId") String shopId);
}
