package com.lenovo.m2.hsbuy.dao.order;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.hsbuy.domain.order.OrderInvoice;

import java.util.List;

/**
 * Created by fenglg1 on 2015/5/18.
 */
public interface OrderInvoiceMapper extends GenericDao<OrderInvoice, Long> {

    public int saveOrderInvoice(OrderInvoice orderInvoice);

    public int saveOrderInvoiceList(List<OrderInvoice> orderInvoiceList);
}
