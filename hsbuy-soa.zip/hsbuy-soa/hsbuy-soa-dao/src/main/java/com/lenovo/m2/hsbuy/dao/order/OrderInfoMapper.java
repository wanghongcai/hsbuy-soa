package com.lenovo.m2.hsbuy.dao.order;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.hsbuy.domain.order.orderInfo.OrderInfo;

import java.util.List;
import java.util.Map;

/**
 * Created by fenglg1 on 2015/5/19.
 */
public interface OrderInfoMapper extends GenericDao<OrderInfo, Long> {

    public List<OrderInfo> getOrderInfoByStatus(Map paramMap);

    public int updateOrderInfoStatus(Map paramMap);

    public OrderInfo getOrderInfoByOrderId(Long orderId);
}