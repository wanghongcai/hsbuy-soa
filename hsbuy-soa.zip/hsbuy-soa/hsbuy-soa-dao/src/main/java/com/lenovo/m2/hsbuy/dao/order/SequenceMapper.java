package com.lenovo.m2.hsbuy.dao.order;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.hsbuy.domain.order.sequence.Sequence;
import org.apache.ibatis.annotations.Param;

/**
 *  Created by zhaocl1 on 2016/8/2.
 */
public interface SequenceMapper extends GenericDao<Sequence, String> {

    int getCurrval(@Param("seq_name") String seq_name);

    int getNextval(@Param("seq_name") String seq_name);

    int setval(@Param("seq_name") String seq_name, @Param("value") int value);

}
