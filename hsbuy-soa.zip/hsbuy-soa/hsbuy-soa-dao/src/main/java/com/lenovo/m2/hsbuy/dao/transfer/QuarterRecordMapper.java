package com.lenovo.m2.hsbuy.dao.transfer;


import com.lenovo.m2.hsbuy.domain.transfer.QuarterRecord;

public interface QuarterRecordMapper {

    /**
     * 插入经销商积分奖励季度记录信息
     *
     * @param record
     * @return
     */
    int insert(QuarterRecord record);


    /**
     * 根据 经销商、年份、季度查询 积分奖励季度记录
     *
     * @param quarterRecord
     * @return
     */
    QuarterRecord selectByLenovoIdAndYearAndQuarter(QuarterRecord quarterRecord);


    /**
     * 根据Id 更新 实际奖励商品总数量
     *
     * @param record
     * @return
     */
    int updateById(QuarterRecord record);
}