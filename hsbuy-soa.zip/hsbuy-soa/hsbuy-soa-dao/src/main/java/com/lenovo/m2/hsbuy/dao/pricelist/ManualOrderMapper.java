package com.lenovo.m2.hsbuy.dao.pricelist;


import com.lenovo.m2.hsbuy.domain.pricelist.ManualOrder;

public interface ManualOrderMapper {
    int deleteByPrimaryKey(Long id);

    int insert(ManualOrder record);

    int insertSelective(ManualOrder record);

    ManualOrder selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(ManualOrder record);

    int updateByPrimaryKey(ManualOrder record);
}