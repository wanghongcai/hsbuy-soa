package com.lenovo.m2.hsbuy.dao.pay.soa.base;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.arch.framework.domain.PageModel;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.MerchantInfo;

/**
 * Created by chenww3 on 2015/4/17.
 */
public interface MerchantMapper extends GenericDao<MerchantInfo,Long> {

    public MerchantInfo get(Long id);
    public PageModel<MerchantInfo> getAll(PageQuery pageQuery);
    public Long insert(MerchantInfo merchantInfo);
    public int update(MerchantInfo merchantInfo);
    public int remove(Long userId);

}
