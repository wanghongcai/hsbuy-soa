package com.lenovo.m2.hsbuy.dao.middleware;

import com.lenovo.m2.hsbuy.common.util.DateUtil;
import com.lenovo.m2.hsbuy.domain.middleware.PayAccount;
import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrder;
import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrderDetail;
import com.lenovo.m2.hsbuy.domain.order.mongo.OrderFewInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * 订单在mongoDB中的数据操作
 *
 * @author : 朝阳
 * @version : v1.0
 * @email : licy13@lenovo.com
 * @time : 2017/11/20 14:38
 */
@Repository
public class MongoDao {


    @Autowired
    private MongoTemplate mongoTemplate;

    /**
     * 通过订单编号取订单信息（含子类信息）
     *
     * @param orderCode
     * @author zhangzhen
     */
    public MongoOrder getOrderByOrderCode(String orderCode, String lenovoId, int shopId) {
        try {
            return mongoTemplate.findOne(new Query(Criteria.where("orderCode").is(orderCode).and("lenovoId").is(lenovoId).and("amountMoney").gt("0.00").and("activeStatus").is("1")), MongoOrder.class);
        } catch(Exception e) {
            return null;
        }
    }


    public MongoOrderDetail getOrderByOrderCode(String orderCode, int shopId) {
        try {
            return mongoTemplate.findOne(new Query(Criteria.where("orderCode").is(orderCode).and("activeStatus").is("1")), MongoOrderDetail.class);
        } catch(Exception e) {
            return null;
        }
    }

    public MongoOrderDetail getOrderDetailByOrderCode(String orderCode, int shopId) {
        try {
            return mongoTemplate.findOne(new Query(Criteria.where("orderCode").is(orderCode).and("activeStatus").is("1")), MongoOrderDetail.class);
        } catch(Exception e) {
            return null;
        }
    }

    /**
     * 根据主单号 取一条订单信息（smb 订单根据主单进行取消）
     *
     * @param orderMainCode
     * @param shopId
     * @return
     */
    public MongoOrder getOrderByOrderMainCode(String orderMainCode, int shopId) {
        try {
            return mongoTemplate.findOne(new Query(Criteria.where("orderMainCode").is(orderMainCode).and("activeStatus").is("1")), MongoOrder.class);
        } catch(Exception e) {
            return null;
        }
    }

    public List<OrderFewInfo> getPayOrderInfoByOrderMainCode(String lenovoId, String orderMainCode, int shopId) {
        Query query = new Query();
        query.addCriteria(new Criteria("orderMainCode").is(orderMainCode).and("lenovoId").is(lenovoId));
        try {
            return mongoTemplate.find(query, OrderFewInfo.class);
        } catch(Exception e) {
            return null;
        }
    }
    public OrderFewInfo getPayOrderInfo(String lenovoId, String orderCode, int shopId) {
        Query query = new Query();
        query.addCriteria(new Criteria("orderCode").is(orderCode).and("lenovoId").is(lenovoId));
        try {
            return mongoTemplate.findOne(query, OrderFewInfo.class);
        } catch(Exception e) {
            return null;
        }
    }

    /**
     * 根据主单号获取 所有子单信息
     *
     * @param orderMainCode
     * @param shopId
     * @return
     */
    public List<MongoOrder> getOrdersByOrderMainCode(String orderMainCode, int shopId) {
        try {
            return mongoTemplate.find(new Query(Criteria.where("orderMainCode").is(orderMainCode).and("activeStatus").is("1")), MongoOrder.class);
        } catch(Exception e) {
            return null;
        }
    }


    public int updateMongoOrderPayCount(MongoOrder order, PayAccount payAccount, int shopId) {
        Query query = new Query();
        query.addCriteria(new Criteria("orderCode").is(order.getOrderCode()).and("activeStatus").is("1"));
        Update update = new Update();

        if (order.getPay() == null) {
            List<PayAccount> pay = new ArrayList<PayAccount>();
            pay.add(payAccount);
            update.set("pay", pay);// 更新数组, 这么做是为了防止pay为null
        } else {
            update.addToSet("pay", payAccount);//有则不插入，没有则插入
        }

        //添加惠商新字段 支付积分
        update.set("payCash", payAccount.getTotalPay()); //现金支付
        update.set("payPoint", payAccount.getPayPoint() == null ? "0" : payAccount.getPayPoint());//积分支付

        update.set("payStatus", "3".equals(payAccount.getPayStatus()) ? "1" : payAccount.getPayStatus());//3--支付尾款，转换为1--已支付
        update.set("payDatetime", payAccount.getPaidTime());
        update.set("payOrderNo", payAccount.getBankTraceNo());
        update.set("updatetime", DateUtil.getCurrentDateTimeDefaultFormat());
        update.set("orderStatus", "2");

        try {
            return mongoTemplate.updateFirst(query, update, MongoOrder.class).getN();
        } catch(Exception e) {
            return -9999;
        }
    }

    public int updateMongoOrder(String orderCode, String field, Object parameter, int shopId) {
        Query query = new Query();
        query.addCriteria(new Criteria("orderCode").is(orderCode).and("activeStatus").is("1"));
        Update update = new Update();

        update.set(field, parameter);
        try {
            return mongoTemplate.updateFirst(query, update, MongoOrder.class).getN();
        } catch(Exception e) {
            return 0;
        }
    }

    public int updateMongoOrder(String orderCode, int platformCode, Map<String, Object> map) {
        if (map == null || map.isEmpty()) {
            return 0;
        } else {
            Query query = new Query();
            query.addCriteria(new Criteria("orderCode").is(orderCode).and("activeStatus").is("1"));
            Update update = new Update();
            for(Map.Entry<String, Object> entry : map.entrySet()) {
                update.set(entry.getKey(), entry.getValue());
            }
            update.set("updatetime", DateUtil.getCurrentDateTimeDefaultFormat());
            try {
                return mongoTemplate.updateFirst(query, update, MongoOrder.class).getN();
            } catch(Exception e) {
                return 0;
            }
        }
    }

    public List<MongoOrder> getMongoOrdersByLenovoId(int shopId, String lenovoId, int size, int offset) {
        Query query = new Query();
        query.addCriteria(Criteria.where("lenovoId").is(lenovoId).and("shopId").is(String.valueOf(shopId)).and("activeStatus").is("1")).limit(size).skip(offset);
        try {
            return mongoTemplate.find(query, MongoOrder.class);
        } catch(Exception e) {
            return null;
        }
    }


    public List<MongoOrderDetail> getOrderMessage(String orderMainCode, int shopId) {

        List<MongoOrderDetail> MongoOrderDetaillist = new ArrayList<MongoOrderDetail>();
        try {
            Criteria c = Criteria.where("orderMainCode").is(orderMainCode).and("activeStatus").is("1");
            Query query = new Query();
            query.addCriteria(c);
            MongoOrderDetaillist = mongoTemplate.find(query, MongoOrderDetail.class);
        } catch(Exception e) {
            return null;
        }
        return MongoOrderDetaillist;

    }


    /**
     * 合同调用修改审核状态
     *
     * @param orderId
     * @param shopId
     * @param beforeAuditStatus 更改审核状态的前一个状态
     * @param map
     * @return
     */
    public int updateMongoAuditContract(int shopId, String orderId, int beforeAuditStatus, Map<String, Object> map) {
        if (map == null || map.isEmpty()) {
            return 0;
        } else {
            Query query = new Query();
            query.addCriteria(new Criteria("orderCode").is(orderId).and("auditStatus").is(beforeAuditStatus).and("activeStatus").is("1"));
            Update update = new Update();
            for(Map.Entry<String, Object> entry : map.entrySet()) {
                update.set(entry.getKey(), entry.getValue());
            }
            update.set("updatetime", DateUtil.getCurrentDateTimeDefaultFormat());
            try {
                return mongoTemplate.updateFirst(query, update, MongoOrder.class).getN();
            } catch(Exception e) {
                return 0;
            }
        }
    }


}
