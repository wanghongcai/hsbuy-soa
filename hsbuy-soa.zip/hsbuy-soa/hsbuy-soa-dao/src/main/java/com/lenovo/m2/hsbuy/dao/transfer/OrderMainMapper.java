package com.lenovo.m2.hsbuy.dao.transfer;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.hsbuy.domain.order.OrderMain;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * 管道 二拆表
 *
 * @Author licy13
 * @Date 2017/5/15
 */
@Repository("transferOrderMainMapper")
public interface OrderMainMapper {

    /**
     * 根据子订单号获取二拆后的主表数据
     *
     * @param orderCode
     * @return
     */
    OrderMain getOrderByOrderCode(Long orderCode);

    /**
     * 根据主订单号获取二拆后的主表数据
     *
     * @param id
     * @return
     */
    List<OrderMain> getOrderByMainOrderCode(Long id);

    /**
     * CTO 发货时间 （复用预售字段）
     *
     * @param delay      对外发货时间
     * @param innerDelay 对内发货时间
     * @param orderCode
     * @return
     */
    int updateCTODate(@Param("delay") String delay, @Param("innerDelay") String innerDelay, @Param("orderCode") Long orderCode);

    /**
     * 更新奖励乐豆
     *
     * @param rewardLeDouNum
     * @param isRewardLeDou
     * @param orderCode
     * @return
     */
    int updateOrderLedouStatusByOrderCode(@Param("rewardLeDouNum") int rewardLeDouNum, @Param("isRewardLeDou") int isRewardLeDou, @Param("orderCode") Long orderCode);

    /**
     * 更新奖励积分
     *
     * @param score
     * @param isRewardSmbScore
     * @param orderCode
     * @return
     */
    int updateOrder17ScoreStatusByOrderCode(@Param("score") int score, @Param("isRewardSmbScore") int isRewardSmbScore, @Param("orderCode") Long orderCode);


    /**
     * 订单已修改库存，更新库存状态， 修改IsStockStatus为 1
     *
     * @param id
     * @param orderCode
     * @return
     */
    int updateIsStockStatus(@Param("id") Long id, @Param("orderCode") Long orderCode);

    /**
     * 转移失败，更新转移次数(全量库转移次数)
     *
     * @param isFullDbTranferTimes
     * @param id
     * @param orderCode
     * @return
     */
    int updateFullRePeat(@Param("isFullDbTranferTimes") int isFullDbTranferTimes, @Param("id") Long id, @Param("orderCode") Long orderCode);

    /**
     * 转移失败，更新转移次数（抛单库转移次数）
     *
     * @param transferRepeatTimes
     * @param id
     * @param orderCode
     * @return
     */
    int updateThrowRePeat(@Param("transferRepeatTimes") int transferRepeatTimes, @Param("id") Long id, @Param("orderCode") Long orderCode);


    /**
     * 转移成功，更新转移状态（全量库转移状态）
     *
     * @param fullDbTranferSuccess
     * @param id
     * @param orderCode
     * @return
     */
    int updateOrderMainFullDbTranStatus(@Param("fullDbTranferSuccess") int fullDbTranferSuccess, @Param("id") Long id, @Param("orderCode") Long orderCode);

    /**
     * 转移成功，更新转移状态（抛单库转移状态）
     *
     * @param tranferSuccess
     * @param id
     * @param orderCode
     * @return
     */
    int updateOrderMainTransferStatus(@Param("tranferSuccess") int tranferSuccess, @Param("id") Long id, @Param("orderCode") Long orderCode);


    /**
     * 根据时间范围获取未转移全量库异常订单号列表
     *
     * @param startTime
     * @param endTime
     * @return
     */
    List<Long> getPipelineToOrderCenterExceptionOrderIds(@Param("startTime") String startTime, @Param("endTime") String endTime);

    /**
     * 根据时间范围，获取某商场转移全量库异常订单号列表
     *
     * @param shopId
     * @param startTime
     * @param endTime
     * @return
     */
    List<Long> getPipelineToOrderCenterOrderIds(@Param("shopId") int shopId, @Param("startTime") String startTime, @Param("endTime") String endTime);

    /**
     * 更新预期发货时间
     *
     * @param expectDate
     * @param orderCode
     * @return
     */
    int updateExpectDate(@Param("expectDate") String expectDate, @Param("orderCode") Long orderCode);

    /**
     * 更新moto-支付返回的 账单信息
     *
     * @param orderCode
     * @param referenceNumber
     * @param handingFee
     * @return
     */
    int updateMotoBillByOrderCode(@Param("orderCode") Long orderCode, @Param("referenceNumber") String referenceNumber, @Param("handingFee") Money handingFee);


    /**
     * EPP订单更新  Enterprise 及 EnterpriseCode
     *
     * @param orderCode
     * @param enterprise
     * @param enterpriseCode
     * @return
     */
    int updateEnterPrise(@Param("orderCode") Long orderCode, @Param("enterprise") String enterprise, @Param("enterpriseCode") String enterpriseCode);


    /**
     * 更新smb 审单后的发票信息
     *
     * @param map
     * @return
     */
    int updateSMBInvoiceInfo(Map<String, Object> map);

    /**
     * 通过 ID 订单更新订单状态
     *
     * @param order
     * @return
     */
    int updateOrderStatus(OrderMain order);

    int updateMigration(OrderMain order);

    /**
     * 更新签收状态,签收时间
     *
     * @param main
     * @return
     */
    int updateSignStatus(OrderMain main);


    /**
     * 根据第三方订单号子订单号获取主单信息
     *
     * @param customerOrderCodeSon
     * @return
     */
    OrderMain getMainByCustomerOrderCodeSon(@Param("customerOrderCodeSon") String customerOrderCodeSon);
}