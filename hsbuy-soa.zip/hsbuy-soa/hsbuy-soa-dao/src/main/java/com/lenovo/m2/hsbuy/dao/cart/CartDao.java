package com.lenovo.m2.hsbuy.dao.cart;


import com.lenovo.m2.hsbuy.domain.cart.CartEntry;
import com.lenovo.m2.hsbuy.domain.cart.CartNG;

import java.util.List;
import java.util.Map;

public interface CartDao {
	
	/**
	 * 增加或更新购物车行项目
	 * @param itemId 购物行id
	 * @param item购物行详情
     * @param cartkey 购物车id
	 * @author wangrq1
	 */
	public void addOrUpdateItem(String cartkey, CartEntry entry);
	
	
	
	/**
	 * 立即购买增加购物车行项目
	 * @param itemId 购物行id
	 * @param item购物行详情
     * @param cartkey 购物车id
	 * @author wangrq1
	 */
	public void addTempItem(String cartkey, CartEntry entry);
	
	
	
	/**
	 * 批量增加或更新购物车行项目
	 * @param itemId 购物行id
	 * @param item购物行详情
     * @param cartkey 购物车id
	 * @author wangrq1
	 */
	public void addOrUpdateItems(String cartkey, List<CartEntry> entry);
	
	
	/**
	 * 删除购物行
	 * @param cartkey   
     * @param fields
	 * @return
	 * @author wangrq1
	 */
	boolean delItems(String cartkey, String... fields);
	
	
	 /**
     * 
     * @param shopid
     * @param userid
     * @param type  购物行类型
     * @param id    套餐id或skuid
     * @return
     * @author wangrq1
     */
	boolean delItem(String cartkey, String itemid);
	
	
	
	/**
	 * 删除购物行
	 * @param itemId   itemType|id   id为skuid或促销id||商品code
	 *
	 * @param shopId
	 * @param userid    由于购物车存储结构是hash 所以在操作某个用户的购物车是需要外层的大key
	 *                      userCartKey shopId+"|"+userid
	 * @param gcode     由于满返，满赠等类型的购物车采用套餐结构（packitem），
	 *                  把满返或者满赠商品视为一组，所以采用packitem的结构，
	 *                  在操作实际意义上的某行的时候，其实是操作packitem这个结构中的某个sku
	 *
	 * @return
	 * @author wangrq1
	 */
	boolean delItem(String cartkey, CartEntry entry);

    /**
     * 清空购物车
     * @param shopId 商户id 例如 B2C
     * @param userid 标识用户信息;例如商城为lenovoid
     */
    boolean delAllCart(String cartkey);

	
	/**
	 * 获取整个购物车
	 * @param cartkey 根据shopid 用户生成的购物车key 
	 * @param check   true时获取已选中的购物车， false时获取整个购物车
	 * @return
	 * @author wangrq1
	 */
    List<CartEntry> getCart(String cartkey, boolean check);
    
    
    /**
	 * 获取整个购物车, 返回结构为map
	 * @param cartkey 根据shopid 用户生成的购物车key 
	 * @param check   true时获取已选中的购物车， false时获取整个购物车
	 * @return
	 * @author wangrq1
	 */
    Map<String,CartEntry> getCartMap(String cartkey, boolean check);
    
    
    

    /**
     * 获取单行购物车
     * @param cartkey
     * @param itemid
     */
    CartEntry getCartEntry(String cartkey, String itemid);
    
    
    /**
     * 获取单行购物车
     * @param cartkey
     * @param itemid
     */
    List<CartEntry> getCartEntrys(String cartkey, String... itemid);


    /**
     * 添加报价单到购物车
     * @param key
     * @return
     */
    public CartNG getPriceListCart(String key);

    /**
     * 删除报价单
     * @param key
     * @return
     */
    public boolean delPriceListCart(String key);

    /**
     * 保存报价单到购物车
     * @param key
     * @param cartNG
     */
    public void addPriceListCart(String key, CartNG cartNG);
    
    
    
    public long pushDealNo(int shopid, String dealNo);
    
    
    long cartSize(String key);

	public int getRowNumLimit(Integer shopId);
}
