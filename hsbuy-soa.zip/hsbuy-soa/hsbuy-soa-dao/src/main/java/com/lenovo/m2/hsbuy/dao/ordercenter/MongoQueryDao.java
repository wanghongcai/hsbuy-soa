package com.lenovo.m2.hsbuy.dao.ordercenter;

import com.lenovo.m2.arch.framework.domain.PageModel;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.hsbuy.common.util.JsonUtil;
import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrderDetail;
import com.lenovo.m2.hsbuy.domain.order.mongo.PayRecords;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.type.JavaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import sun.reflect.generics.reflectiveObjects.ParameterizedTypeImpl;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Type;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by fenglg1 on 2015/5/21.
 */
@Repository
public class MongoQueryDao {
    private final static Logger LOGGER = LogManager.getLogger();

    @Autowired
    private MongoTemplate mongoTemplate;

    /**
     * 分页list方法
     *
     * @param plat
     * @param query
     * @param T
     * @return
     */

    public PageModel<?> getMongoOrderList(int plat, Query query, Class<?> T) {
        PageQuery pageQuery = new PageQuery();
        try {
            List<?> list = mongoTemplate.find(query, T);
            long pageCount = mongoTemplate.count(query, T);
            pageQuery.setTotalCount(pageCount);
            return new PageModel(pageQuery, list);
        } catch(Exception e) {
            return null;
        }
    }


    /**
     * 查询数量
     *
     * @param query
     * @return
     */
    public long getOrderCount(Query query) {
        return mongoTemplate.count(query, MongoOrderDetail.class);
    }

    /**
     * 分页list方法
     *
     * @param shopId
     * @param query
     * @param T
     * @return
     */

    public PageModel<?> getMongoOrderList(int shopId, Query query, PageQuery pageQuery, Class<?> T) {
        try {
            List<?> list = mongoTemplate.find(query, T);
            long pageCount = mongoTemplate.count(query, T);
            LOGGER.info("<=======query:{},pageCount:{}=======>",JsonUtil.toJson(query),pageCount);
            pageQuery.setTotalCount(pageCount);
            LOGGER.info("<=======pageQuery:{}=======>",JsonUtil.toJson(pageQuery));
            return new PageModel(pageQuery, list);
        } catch(Exception e) {
            return null;
        }
    }

    public <T> PageModel getMongoOrderList2(int shopId, DBObject queryObject, PageQuery pageQuery, Class<T> T) throws Exception {
        DBCursor res = mongoTemplate.getCollection("mongoorder").find(queryObject).sort(new BasicDBObject("createTime", -1)).skip(pageQuery.getPageNum()).limit(pageQuery.getPageSize());
        pageQuery.setTotalCount(res.count());
        List<T> mongoMainList = new ArrayList<>();
        while(res.hasNext()) {
            DBObject resDBObject = res.next();
            T t = JsonUtil.fromJson(resDBObject.toString(), T);
            mongoMainList.add(t);
        }
        return new PageModel<T>(pageQuery, mongoMainList);
    }

    public MongoOrderDetail getOrder(int platformCode, String orderCode) {
        try {
            MongoOrderDetail mongoOrder = mongoTemplate.findOne(new Query(Criteria.where("orderCode").is(orderCode).and("activeStatus").is("1")), MongoOrderDetail.class);
            return mongoOrder;
        } catch(Exception e) {
            LOGGER.error("getOrder error orderCode=" + orderCode, e);
            return null;
        }
    }

    public MongoOrderDetail getOrderDetail(int shopId, String orderCode) {
        try {
            return mongoTemplate.findOne(new Query(Criteria.where("orderCode").is(orderCode).and("activeStatus").is("1")), MongoOrderDetail.class, "mongoorder");
        } catch(Exception e) {
            return null;
        }
    }

    public List<MongoOrderDetail> getOrderDetailByOrderMainCode(Integer shopId, String orderMainCode) {
        try {
            return mongoTemplate.find(new Query(Criteria.where("orderMainCode").is(orderMainCode).and("activeStatus").is("1").and("orderStatus").ne("1")), MongoOrderDetail.class, "mongoorder");
        } catch(Exception e) {
            return null;
        }
    }
    /*
      get list方法
     * @param plat
     * @param query
     * @param T
     * @return
     */

    public List<?> getList(int plat, Query query, Class<?> T) {
        try {
            List<?> list = mongoTemplate.find(query, T);
            return list;
        } catch(Exception e) {
            return null;
        }
    }

    public int updateMongoStatus(int plat, String orderCode, String orderStatus) {
        DBObject queryObject = new BasicDBObject();
        queryObject.put("orderCode", orderCode);

        DBObject updateObject = new BasicDBObject();
        updateObject.put("orderStatus", orderStatus);

        DBObject res = new BasicDBObject();
        res.put("$set", updateObject);
        try {
            return mongoTemplate.getCollection("mongoorder").update(queryObject, res).getN();
        } catch(Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int updateMongoComment(String orderCode) {
        DBObject queryObject = new BasicDBObject();
        queryObject.put("orderCode", orderCode);

        DBObject updateObject = new BasicDBObject();
        updateObject.put("hasComment", "1");

        DBObject res = new BasicDBObject();
        res.put("$set", updateObject);
        try {
            return mongoTemplate.getCollection("mongoorder").update(queryObject, res).getN();
        } catch(Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     * 根据payId获取支付信息
     *
     * @param payId
     * @return
     */

    public PayRecords getPayRecordsDetail(String payId) {
        try {
            return mongoTemplate.findOne(new Query(Criteria.where("payId").is(payId)), PayRecords.class);
        } catch(Exception e) {
            return null;
        }
    }

    public List<MongoOrderDetail> queryUserOrderPage(String lenovoId, String shopId, int pageSize, int pageNum) {
        if (pageNum < 1) {
            pageNum = 1;
        }
        if (pageSize > 10) {
            pageSize = 10;
        }
        List<MongoOrderDetail> list = new ArrayList<MongoOrderDetail>();
        DBObject ref = new BasicDBObject();
        ref.put("lenovoId", lenovoId);
        ref.put("shopId", shopId);
        ref.put("orderAddType", new BasicDBObject("$ne", 11));
        ref.put("activeStatus", "1");
        DBObject orderBy = new BasicDBObject("createTime", -1);
        DBCursor rs = mongoTemplate.getCollection("mongoorder").find(ref).limit(pageSize).skip(pageSize * (pageNum - 1)).sort(orderBy);
        while(rs.hasNext()) {
            DBObject dbObject = rs.next();
            Object preferredPayment = dbObject.get("preferredPayment");
            if (null != preferredPayment) {
                DBObject ppdb = (DBObject) preferredPayment;
                Object blackBeans = ppdb.get("blackBeans");
                if (null != blackBeans) {

                }
                Object coupons = ppdb.get("coupons");
                if (null != coupons) {

                }
            }
            MongoOrderDetail mongoOrder = dbObject2Bean(dbObject, new MongoOrderDetail());
            list.add(mongoOrder);
        }

        return list;
    }

    /**
     * 把DBObject转换成bean对象
     *
     * @param dbObject
     * @param bean
     * @return
     */
    public static <T> T dbObject2Bean(DBObject dbObject, T bean) {
        return handle(dbObject, (Class<T>) bean.getClass(), bean);
    }

    public static <T> T handle(DBObject dbObject, Class<T> clazz, T bean) {
        if (!clazz.getName().equals("java.lang.Object")) {
            handle(dbObject, clazz.getSuperclass(), bean);
            Field[] fields = clazz.getDeclaredFields();
            for(Field field : fields) {
                String fieldName = field.getName();
                /*if("preferredPayment".equals(fieldName)){
                    continue;
				}*/
                Object fieldValue = dbObject.get(fieldName);
                if (fieldValue != null) {
                    if (field.getType().isPrimitive() || field.getType().getName().equals("java.lang.String")) {// 如果是基本数据类型或字符串
                        try {
                            BeanUtils.setProperty(bean, fieldName, fieldValue);
                        } catch(IllegalAccessException e) {
                            LOGGER.warn(e.getMessage());
                            e.printStackTrace();
                        } catch(InvocationTargetException e) {
                            LOGGER.warn(e.getMessage());
                            e.printStackTrace();
                        }

                    } else {// 否则应当按字符串取出并 转为 实体bean 再set到 返回的实例里

                        if (field.getType().getName().equals("java.util.List")) {// 如果是List
                            Type genericType = field.getGenericType();
                            ParameterizedTypeImpl ty = (ParameterizedTypeImpl) genericType;
                            Type[] actualType = ty.getActualTypeArguments();
                            if (actualType.length > 0) {
                                try {

                                    JavaType javaType = JsonUtil.OM.getTypeFactory().constructType(actualType[0]);
                                    JavaType javaTypeInArrayList = JsonUtil.OM.getTypeFactory().constructParametricType(ArrayList.class, javaType);
                                    Object readValue = JsonUtil.OM.readValue(fieldValue.toString(), javaTypeInArrayList);
                                    if (fieldName.contains("time") || fieldName.contains("Time")) {
                                        String str = fieldValue.toString();
                                        try {
                                            Date parse = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(str);
                                            BeanUtils.setProperty(bean, fieldName, parse);
                                        } catch(ParseException e) {
                                            e.printStackTrace();
                                        }
                                    } else {
                                        BeanUtils.setProperty(bean, fieldName, readValue);
                                    }
                                } catch(IOException e) {
                                    LOGGER.warn(e.getMessage());
                                    e.printStackTrace();
                                } catch(IllegalAccessException e) {
                                    LOGGER.warn(e.getMessage());
                                    e.printStackTrace();
                                } catch(InvocationTargetException e) {
                                    LOGGER.warn(e.getMessage());
                                    e.printStackTrace();
                                } catch(Exception e) {
                                    LOGGER.warn(e.getMessage());
                                    e.printStackTrace();
                                }

                            }

                        } else {// 否则按实体去转换 JSON
                            Type type = field.getType();
                            try {
                                JavaType javaType = JsonUtil.OM.getTypeFactory().constructType(type);
                                Object readValue = JsonUtil.OM.readValue(fieldValue.toString(), javaType);
                                BeanUtils.setProperty(bean, fieldName, readValue);
                            } catch(JsonParseException e) {
                                LOGGER.warn(e.getMessage());
                                e.printStackTrace();
                            } catch(JsonMappingException e) {
                                LOGGER.warn(e.getMessage());
                                e.printStackTrace();
                            } catch(IOException e) {
                                LOGGER.warn(e.getMessage());
                                e.printStackTrace();
                            } catch(IllegalAccessException e) {
                                LOGGER.warn(e.getMessage());
                                e.printStackTrace();
                            } catch(InvocationTargetException e) {
                                LOGGER.warn(e.getMessage());
                                e.printStackTrace();
                            }
                        }

                    }
                }
            }
        }
        return bean;
    }
}
