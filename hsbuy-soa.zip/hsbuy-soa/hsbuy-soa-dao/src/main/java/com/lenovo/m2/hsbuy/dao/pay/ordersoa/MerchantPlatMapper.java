package com.lenovo.m2.hsbuy.dao.pay.ordersoa;

import com.lenovo.m2.hsbuy.domain.pay.ordersoa.wxpay.MerchantPayPlat;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by chenww3 on 2015/4/17.
 */
public interface MerchantPlatMapper{
    public List<MerchantPayPlat> getMerchantPayPlatsByMerchantId(@Param("merchantId") String merchId);
    public List<MerchantPayPlat> getMerchantPayPlatAll();
}
