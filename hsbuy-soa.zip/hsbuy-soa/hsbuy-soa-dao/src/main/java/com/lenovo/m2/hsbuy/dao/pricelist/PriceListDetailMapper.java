package com.lenovo.m2.hsbuy.dao.pricelist;


import com.lenovo.m2.hsbuy.domain.pricelist.PriceListDetail;

import java.util.List;
import java.util.Map;

public interface PriceListDetailMapper {
    int deleteByPrimaryKey(Long id);

    int insert(PriceListDetail record);

    int insertSelective(PriceListDetail record);

    PriceListDetail selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(PriceListDetail record);

    int updateByPrimaryKey(PriceListDetail record);

    /**
     * 获取集合列表
     * @param Map
     * @return
     */
    List<PriceListDetail> getPriceDetailList(Map Map);

}