package com.lenovo.m2.hsbuy.dao.receiver;

import com.lenovo.m2.hsbuy.domain.receiver.OrderInfoEntity;
import org.springframework.stereotype.Repository;

/**
 * 
* @ClassName: OrderInfoMapper 
* @Description: 订单信息mapper 
* @author yuzj7@lenovo.com 
* @date 2015年11月15日 下午3:39:11 
*
 */
@Repository("receiveOrderInfoMapper")
public interface OrderInfoMapper {
	/**
	 * 
	* @Title: insert 
	* @Description: 接单方法，保存订单信息
	* @param orderInfo
	* @return    设定文件
	 */
	@Deprecated
	 public Long insert(OrderInfoEntity orderInfoEntity);
	 /**
	  * 
	 * @Title: getOrderByOrderNumber
	 * @Description: 根据订单号获取订单信息
	 * @param ordernum
	 * @return    设定文件
	 * @throws
	  */
	 @Deprecated
	public OrderInfoEntity getOrderByOrderNumber(Long ordernum);

	/**
	 * 接单方法，保存订单信息
	 * @param orderInfoEntity
	 * @return
	 */
	public Long insertNOrderInfo(OrderInfoEntity orderInfoEntity);

	/**
	 * 根据订单号获取订单信息
	 * @param ordernum
	 * @return
	 */
	public OrderInfoEntity getNOrderByOrderNumber(Long ordernum);
}
