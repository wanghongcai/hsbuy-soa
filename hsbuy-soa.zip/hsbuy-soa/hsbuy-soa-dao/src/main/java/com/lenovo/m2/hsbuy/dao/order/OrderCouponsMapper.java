package com.lenovo.m2.hsbuy.dao.order;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.hsbuy.domain.order.OrderCoupons;

import java.util.List;

/**
 * Created by fenglg1 on 2015/5/18.
 */
public interface OrderCouponsMapper extends GenericDao<OrderCoupons, Long> {

    public int saveOrderCoupons(OrderCoupons orderCoupon);

    public int saveOrderCouponsList(List<OrderCoupons> orderCouponList);
}
