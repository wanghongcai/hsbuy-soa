package com.lenovo.m2.hsbuy.dao.pay.ordersoa;

import com.lenovo.m2.hsbuy.domain.pay.ordersoa.wxpay.WxPayOrder;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface WxPayOrderMapper {
    /**
     *  对账查询 正向支付流水
     * @param param
     * @return
     */
    public List<WxPayOrder> getPayOrderByConf(Map param);

    public List<WxPayOrder> queryLocalFlow(Map param);

    public List<WxPayOrder> queryLocalFlowSelectice(Map param);

    Integer updatePayDetilHanndel(@Param("id") String transactionId, @Param("updateTime") String updateTime);
}