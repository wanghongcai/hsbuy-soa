package com.lenovo.m2.hsbuy.dao.pay.ordersoa;

import com.lenovo.m2.arch.framework.domain.PageModel;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.SimpleUseInfoVO;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.UserInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @author zhangyg7 on 2017/10/20.
 */
public interface UserInfoMapper {

    /**
     * 添加收银台商户
     *
     * @param userInfo 用户信息
     * @return int
     */
    int saveUserInfo(UserInfo userInfo);

    /**
     * 修改
     *
     * @param userInfo 用户信息
     * @return int
     */
    int updateUserInfo(UserInfo userInfo);

    /**
     * 查询详情
     *
     * @param userNo 商户编码
     * @return UserInfo
     */
    UserInfo getUserInfoByUserNo(@Param("userNo") String userNo);

    /**
     * 根据userNo 或者 userName判断唯一
     * @param userNo
     * @param userName
     * @return
     */
    List<UserInfo> getUniqueUserInfoByUser(@Param("userNo") String userNo, @Param("userName") String userName);

    /**
     * 根据faid 或 faname 判断唯一
     * @param faId
     * @param faName
     * @return
     */
    List<UserInfo> getUniqueUserInfoByFa(@Param("faId") String faId, @Param("faName") String faName);

    /**
     * 根据用户名称 查询收银台商户信息 userType !=1
     *
     * @param userName 商户名称
     * @return UserInfo
     */
    UserInfo getUserInfoByUserName(@Param("userName") String userName);

    /**
     * 删除用户信息
     *
     * @param userNo 商户编码
     * @return int
     */
    int deleteUserInfoByUserNo(@Param("userNo") String userNo);

    /**
     * 分页查询
     *
     * @param pageQuery 分页参数
     * @param map       条件参数 带权限
     * @return PageModel<UserInfo>
     */
    PageModel<UserInfo> getUserInfoPage(PageQuery pageQuery, @Param("param2") Map map);

    /**
     * 不带权限查询用户信息列表
     * @param pageQuery
     * @param map
     * @return
     */
    PageModel<UserInfo>  getUserInfoOfMerchantPage(PageQuery pageQuery, @Param("param2") Map map);

    /**
     *  查询 启用状态 and userType != 列表
     *  @param map  权限参数
     * @return
     */
    List<SimpleUseInfoVO> querySimpleUserInfoList(@Param("param2") Map map);

    /**
     * pay-soa使用
     * 根据fa 查询 启用状态下 支持网银付款的信息
     * @param faId
     * @return
     */
    UserInfo getEnablePersonalBankByFaId(@Param("faId") String faId);

    /**
     * 根据faId查询信息
     * @param faId
     * @return
     */
    UserInfo getUserInfoByFaId(@Param("faId") String faId);

    /**
     * 查询商户权限列表
     * @return
     */
    List<SimpleUseInfoVO> queryPermissionsList();


    List<UserInfo> queryListByremark(@Param("remark") String remark);
}
