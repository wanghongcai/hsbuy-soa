package com.lenovo.m2.hsbuy.dao.transfer;

import com.lenovo.m2.hsbuy.domain.transfer.OrderScore;
import org.apache.ibatis.annotations.Param;

public interface OrderScoreMapper {

    /**
     * 保存 订单积分记录
     *
     * @param record
     * @return
     */
    int insert(OrderScore record);

    /**
     * 通过订单查询订单积分记录
     *
     * @param orderCode
     * @return
     */
    OrderScore selectByOrderCode(Long orderCode);

    /**
     * 根据订单号更新 积分状态
     *
     * @param rewardStatus
     * @param orderCode
     * @return
     */
    int updateRewardStatusByOrderCode(@Param("rewardStatus") int rewardStatus, @Param("orderCode") Long orderCode);

    /**
     * 根据订单号更新 同步状态
     *
     * @param syncStatus
     * @param orderCode
     * @return
     */
    int updateSyncStatusByOrderCode(@Param("syncStatus") int syncStatus, @Param("orderCode") Long orderCode);
}