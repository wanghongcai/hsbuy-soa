package com.lenovo.m2.hsbuy.dao.pay.ordersoa;


import com.lenovo.m2.hsbuy.domain.pay.ordersoa.wxpay.PayPortalOrder;

import java.util.List;
import java.util.Map;

public interface PayPortalOrderMapper {
    /**
     * 对账查询 支付映射别
     * @param map
     * @return
     */
    public List<PayPortalOrder> getPayPortalOrderByConf(Map map);
}