package com.lenovo.m2.hsbuy.dao.throwengine;

import com.lenovo.m2.hsbuy.domain.order.DeliveryAddress;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by jiazy on 2017/6/1.
 */
public interface DeliveryAddMapper {

    /**
     * 通过订单号 和 类型获取 地址信息
     * 0、收货地址，1、发票寄送地址，2、合同寄送
     *
     * @param orderId
     * @param type
     * @return
     */
    DeliveryAddress getAddressByOrderIdAndType(@Param("orderId") Long orderId, @Param("type") Integer type);

    /**
     * 根据订单号获取地址列表
     *
     * @param orderId
     * @return
     */
    List<DeliveryAddress> getAddressListByOrderId(@Param("orderId") Long orderId);
}
