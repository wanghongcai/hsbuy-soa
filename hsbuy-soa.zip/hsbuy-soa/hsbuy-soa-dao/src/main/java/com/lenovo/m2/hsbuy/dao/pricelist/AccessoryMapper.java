package com.lenovo.m2.hsbuy.dao.pricelist;


import com.lenovo.m2.hsbuy.domain.pricelist.CTOAccessory;

import java.util.List;
import java.util.Map;

public interface AccessoryMapper {
    int deleteByPrimaryKey(Long id);

    int insert(CTOAccessory record);

    int insertSelective(CTOAccessory record);

    CTOAccessory selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(CTOAccessory record);

    int updateByPrimaryKey(CTOAccessory record);

    List<CTOAccessory> getAccessoryList(Map map);

}