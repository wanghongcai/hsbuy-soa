package com.lenovo.m2.hsbuy.dao.sequence;


import com.lenovo.m2.hsbuy.domain.sequence.Generator;

import java.util.List;

public interface GeneratorMapper {

    Long insert(Generator record);

    Generator getGeneratorByKey(String ownerKey);

    Long updateGenerator(String ownerKey);

    List<Generator> getGeneratorList();
}