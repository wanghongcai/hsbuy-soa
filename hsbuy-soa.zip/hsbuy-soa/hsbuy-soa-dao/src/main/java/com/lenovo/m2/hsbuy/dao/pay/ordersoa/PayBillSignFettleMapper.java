package com.lenovo.m2.hsbuy.dao.pay.ordersoa;


import com.lenovo.m2.hsbuy.domain.pay.ordersoa.wxpay.PayBillSignFettle;

import java.util.List;
import java.util.Map;

public interface PayBillSignFettleMapper {
    /**
     * 条件删除
     * @mbggenerated
     */
   public int deleteSignFettleByExample(Map param);


    /**
     * 插入记录
     * @mbggenerated
     */
    public int insertSignFettleSelective(PayBillSignFettle record);

    /**
     *条件查询
     * @mbggenerated
     */
    public List<PayBillSignFettle> selectSignFettleByExample(Map param);

}