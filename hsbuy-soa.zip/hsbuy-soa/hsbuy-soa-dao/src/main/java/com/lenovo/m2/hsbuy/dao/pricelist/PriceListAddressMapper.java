package com.lenovo.m2.hsbuy.dao.pricelist;


import com.lenovo.m2.hsbuy.domain.pricelist.PriceListAddress;

public interface PriceListAddressMapper {
    int deleteByPrimaryKey(Long id);

    int insert(PriceListAddress record);

    int insertSelective(PriceListAddress record);

    PriceListAddress selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(PriceListAddress record);

    int updateByPrimaryKey(PriceListAddress record);
}