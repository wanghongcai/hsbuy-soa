package com.lenovo.m2.hsbuy.dao.order;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.hsbuy.domain.order.DeliveryAddress;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by fenglg1 on 2015/5/28.
 */
public interface DeliveryAddressMapper extends GenericDao<DeliveryAddress, Long> {

     int saveDeliveryAddress(DeliveryAddress deliveryAddress);

     int saveDeliveryAddressList(List<DeliveryAddress> deliveryAddressList);

     /**
      * 根据订单编号和地址类型获取地址详情
      *
      * @param orderId
      * @param type
      * @return
      */
     String getDeliveryAddressByOrderId(@Param("orderId") long orderId, @Param("type") long type);
}
