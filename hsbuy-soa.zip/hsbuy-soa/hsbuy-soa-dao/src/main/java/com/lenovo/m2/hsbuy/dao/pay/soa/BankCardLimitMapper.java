package com.lenovo.m2.hsbuy.dao.pay.soa;


import com.lenovo.m2.hsbuy.domain.pay.soa.outpay.BankCardLimit;

import java.util.List;

/**
 * Created by tianchuyang on 2017/1/6.
 */
public interface BankCardLimitMapper {

    /**
     * 根据参数准确查询
     * @param bankCardLimit
     * @return
     */
    List<BankCardLimit> getBankCardLimitByParams(BankCardLimit bankCardLimit);

    /**
     * 查询所有
     * @return
     */
    List<BankCardLimit> getAllBankCardLimits();
}
