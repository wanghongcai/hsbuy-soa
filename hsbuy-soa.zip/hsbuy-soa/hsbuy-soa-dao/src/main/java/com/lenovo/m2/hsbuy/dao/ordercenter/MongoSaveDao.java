package com.lenovo.m2.hsbuy.dao.ordercenter;

import com.lenovo.m2.hsbuy.common.util.JsonUtil;
import com.lenovo.m2.hsbuy.domain.order.mongo.PayRecords;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.util.JSON;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

/**
 * Created by Administrator on 2017-07-07.
 */
@Repository
public class MongoSaveDao {
    @Autowired
    private MongoTemplate mongoTemplate;
    /**
     * 保存
     * @param payRecords
     * @return
     */
    public int savePayRecords(PayRecords payRecords) {
        DBObject dbObject = (DBObject) JSON.parse(JsonUtil.toJson(payRecords));
        try {
            PayRecords pr  = mongoTemplate.findOne(new Query(Criteria.where("orderCode").is(payRecords.getOrderCode())), PayRecords.class, "payrecords");
            if (null != pr) {
                return 0;
            } else {
                return mongoTemplate.getCollection("payrecords").insert(dbObject).getLastError().ok() ? 1 : 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     * 更新
     * @param
     * @return
     */
    public int updatePayRecords(String payId , DBObject updateObject) {
        DBObject queryObject = new BasicDBObject();
        queryObject.put("payId", payId);

        DBObject res = new BasicDBObject();
        res.put("$set", updateObject);
        try {
            return   mongoTemplate.getCollection("payrecords").update(queryObject,res).getN();
        } catch (Exception e) {
            e.printStackTrace();
            return  0;
        }

    }

    /**
     * 更新惠商订单的上传状态
     *
     * @return
     */
    public int updateMongoPayRecords(String orderCode, String uploadStatus) {
        DBObject queryObject = new BasicDBObject();
        queryObject.put("orderCode", orderCode);

        DBObject res = new BasicDBObject();
        DBObject updateObject = new BasicDBObject();
        updateObject.put("uploadStatus", uploadStatus);
        res.put("$set", updateObject);
        try {
            return mongoTemplate.getCollection("mongoorder").update(queryObject, res).getN();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }



}
