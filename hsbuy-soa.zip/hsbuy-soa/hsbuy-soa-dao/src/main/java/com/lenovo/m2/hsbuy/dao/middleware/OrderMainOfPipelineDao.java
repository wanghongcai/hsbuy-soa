package com.lenovo.m2.hsbuy.dao.middleware;

import com.lenovo.m2.hsbuy.domain.order.OrderMain;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderMain;
import com.lenovo.m2.hsbuy.domain.order.mongo.Product;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author : 朝阳
 * @version : v1.0
 * @email : licy13@lenovo.com
 * @time : 2017/11/20 14:38
 */
public interface OrderMainOfPipelineDao {

    List<Product> queryProduct(@Param("orderCode") String orderCode);

    OrderMain queryOrderByOrderCode(@Param("orderCode") String orderCode);

    List<OrderMain> queryOrderByOrderId(@Param("orderId") String orderId);

    OrderMain queryMOrderByOrderCode(@Param("orderCode") String orderCode);

    OrderMain queryMOrderFullByOrderCode(@Param("orderCode") String orderCode);

    List<OrderMain> queryMOrders(@Param("lenovoId") String lenovoId, @Param("shopId") int shopId, @Param("offset") int offset, @Param("pageSize") int pageSize);


    List<String> queryCouponOfOrder(@Param("orderCode") String orderCode);

    List<String> queryCouponCodeOfOrder(@Param("orderCode") String orderCode);

    List<String> queryCouponOfMOrder(@Param("orderCode") String orderCode);

    List<String> queryCouponOfMOrderHS(@Param("orderCode") String orderCode);


    /**
     * 合同调用更新合同地址和审核状态
     *
     * @param mOrderMain
     * @return
     */
    int updateMOrderMainAuditStatus(@Param("mOrderMain") MOrderMain mOrderMain, @Param("beforeAuditStatus") int beforeAuditStatus);

    /**
     * 回滚审核状态
     *
     * @param mOrderMain
     * @return
     */
    int rollBackMOrderMainAuditStatus(@Param("mOrderMain") MOrderMain mOrderMain, @Param("beforeAuditStatus") int beforeAuditStatus);

    /**
     * 更新转移状态
     *
     * @param tranferSuccessBefore
     * @param tranferSuccessAfter
     * @param orderCode
     * @return
     */
    int updateOrderMainTransferStatus(@Param("tranferSuccessBefore") int tranferSuccessBefore, @Param("tranferSuccessAfter") int tranferSuccessAfter, @Param("orderCode") Long orderCode);

}
