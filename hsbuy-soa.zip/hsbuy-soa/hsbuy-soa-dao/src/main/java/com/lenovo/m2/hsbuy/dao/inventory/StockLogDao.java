package com.lenovo.m2.hsbuy.dao.inventory;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.arch.framework.domain.PageModel;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.hsbuy.domain.inventory.StockInfoLog;

import java.util.List;
import java.util.Map;

/**
 * Created by Jiazy on 15-7-1.
 * Add by dongcy5 on 15-7-10. 库存日志信息分页查询
 */
public interface StockLogDao extends GenericDao<StockInfoLog,Long> {

    /**
     * 增加库存日志
     * @return
     */
    public int addStockInfoLog(StockInfoLog stockInfoLog);

    /**
     * 获取 库存操作的 日志
     * @param map
     * @return
     */
    public List<StockInfoLog> getStockLogList(Map map);

    /**
     * 库存日志信息分页查询
     * @param pageQuery
     * @return
     *
     */
    public PageModel<StockInfoLog> getStockInfoLogPage(PageQuery pageQuery, Map map);
}
