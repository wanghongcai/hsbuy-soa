package com.lenovo.m2.hsbuy.dao.pay.ordersoa;


import com.lenovo.m2.hsbuy.domain.pay.ordersoa.ChannelOrder;

public interface ChannelOrderMainMapper {
    /**
     * 插入记录
     */
    int saveChannelOrderMain(ChannelOrder record);
}