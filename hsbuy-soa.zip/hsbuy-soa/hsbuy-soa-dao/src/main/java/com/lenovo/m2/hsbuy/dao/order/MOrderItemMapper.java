package com.lenovo.m2.hsbuy.dao.order;

import com.lenovo.m2.arch.framework.dao.GenericDao;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderItem;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by fenglg1 on 2016/2/24.
 */
public interface MOrderItemMapper extends GenericDao<MOrderItem, Long> {

    List<MOrderItem> getMOrderItemByOrderId(@Param("orderId") Long orderId);

    int saveMOrderItem(List<MOrderItem> orderItemList);

    int save(MOrderItem mOrderItem);

    int updateMorderItemGprice(MOrderItem mOrderItem);

    /**
     * 手动调用，请勿使用
     * @param mOrderItem
     * @return
     */
    int updateMorderProductName(MOrderItem mOrderItem);
}
