package com.lenovo.m2.hsbuy.dao.pay.ordersoa;

import com.lenovo.m2.arch.framework.domain.PageModel;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.wxpay.ChannelOrderInfo;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public interface ChannelOrderMapper {


    /**
     * 插入记录
     */
    int insertChannelOrderSelective(ChannelOrderInfo record);

    /**
     * 查询记录
     */
    List<ChannelOrderInfo> selectChannelOrderByExample(Map map);

    /**
     * 查询主单LIST
     */
    List<ChannelOrderInfo> selectChannelOrderMainCodeList(Map map);

    /**
     * 查询主单信息
     * @param orderMainCode
     * @param lenovoId
     * @return
     */
    ChannelOrderInfo selectChannelOrderMainCodeDetail(@Param("orderMainCode") String orderMainCode, @Param("lenovoId") String lenovoId, @Param("shopId") String shopId);
    //查询子单信息
    ChannelOrderInfo selectChannelOrderCodeDetail(@Param("orderCode") String orderCode, @Param("lenovoId") String lenovoId, @Param("shopId") String shopId);


    /**
     * 根据主单号修改订单信息
     * @param orderCode
     * @param lenovoId
     * @param payMent
     * @param transationId
     * @param payStatus
     * @return
     */
    public void updateChannelOrderMainCodeDetail(@Param("orderCode") String orderCode, @Param("lenovoId") String lenovoId, @Param("payment") int payMent, @Param("transationId") String transationId, @Param("payStatus") int payStatus, @Param("payTime") String payTime, @Param("shopId") String shopId, @Param("fqNum") Integer fqNum);

    public Integer updateChannelOrderMain(@Param("orderCode") String orderCode, @Param("mainFlag") Integer mainFlag, @Param("payment") int payMent, @Param("transationId") String transationId, @Param("payTime") String payTime);

    /**
     * 查询orderMainCode下所有子单
     * @param orderMainCode
     * @param lenovoId
     * @return
     */
    List<ChannelOrderInfo> queryChannelOrderCodeList(@Param("orderMainCode") String orderMainCode, @Param("lenovoId") String lenovoId, @Param("mainFlag") int mainFlag, @Param("shopId") String shopId);

    /**
     * 查询子单信息
     * @param orderCode
     * @param lenovoId
     * @return
     */
    public ChannelOrderInfo queryChannelOrderCodeDetail(@Param("orderCode") String orderCode, @Param("lenovoId") String lenovoId, @Param("mainFlag") int mainFlag, @Param("shopId") String shopId);

    /**
     * 查询子单List
     * @param map
     * @returen list
     */
    public List<ChannelOrderInfo> queryOrderCodeList(Map map);

    /**
     * Update校验累计退货金额，防重复提交
     * @param refundMoney
     * @param orderCode
     * @return
     */
    public int updateChannelOrderRefundMoney(@Param("refundMoney") BigDecimal refundMoney, @Param("orderCode") String orderCode);

    /**
     * 回滚累计退货金额
     * @param refundMoney
     * @param orderCode
     * @return
     */
    public int rollBackChannelOrderRefundMoney(@Param("refundMoney") BigDecimal refundMoney, @Param("orderCode") String orderCode);

    /**
     * 更新订单状态
     * @param orderStatus
     * @param orderCode
     * @param mainFlag
     * @return
     */
    public Integer updateChannelOrderOrderStatus(@Param("orderStatus") int orderStatus, @Param("orderCode") String orderCode, @Param("mainFlag") int mainFlag, @Param("shopId") String shopId);

    /**
     * 附表去支付更新至主表操作
     * @param orderInfo payTime payStatus receiveMoney
     * @return
     */
    public Integer updateChannelOrderByOrderTracePay(ChannelOrderInfo orderInfo);

    /**
     * 查询 ChannelOrder表
     * @param map
     * @returen list
     */
    public List<ChannelOrderInfo> queryChannelOrderSelective(Map map);

    /**
     * 查询待取消主单列表
     * @param map
     * @returen list
     */
    public List<ChannelOrderInfo> queryOrderList(PageQuery pageQuery, Map map);

    /**
     * 批量取消订单
     * @param map
     * @returen
     */
    public int cancelOrderList(Map map);

    /**
     * 查询超时订单列表
     * @param map
     * @returen list
     */
    public List<ChannelOrderInfo> queryTimeoutOrderList(PageQuery pageQuery, @Param("paramMap") Map map);

    /**
     * 查询超时订单列表 特殊时段
     * @param map
     * @returen list
     */
    public List<ChannelOrderInfo> queryTimeoutSpecialOrderList(PageQuery pageQuery, @Param("paramMap") Map map);
    /**
     * 查询超时订单列表 空白时段
     * @param map
     * @returen list
     */
    public List<ChannelOrderInfo> queryTimeoutGapOrderList(PageQuery pageQuery, @Param("paramMap") Map map);

    /**
     * 对账  查询主单数
     */
    public List<ChannelOrderInfo> selectChannelOrderForCheckAccount(Map param);

    public Integer updateChannelOrderSubByOrderRefund(@Param("orderCode") String orderCode, @Param("mainFlag") Integer mainFlag, @Param("transationId") String transationId, @Param("refundTime") String refundTime);

    public List<ChannelOrderInfo> queryChannelOrderSubBytransationId(Map param);
    public PageModel<ChannelOrderInfo> queryChannelOrderPage(PageQuery pageQuery, Map param);
    public List<ChannelOrderInfo> queryChannelOrderSubByTime(Map param);


    public List<ChannelOrderInfo> queryPresellNotLastPayList(@Param("paramMap") Map map);

}