package com.lenovo.m2.hsbuy.migration;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author : 朝阳
 * @version : v1.0
 * @email : licy13@lenovo.com
 * @time : 2017/12/15 15:19
 */
public interface MigrationMapper {

   public List<Map> getMainInfo(int shopId);

}
