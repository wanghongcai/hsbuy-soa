package com.lenovo.m2.hsbuy.dao.pay.ordersoa;

import com.lenovo.m2.hsbuy.domain.pay.ordersoa.wxpay.RefundOrder;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface RefundOrderMapper {
    /**
     * 对账 退款流水查询 按条件查询
     * @param param
     * @return
     */
    public List<RefundOrder> getRefundOrderByConf(Map param);

    RefundOrder queryChannelOrderRefund(@Param("refundNo") String refundNo, @Param("originalTradeNo") String originalTradeNo);

    List<RefundOrder> queryPayRefundDataInfo(Map param);
}